(() => {
  "use strict";

  const SVG_NS = "http://www.w3.org/2000/svg";
  const STORAGE_KEY = "nexterra-demo-state-v1";
  const layerDefinitions = [
    { id: "heat", label: "Heat map", color: "#f0794d" },
    { id: "lst", label: "Land surface temp.", color: "#ffb54d" },
    { id: "landuse", label: "Land use", color: "#b4c86f" },
    { id: "vegetation", label: "Vegetation", color: "#59bd72" },
    { id: "wind", label: "Wind", color: "#54c4d2" },
    { id: "humidity", label: "Humidity", color: "#6d9ce5" },
    { id: "population", label: "Population / exposure", color: "#cf83d5" }
  ];

  const solutions = [
    { id: "trees", name: "Tree plantation", icon: "♧", short: "Shade streets and public spaces.", band: "1–3°C local", weight: 0.36, co2: 1.8, energy: 0.55, water: 0.34, time: "6–12 months", role: "Parks & urban forestry", valid: "Parks, streets, public space" },
    { id: "cool-roofs", name: "Cool roofs", icon: "⌂", short: "Reflect heat from rooftops.", band: "1–2.5°C local", weight: 0.32, co2: 1.15, energy: 1.15, water: 0.08, time: "3–6 months", role: "Buildings & facilities", valid: "Built-up / roof areas" },
    { id: "albedo", name: "Albedo materials", icon: "▧", short: "Use reflective surfaces where suitable.", band: "1–2°C local", weight: 0.25, co2: 0.55, energy: 0.35, water: 0.03, time: "6–9 months", role: "Public works", valid: "Roads and paved areas" },
    { id: "parks", name: "Small parks", icon: "❋", short: "Create pocket parks and green space.", band: "1.5–3°C local", weight: 0.4, co2: 1.5, energy: 0.42, water: 0.75, time: "9–18 months", role: "Parks & community", valid: "Open parcels / neighbourhoods" },
    { id: "water", name: "Water bodies / lakes", icon: "≈", short: "Restore blue-green cooling assets.", band: "2–4°C local", weight: 0.43, co2: 0.5, energy: 0.25, water: 1.6, time: "12–24 months", role: "Water & ecology teams", valid: "Lake / water-adjacent areas" },
    { id: "solar", name: "Solar energy", icon: "☼", short: "Add rooftop solar and shade.", band: "1–2°C local", weight: 0.24, co2: 2.2, energy: 1.7, water: 0.04, time: "6–12 months", role: "Energy & buildings", valid: "Built-up / roof areas" },
    { id: "green-roofs", name: "Green roofs", icon: "▱", short: "Add planted roof systems.", band: "1–2.5°C local", weight: 0.3, co2: 1.1, energy: 0.8, water: 0.56, time: "6–12 months", role: "Buildings & horticulture", valid: "Suitable roof areas" },
    { id: "vertical", name: "Vertical gardens", icon: "▥", short: "Bring planting to suitable facades.", band: "1–2°C local", weight: 0.2, co2: 0.65, energy: 0.48, water: 0.18, time: "4–8 months", role: "Buildings & community", valid: "Suitable building facades" }
  ];

  const zoneShapes = [
    { key: "northwest", points: "70,58 302,44 313,194 80,210", cx: 191, cy: 123 },
    { key: "north", points: "302,44 566,59 550,211 313,194", cx: 432, cy: 125 },
    { key: "northeast", points: "566,59 832,45 841,225 550,211", cx: 697, cy: 132 },
    { key: "west", points: "80,210 313,194 302,394 70,403", cx: 190, cy: 300 },
    { key: "central", points: "313,194 550,211 559,400 302,394", cx: 430, cy: 300 },
    { key: "east", points: "550,211 841,225 828,407 559,400", cx: 695, cy: 308 },
    { key: "southwest", points: "70,403 302,394 310,575 58,556", cx: 187, cy: 483 },
    { key: "south", points: "302,394 559,400 570,581 310,575", cx: 436, cy: 486 }
  ];

  const cityData = {
    bengaluru: {
      name: "Bengaluru", population: "8.4M", timestamp: "18 JUN 2025", baselineDrivers: [34, 27, 23, 16],
      zones: [
        { id: "northwest", name: "Yelahanka", temp: 36.8, population: 48000, area: 15, veg: 39, built: 38, industrial: 8, water: 15, wind: 55, humidity: 57, drivers: [22, 18, 24, 36] },
        { id: "north", name: "Hebbal", temp: 39.1, population: 59000, area: 13, veg: 25, built: 49, industrial: 9, water: 13, wind: 48, humidity: 49, drivers: [31, 24, 23, 22] },
        { id: "northeast", name: "Whitefield", temp: 41.2, population: 92000, area: 19, veg: 13, built: 61, industrial: 15, water: 7, wind: 38, humidity: 39, drivers: [37, 29, 22, 12] },
        { id: "west", name: "Peenya", temp: 42.0, population: 73000, area: 14, veg: 9, built: 52, industrial: 29, water: 4, wind: 35, humidity: 36, drivers: [30, 25, 30, 15] },
        { id: "central", name: "Koramangala", temp: 39.6, population: 63000, area: 12, veg: 14, built: 58, industrial: 17, water: 5, wind: 43, humidity: 42, drivers: [35, 29, 21, 15] },
        { id: "east", name: "Indiranagar", temp: 38.8, population: 54000, area: 11, veg: 24, built: 55, industrial: 13, water: 8, wind: 47, humidity: 46, drivers: [30, 23, 25, 22] },
        { id: "southwest", name: "Basavanagudi", temp: 37.5, population: 42000, area: 8, veg: 35, built: 45, industrial: 8, water: 12, wind: 52, humidity: 53, drivers: [25, 20, 22, 33] },
        { id: "south", name: "Jayanagar", temp: 38.2, population: 51000, area: 8, veg: 29, built: 50, industrial: 11, water: 8, wind: 49, humidity: 48, drivers: [28, 24, 23, 25] }
      ],
      hotspots: [
        { zone: "northeast", x: 764, y: 120, severity: "Very high" },
        { zone: "west", x: 131, y: 335, severity: "Very high" },
        { zone: "central", x: 486, y: 340, severity: "High" },
        { zone: "east", x: 757, y: 347, severity: "High" },
        { zone: "north", x: 473, y: 146, severity: "High" },
        { zone: "south", x: 480, y: 522, severity: "Moderate" }
      ]
    },
    vadodara: {
      name: "Vadodara", population: "2.3M", timestamp: "18 JUN 2025", baselineDrivers: [31, 30, 22, 17],
      zones: [
        { id: "northwest", name: "Gotri", temp: 39.1, population: 37000, area: 15, veg: 25, built: 53, industrial: 10, water: 12, wind: 46, humidity: 48, drivers: [29, 27, 22, 22] },
        { id: "north", name: "Sama", temp: 38.4, population: 33000, area: 13, veg: 32, built: 47, industrial: 9, water: 12, wind: 51, humidity: 51, drivers: [27, 25, 21, 27] },
        { id: "northeast", name: "Waghodia Road", temp: 41.5, population: 66000, area: 19, veg: 12, built: 58, industrial: 23, water: 7, wind: 37, humidity: 38, drivers: [34, 27, 28, 11] },
        { id: "west", name: "Makarpura", temp: 42.1, population: 61000, area: 14, veg: 8, built: 48, industrial: 36, water: 8, wind: 34, humidity: 35, drivers: [27, 25, 34, 14] },
        { id: "central", name: "Alkapuri", temp: 40.1, population: 49000, area: 12, veg: 18, built: 64, industrial: 11, water: 5, wind: 41, humidity: 40, drivers: [36, 29, 19, 16] },
        { id: "east", name: "Karelibaug", temp: 39.2, population: 46000, area: 11, veg: 26, built: 53, industrial: 12, water: 9, wind: 47, humidity: 46, drivers: [30, 25, 22, 23] },
        { id: "southwest", name: "Tandalja", temp: 38.7, population: 41000, area: 8, veg: 24, built: 53, industrial: 13, water: 10, wind: 45, humidity: 47, drivers: [29, 27, 23, 21] },
        { id: "south", name: "Manjalpur", temp: 39.6, population: 58000, area: 8, veg: 16, built: 60, industrial: 17, water: 7, wind: 40, humidity: 41, drivers: [33, 28, 23, 16] }
      ],
      hotspots: [
        { zone: "northeast", x: 764, y: 120, severity: "Very high" },
        { zone: "west", x: 131, y: 335, severity: "Very high" },
        { zone: "central", x: 486, y: 340, severity: "Very high" },
        { zone: "east", x: 757, y: 347, severity: "High" },
        { zone: "north", x: 473, y: 146, severity: "High" },
        { zone: "south", x: 480, y: 522, severity: "High" }
      ]
    }
  };

  const freshState = () => ({
    city: "bengaluru",
    layers: { heat: true, lst: false, landuse: false, vegetation: false, wind: false, humidity: false, population: false },
    activeLayer: "heat",
    selectedZone: null,
    compare: "baseline",
    placements: [],
    selectedPlacement: null,
    pendingSolution: null,
    movingPlacement: null,
    chat: [],
    planGenerated: false,
    score: 0,
    badges: [],
    zoom: 1,
    elevated: false,
    panX: 0,
    panY: 0
  });

  let state = freshState();
  let undoStack = [];
  let redoStack = [];
  let chatBusy = false;
  let tourStep = 0;
  let toastId = 0;
  let panSession = null;
  let suppressMapClick = false;
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const city = () => cityData[state.city];
  const currentZone = () => city().zones.find((zone) => zone.id === state.selectedZone) || null;
  const solution = (id) => solutions.find((item) => item.id === id);
  const zoneById = (id) => city().zones.find((zone) => zone.id === id);
  const activeCount = () => state.placements.filter((item) => item.enabled !== false).length;

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[character]);
  }

  function loadSavedState() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return;
      const parsed = JSON.parse(saved);
      if (!parsed || typeof parsed !== "object" || !cityData[parsed.city]) throw new Error("Saved demo data has an invalid city.");
      const restored = freshState();
      restored.city = parsed.city;
      restored.layers = { ...restored.layers, ...(parsed.layers || {}) };
      restored.activeLayer = layerDefinitions.some((item) => item.id === parsed.activeLayer) ? parsed.activeLayer : "heat";
      restored.selectedZone = cityData[restored.city].zones.some((zone) => zone.id === parsed.selectedZone) ? parsed.selectedZone : null;
      restored.compare = parsed.compare === "scenario" ? "scenario" : "baseline";
      restored.placements = Array.isArray(parsed.placements) ? parsed.placements.filter((item) =>
        item && solution(item.type) && typeof item.id === "string" && Number.isFinite(item.x) && Number.isFinite(item.y) &&
        cityData[restored.city].zones.some((zone) => zone.id === item.zoneId)
      ).map((item) => ({ ...item, quantity: Math.max(1, Math.min(500, Number(item.quantity) || 1)), enabled: item.enabled !== false })) : [];
      restored.chat = Array.isArray(parsed.chat) ? parsed.chat.slice(-40).filter((entry) => entry && (entry.role === "user" || entry.role === "assistant") && typeof entry.text === "string").map((entry) => ({ role: entry.role, text: entry.text, action: null, time: entry.time || timeNow() })) : [];
      restored.planGenerated = parsed.planGenerated === true && restored.placements.length > 0;
      restored.score = Number.isFinite(parsed.score) ? Math.max(0, parsed.score) : 0;
      restored.badges = Array.isArray(parsed.badges) ? parsed.badges.filter((badge) => typeof badge === "string") : [];
      restored.zoom = Number.isFinite(parsed.zoom) ? Math.min(1.7, Math.max(.8, parsed.zoom)) : 1;
      restored.elevated = parsed.elevated === true;
      state = restored;
    } catch (error) {
      console.error("Could not restore the NexTerra demo session:", error);
      showToast("Saved demo data could not be loaded. A fresh session is ready.", true);
    }
  }

  function persistState() {
    const stored = {
      city: state.city, layers: state.layers, activeLayer: state.activeLayer, selectedZone: state.selectedZone,
      compare: state.compare, placements: state.placements, chat: state.chat, planGenerated: state.planGenerated,
      score: state.score, badges: state.badges, zoom: state.zoom, elevated: state.elevated
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
    } catch (error) {
      console.error("Could not save the NexTerra demo session:", error);
      showToast("Your browser could not save this session. Keep this tab open to preserve your scenario.", true);
    }
  }

  function timeNow() {
    return new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit" }).format(new Date());
  }

  function showToast(message, isError = false) {
    const toast = document.createElement("div");
    toast.className = `toast${isError ? " error" : ""}`;
    toast.setAttribute("role", isError ? "alert" : "status");
    toast.textContent = message;
    $("#toastRegion").append(toast);
    const id = ++toastId;
    window.setTimeout(() => {
      if (toast.isConnected && id <= toastId) toast.remove();
    }, 3900);
  }

  function averageTemperature(useScenario = state.compare === "scenario") {
    const zones = city().zones;
    const totalArea = zones.reduce((sum, zone) => sum + zone.area, 0);
    return zones.reduce((sum, zone) => sum + (useScenario ? scenarioForZone(zone).temperature : zone.temp) * zone.area, 0) / totalArea;
  }

  function riskForTemperature(temp) {
    if (temp < 32) return { label: "Low", className: "risk-low", bin: 0 };
    if (temp < 36) return { label: "Moderate", className: "risk-moderate", bin: 1 };
    if (temp < 40) return { label: "High", className: "risk-high", bin: 2 };
    if (temp < 44) return { label: "Very high", className: "risk-very-high", bin: 3 };
    return { label: "Extreme", className: "risk-very-high", bin: 4 };
  }

  function scenarioForZone(zone) {
    const placements = state.placements.filter((item) => item.enabled !== false && item.zoneId === zone.id);
    if (!placements.length) return { temperature: zone.temp, reduction: 0, count: 0 };
    const raw = placements.reduce((sum, item) => {
      const itemType = solution(item.type);
      const scaleFactor = 0.58 + Math.min(Number(item.quantity) || 1, 150) / 210;
      return sum + itemType.weight * scaleFactor;
    }, 0);
    const diminishingFactor = 1 / (1 + 0.2 * Math.max(0, placements.length - 1));
    const reduction = Math.min(1.4, raw * diminishingFactor);
    return { temperature: zone.temp - reduction, reduction, count: placements.length };
  }

  function scenarioBenefits() {
    const active = state.placements.filter((item) => item.enabled !== false);
    const totals = active.reduce((sum, item) => {
      const type = solution(item.type);
      const quantityFactor = Math.min(Number(item.quantity) || 1, 150) / 20;
      const localFactor = 0.55 + type.weight;
      sum.co2 += type.co2 * quantityFactor * localFactor;
      sum.energy += type.energy * quantityFactor * localFactor;
      sum.water += type.water * quantityFactor * localFactor;
      return sum;
    }, { co2: 0, energy: 0, water: 0 });
    const comfort = Math.min(100, Math.round(active.reduce((sum, item) => sum + solution(item.type).weight * (0.6 + Math.min(item.quantity, 100) / 90) * 17, 0)));
    return { ...totals, comfort };
  }

  function weightedDriverMix(zone) {
    if (zone) return zone.drivers;
    const area = city().zones.reduce((sum, item) => sum + item.area, 0);
    return [0, 1, 2, 3].map((driverIndex) => Math.round(city().zones.reduce((sum, item) => sum + item.drivers[driverIndex] * item.area, 0) / area));
  }

  function temperatureColor(temp) {
    if (temp < 32) return "#32835b";
    if (temp < 36) return "#8eb85f";
    if (temp < 40) return "#c3ae4f";
    if (temp < 44) return "#d97843";
    return "#b64c54";
  }

  function activeFill(zone) {
    const temp = state.compare === "scenario" ? scenarioForZone(zone).temperature : zone.temp;
    const topLayer = state.layers[state.activeLayer] ? state.activeLayer : null;
    const riskColor = temperatureColor(temp);
    if (!topLayer) return "#254a4d";
    if (topLayer === "heat" || topLayer === "lst") return riskColor;
    if (topLayer === "landuse") {
      if (zone.industrial >= 23) return "#a65a50";
      if (zone.built >= 58) return "#bf8350";
      if (zone.veg >= 30) return "#438d65";
      return "#6c9370";
    }
    if (topLayer === "vegetation") return zone.veg >= 30 ? "#328a66" : zone.veg >= 20 ? "#6d9d60" : "#b47b4d";
    if (topLayer === "wind") return zone.wind >= 50 ? "#3dabb7" : zone.wind >= 43 ? "#528fa7" : "#797c8f";
    if (topLayer === "humidity") return zone.humidity >= 50 ? "#4c8ed1" : zone.humidity >= 43 ? "#5186a5" : "#817f72";
    return zone.population > 65000 ? "#bf65a4" : zone.population > 50000 ? "#a77ca6" : "#6986a0";
  }

  function renderHeader() {
    const baseline = averageTemperature(false);
    $("#citySelect").value = state.city;
    $("#headerTemp").textContent = `${averageTemperature().toFixed(1)}°C`;
    $("#headerRisk").textContent = riskForTemperature(averageTemperature()).label;
    $("#headerPopulation").textContent = city().population;
    $("#datasetDate").textContent = `DATASET · ${city().timestamp}`;
    $("#mapCityName").innerHTML = `${escapeHtml(city().name)} <span>·</span> <small>Illustrative neighbourhoods</small>`;
    $("#baselineMetric").textContent = `${baseline.toFixed(1)}°`;
    $("#predictedMetric").textContent = `${averageTemperature(true).toFixed(1)}°`;
    const reduction = baseline - averageTemperature(true);
    $("#reductionMetric").textContent = reduction > 0 && reduction < .05 ? "<0.1°" : `${reduction > 0 ? "−" : ""}${reduction.toFixed(1)}°`;
    $("#reductionMetric").setAttribute("aria-label", `${reduction.toFixed(1)} degrees Celsius illustrative city average reduction`);
    $("#afterCount").textContent = String(activeCount());
    $("#baselineButton").classList.toggle("selected", state.compare === "baseline");
    $("#scenarioButton").classList.toggle("selected", state.compare === "scenario");
    $("#baselineButton").setAttribute("aria-pressed", String(state.compare === "baseline"));
    $("#scenarioButton").setAttribute("aria-pressed", String(state.compare === "scenario"));
    $("#viewButton").setAttribute("aria-pressed", String(state.elevated));
    $("#undoButton").disabled = undoStack.length === 0;
    $("#redoButton").disabled = redoStack.length === 0;
  }

  function renderSolutions() {
    $("#solutionList").innerHTML = solutions.map((item) => `
      <div class="solution-card${state.pendingSolution === item.id ? " is-selected" : ""}" draggable="true" tabindex="0" role="button"
        aria-label="${escapeHtml(item.name)}. ${escapeHtml(item.short)} Indicative potential ${escapeHtml(item.band)}. Drag to map or press Enter to select."
        data-solution="${item.id}">
        <span class="solution-icon" aria-hidden="true">${item.icon}</span>
        <span class="solution-copy"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.short)}</small><span class="solution-impact">${escapeHtml(item.band)}</span></span>
        <span class="drag-grip" aria-hidden="true">⠿</span>
      </div>`).join("");
  }

  function renderLayerControls() {
    $("#layerList").innerHTML = layerDefinitions.map((layer) => `
      <button class="layer-toggle" type="button" data-layer="${layer.id}" aria-pressed="${state.layers[layer.id]}" aria-label="${state.layers[layer.id] ? "Hide" : "Show"} ${escapeHtml(layer.label)} layer">
        <span class="layer-check" aria-hidden="true">${state.layers[layer.id] ? "✓" : ""}</span><span>${escapeHtml(layer.label)}</span><i class="layer-swatch" style="--swatch:${layer.color}"></i>
      </button>`).join("");
  }

  function renderDecor() {
    $("#mapDecor").innerHTML = `
      <path class="river-line" d="M624 17 C610 92 655 116 624 186 C596 250 640 316 607 384 C584 430 615 485 588 603"/>
      <path class="river-edge" d="M624 17 C610 92 655 116 624 186 C596 250 640 316 607 384 C584 430 615 485 588 603"/>
      <path class="park-shape" d="M90 69 L134 65 L139 102 L98 111 Z"/><path class="park-shape" d="M338 74 L378 76 L374 102 L337 101 Z"/>
      <path class="park-shape" d="M615 87 L660 85 L663 114 L616 118 Z"/><path class="park-shape" d="M362 441 L405 444 L407 471 L359 469 Z"/>
      <path class="park-shape" d="M112 440 L151 438 L155 469 L115 472 Z"/>
      <path class="road-line" d="M32 202 C208 181 302 226 421 194 S681 180 869 214"/><path class="road-line" d="M42 397 C200 420 340 370 460 411 S711 428 862 393"/>
      <path class="road-line" d="M294 24 C319 156 275 282 314 393 S308 518 321 599"/><path class="road-line" d="M558 34 C535 162 577 271 550 394 S581 517 559 600"/>
      <path class="road-line minor" d="M58 141 C216 128 270 152 329 126 S513 98 600 137 S751 151 852 129"/>
      <path class="road-line minor" d="M82 287 C239 276 332 312 438 274 S660 288 829 268"/>
      <path class="road-line minor" d="M79 505 C208 491 287 534 405 500 S651 481 837 517"/>
      <path class="road-line minor" d="M201 34 C187 188 214 245 195 371 S213 512 198 588"/>
      <path class="road-line minor" d="M738 28 C724 173 755 278 724 392 S735 522 724 594"/>
      <text x="681" y="185" fill="#85c9c3" opacity=".65" font-size="8" font-family="DM Sans">RIVER CORRIDOR</text>
      <text x="113" y="95" fill="#b9dda0" opacity=".7" font-size="7" font-family="DM Sans">GREEN SPACE</text>`;
  }

  function renderMap() {
    const map = $("#cityMap");
    map.classList.toggle("is-elevated", state.elevated);
    setMapTransform();
    renderDecor();
    $("#zoneLayer").innerHTML = city().zones.map((zone) => {
      const shape = zoneShapes.find((item) => item.key === zone.id);
      const score = state.compare === "scenario" ? scenarioForZone(zone) : { temperature: zone.temp, reduction: 0 };
      const selected = state.selectedZone === zone.id ? " is-selected" : "";
      const displayTemp = score.temperature.toFixed(1);
      return `<g class="zone-group" data-zone-group="${zone.id}">
        <polygon class="zone-shape${selected}" data-zone="${zone.id}" points="${shape.points}" fill="${activeFill(zone)}" fill-opacity="${state.layers[state.activeLayer] ? ".74" : ".54"}" role="button" tabindex="0" aria-label="${escapeHtml(zone.name)}, ${displayTemp} degrees Celsius, ${riskForTemperature(score.temperature).label} heat stress. Select neighbourhood."/>
        <text class="zone-name" x="${shape.cx}" y="${shape.cy}">${escapeHtml(zone.name)}</text>
        <text class="zone-temp-label" x="${shape.cx}" y="${shape.cy + 18}">${displayTemp}° · ${riskForTemperature(score.temperature).label}</text>
      </g>`;
    }).join("");
    $("#roadLayer").innerHTML = `<path class="road-line" d="M32 202 C208 181 302 226 421 194 S681 180 869 214"/><path class="road-line" d="M42 397 C200 420 340 370 460 411 S711 428 862 393"/><path class="road-line" d="M294 24 C319 156 275 282 314 393 S308 518 321 599"/><path class="road-line" d="M558 34 C535 162 577 271 550 394 S581 517 559 600"/>`;
    $("#hotspotLayer").innerHTML = city().hotspots.map((hotspot, index) => {
      const name = zoneById(hotspot.zone)?.name || "Neighbourhood";
      return `<g class="hotspot-marker" data-hotspot-zone="${hotspot.zone}" role="button" tabindex="0" aria-label="${hotspot.severity} heat hotspot in ${escapeHtml(name)}. View details.">
        <circle cx="${hotspot.x}" cy="${hotspot.y}" r="27" fill="transparent" pointer-events="all"/><circle class="map-halo" cx="${hotspot.x}" cy="${hotspot.y}" r="15"/><circle class="hotspot-dot" cx="${hotspot.x}" cy="${hotspot.y}" r="6"/><circle class="hotspot-core" cx="${hotspot.x}" cy="${hotspot.y}" r="2"/>
        ${index < 4 ? `<text class="hotspot-label" x="${hotspot.x + 11}" y="${hotspot.y - 7}">${escapeHtml(hotspot.severity.toUpperCase())}</text>` : ""}
      </g>`;
    }).join("");
    $("#placementLayer").innerHTML = state.placements.map((placement) => {
      const item = solution(placement.type);
      const label = `${item.name}, ${placement.quantity} units, ${zoneById(placement.zoneId)?.name || "neighbourhood"}${placement.enabled === false ? ", disabled" : ""}. Open configuration.`;
      return `<g class="placement-pin${placement.enabled === false ? " disabled" : ""}" data-placement="${placement.id}" role="button" tabindex="0" aria-label="${escapeHtml(label)}">
        <circle class="pin-circle" cx="${placement.x}" cy="${placement.y}" r="12"/><text class="pin-icon" x="${placement.x}" y="${placement.y + 1}">${item.icon}</text>
        <text class="pin-count" x="${placement.x + 9}" y="${placement.y - 9}">${placement.quantity > 99 ? "99+" : placement.quantity}</text>
      </g>`;
    }).join("");
    $("#mapLabels").innerHTML = "";
    $("#mapStatusText").textContent = `${state.layers[state.activeLayer] ? layerDefinitions.find((layer) => layer.id === state.activeLayer)?.label : "No overlay"} · ${state.compare === "baseline" ? "Baseline" : "Illustrative scenario"}`;
    $("#mapInstructions").classList.toggle("visible", Boolean(state.pendingSolution || state.movingPlacement));
    $("#mapInstructions").textContent = state.movingPlacement
      ? "Click a new map location to reposition this solution."
      : state.pendingSolution ? `Tap a neighbourhood to place ${solution(state.pendingSolution).name}. Press Enter on the map to place in the selected zone.` : "";
    renderLegend();
    renderZoneCard();
  }

  function renderLegend() {
    if (!state.layers[state.activeLayer]) {
      $("#mapLegend").innerHTML = `<span class="legend-title">No overlay</span><span class="legend-item">Neighbourhood outlines only</span>`;
      return;
    }
    const layer = layerDefinitions.find((item) => item.id === state.activeLayer);
    let legendItems;
    if (state.activeLayer === "vegetation") legendItems = [["<15%", "#b47b4d"], ["15–29%", "#6d9d60"], ["30%+", "#328a66"]];
    else if (state.activeLayer === "wind") legendItems = [["Lower", "#797c8f"], ["Moderate", "#528fa7"], ["Higher", "#3dabb7"]];
    else if (state.activeLayer === "humidity") legendItems = [["<40%", "#817f72"], ["40–49%", "#5186a5"], ["50%+", "#4c8ed1"]];
    else if (state.activeLayer === "landuse") legendItems = [["Built-up", "#bf8350"], ["Green", "#438d65"], ["Industrial", "#a65a50"]];
    else if (state.activeLayer === "population") legendItems = [["Lower", "#6986a0"], ["Medium", "#a77ca6"], ["Higher", "#bf65a4"]];
    else legendItems = [["<32°", "#32835b"], ["32–36°", "#8eb85f"], ["36–40°", "#c3ae4f"], ["40–44°", "#d97843"], [">44°", "#b64c54"]];
    $("#mapLegend").innerHTML = `<span class="legend-title">${escapeHtml(layer?.label || "Heat risk")}</span>${legendItems.map(([label, color]) => `<span class="legend-item"><i class="legend-swatch" style="background:${color}"></i>${label}</span>`).join("")}`;
  }

  function renderZoneCard() {
    const zone = currentZone();
    if (!zone) { $("#zoneCard").innerHTML = ""; return; }
    const scenario = scenarioForZone(zone);
    const temp = state.compare === "scenario" ? scenario.temperature : zone.temp;
    const risk = riskForTemperature(temp);
    const drivers = [
      ["Built surfaces", zone.drivers[0]], ["Low vegetation", zone.drivers[1]], ["Traffic / industry", zone.drivers[2]], ["Other context", zone.drivers[3]]
    ].sort((a, b) => b[1] - a[1]).slice(0, 2).map(([name]) => name.toLowerCase()).join(" · ");
    $("#zoneCard").innerHTML = `<div class="zone-card-head"><div><div class="zone-card-name">${escapeHtml(zone.name)}</div><span class="zone-risk ${risk.className}">${risk.label} heat stress</span></div><button class="zone-card-close" aria-label="Close neighbourhood details">×</button></div>
      <div class="zone-stat-row"><span>Illustrative temperature</span><strong>${temp.toFixed(1)}°C</strong></div>
      <div class="zone-stat-row"><span>Population context</span><strong>${zone.population.toLocaleString()}</strong></div>
      <div class="zone-card-drivers">Key demo drivers: ${escapeHtml(drivers)}.</div>
      <div class="zone-card-actions"><button data-zone-place="${zone.id}">＋ Add solution here</button><button data-zone-list>All zones</button></div>`;
  }

  function renderAnalytics() {
    const zone = currentZone();
    const drivers = weightedDriverMix(zone);
    const labels = ["Built surfaces", "Low vegetation", "Traffic / industry", "Other context"];
    $("#hotspotTitle").textContent = zone ? `${zone.name} · key drivers` : "City overview · key drivers";
    $("#driverList").innerHTML = labels.map((label, index) => `<div class="driver-row"><span>${label}</span><span class="driver-track"><span style="width:${drivers[index]}%"></span></span><b>${drivers[index]}%</b></div>`).join("");
    $("#exposureNote").textContent = zone
      ? `${zone.population.toLocaleString()} people in demo exposure context · illustrative drivers`
      : "Citywide illustrative driver mix · select a neighbourhood for details.";
    const baseline = averageTemperature(false);
    const after = averageTemperature(true);
    $("#predictionNote").textContent = state.placements.length
      ? `${activeCount()} active solution${activeCount() === 1 ? "" : "s"} across ${new Set(state.placements.filter((item) => item.enabled !== false).map((item) => item.zoneId)).size} neighbourhood${new Set(state.placements.filter((item) => item.enabled !== false).map((item) => item.zoneId)).size === 1 ? "" : "s"} · ${baseline - after > 0 && baseline - after < .05 ? "citywide change is below the 0.1° display increment; local zones update." : "area-weighted illustrative estimate."}`
      : "Place interventions to estimate a localised scenario.";
    const benefits = scenarioBenefits();
    $("#co2Metric").textContent = benefits.co2 ? `${benefits.co2.toFixed(1)} t` : "—";
    $("#energyMetric").textContent = benefits.energy ? `${benefits.energy.toFixed(1)} MWh` : "—";
    $("#waterMetric").textContent = benefits.water ? `${Math.round(benefits.water * 100)} m³` : "—";
    $("#comfortMetric").textContent = String(benefits.comfort);
    const activePlacements = state.placements.filter((item) => item.enabled !== false);
    const planCount = activePlacements.length;
    $("#planTabCount").textContent = String(planCount);
    $("#planSummaryTitle").textContent = planCount ? `${planCount} draft action${planCount === 1 ? "" : "s"}` : "Ready when you are";
    $("#planSummaryBody").innerHTML = planCount
      ? `<span class="plan-summary-mark">${String(planCount).padStart(2, "0")}</span><span>${new Set(activePlacements.map((item) => item.zoneId)).size} neighbourhood${new Set(activePlacements.map((item) => item.zoneId)).size === 1 ? "" : "s"} · ${state.planGenerated ? "Plan generated" : "Generate a phased draft"}</span>`
      : `<span class="plan-summary-mark">01</span><span>Place a solution to draft a neighbourhood action plan.</span>`;
    $("#analyticsPlanButton").textContent = state.planGenerated ? "Review action plan →" : "Open action plan →";
    $("#analyticsPlanButton").setAttribute("aria-label", state.planGenerated ? "Review generated action plan" : "Open action plan");
    renderPlan();
  }

  function renderPlan() {
    const activePlacements = state.placements.filter((item) => item.enabled !== false);
    $("#planEmpty").hidden = state.planGenerated && activePlacements.length > 0;
    $("#planContent").hidden = !(state.planGenerated && activePlacements.length > 0);
    $("#planActions").hidden = !(state.planGenerated && activePlacements.length > 0);
    if (!state.planGenerated || !activePlacements.length) return;
    const groups = new Map();
    for (const item of activePlacements) {
      const key = item.type;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(item);
    }
    const rows = Array.from(groups.entries()).map(([typeId, items]) => {
      const type = solution(typeId);
      const zoneNames = [...new Set(items.map((item) => zoneById(item.zoneId)?.name || "Neighbourhood"))];
      return { typeId, type, items, zoneNames, count: items.reduce((sum, item) => sum + Number(item.quantity), 0) };
    }).sort((a, b) => b.type.weight - a.type.weight);
    const phases = [
      { title: "Phase 1 · Prepare & pilot", duration: "Months 0–6", rows: rows.filter((_, index) => index < Math.ceil(rows.length / 2)) },
      { title: "Phase 2 · Deliver & maintain", duration: "Months 6–18", rows: rows.filter((_, index) => index >= Math.ceil(rows.length / 2)) }
    ].filter((phase) => phase.rows.length);
    $("#planContent").innerHTML = `<div class="plan-content-head"><span class="eyebrow">DRAFT · ${escapeHtml(city().name.toUpperCase())}</span><h3>Neighbourhood cooling plan</h3><p>${rows.length} work package${rows.length === 1 ? "" : "s"} across ${new Set(state.placements.map((item) => item.zoneId)).size} area${new Set(state.placements.map((item) => item.zoneId)).size === 1 ? "" : "s"}. Quantities and timelines are indicative only.</p></div>
      ${phases.map((phase, phaseIndex) => `<div class="plan-phase"><div class="plan-phase-heading"><span class="phase-index">${phaseIndex + 1}</span><span>${phase.title}</span><span style="margin-left:auto;color:#829b9b;font-size:7px">${phase.duration}</span></div>
        ${phase.rows.map((row) => `<div class="plan-item"><strong>${row.type.icon} ${escapeHtml(row.type.name)} · ${row.count} units</strong><small>${escapeHtml(row.zoneNames.join(", "))}<br>${escapeHtml(row.type.time)} · ${escapeHtml(row.type.role)}<br>${row.typeId === "trees" ? "Coordinate planting sites and species suitability before installation." : "Confirm site suitability, maintenance and local approvals before delivery."}</small></div>`).join("")}</div>`).join("")}
      <p class="card-footnote">Draft only. Confirm site conditions, dependencies, permissions and costs with local teams.</p>`;
  }

  function renderScore() {
    const score = state.score;
    const level = Math.floor(score / 100) + 1;
    const levelNames = ["Explorer", "Heat mapper", "Cool-city planner", "Climate champion"];
    const name = levelNames[Math.min(level - 1, levelNames.length - 1)];
    $("#plannerLevel").textContent = `Level ${level} · ${name}`;
    $("#scoreValue").textContent = `${score} pts`;
    $("#scoreProgress").style.width = `${Math.min(100, score % 100)}%`;
    $("#scoreGoal").textContent = `${score % 100} / 100`;
    $("#badgeText").textContent = state.badges.includes("scenario") ? "Scenario builder badge earned" : state.badges.includes("first-solution") ? "First solution badge earned" : "Your first action is waiting";
  }

  function renderChat() {
    const welcome = {
      role: "assistant",
      time: timeNow(),
      text: `Welcome to NexTerra. I can help you explore illustrative heat patterns in ${city().name}, compare cooling ideas, and draft a neighbourhood action plan. What would you like to look at?`
    };
    const messages = state.chat.length ? state.chat : [welcome];
    $("#chatMessages").innerHTML = messages.map((message, index) => {
      const isUser = message.role === "user";
      const content = escapeHtml(message.text);
      const action = !isUser && message.action === "add-recommendations"
        ? `<button type="button" class="message-action" data-assistant-action="add-recommendations">Confirm & add 3 solutions</button>`
        : !isUser && message.action === "generate-plan"
          ? `<button type="button" class="message-action" data-assistant-action="generate-plan">Create my action plan</button>` : "";
      return `<article class="chat-message${isUser ? " user" : ""}" data-message-index="${index}">
        <span class="message-avatar">${isUser ? "DP" : "✦"}</span><div class="message-body"><div class="message-meta"><strong>${isUser ? "You" : "Terra"}</strong><time>${escapeHtml(message.time || timeNow())}</time></div>
          <div class="message-bubble">${content}${action}</div></div></article>`;
    }).join("") + (chatBusy ? `<div class="typing-indicator" role="status">Terra is thinking<span>.</span><span>.</span><span>.</span></div>` : "");
    $("#chatMessages").scrollTop = $("#chatMessages").scrollHeight;
    $("#chatForm").querySelector("button").disabled = chatBusy;
  }

  function renderAll() {
    renderHeader();
    renderSolutions();
    renderLayerControls();
    renderMap();
    renderAnalytics();
    renderScore();
    renderChat();
    persistState();
  }

  function svgPointFromEvent(event) {
    const map = $("#cityMap");
    const point = map.createSVGPoint();
    point.x = event.clientX;
    point.y = event.clientY;
    const matrix = map.getScreenCTM();
    if (!matrix) return { x: 450, y: 310 };
    const mapped = point.matrixTransform(matrix.inverse());
    return { x: Math.max(55, Math.min(845, mapped.x)), y: Math.max(35, Math.min(590, mapped.y)) };
  }

  function setMapTransform() {
    const tilt = state.elevated ? "perspective(1000px) rotateX(7deg) " : "";
    $("#cityMap").style.transform = `translate(${state.panX || 0}px, ${state.panY || 0}px) ${tilt}scale(${state.zoom})`;
  }

  function validateTarget(typeId, zone, x) {
    if (typeId === "water" && zone.water < 10 && !(x >= 580 && x <= 665)) {
      return `Water-body projects need a lake or water-adjacent site. Try ${city().zones.filter((item) => item.water >= 10).map((item) => item.name).join(" or ")}.`;
    }
    if (["cool-roofs", "solar", "green-roofs", "vertical"].includes(typeId) && zone.built < 45) {
      return `${solution(typeId).name} needs a suitable built-up or roof area. Try a denser neighbourhood such as ${city().zones.filter((item) => item.built >= 55).map((item) => item.name).slice(0, 2).join(" or ")}.`;
    }
    return null;
  }

  function closestZone(x, y) {
    let closest = city().zones[0];
    let distance = Number.POSITIVE_INFINITY;
    for (const zone of city().zones) {
      const shape = zoneShapes.find((item) => item.key === zone.id);
      const current = Math.hypot(shape.cx - x, shape.cy - y);
      if (current < distance) { distance = current; closest = zone; }
    }
    return closest;
  }

  function rememberPlacements() {
    undoStack.push(JSON.stringify(state.placements));
    if (undoStack.length > 25) undoStack.shift();
    redoStack = [];
  }

  function updatePlacements(placements, options = {}) {
    if (options.history !== false) rememberPlacements();
    state.placements = placements;
    state.selectedPlacement = null;
    if (!placements.length) state.planGenerated = false;
    renderAll();
  }

  function awardPoints(points, badge) {
    state.score += points;
    if (badge && !state.badges.includes(badge)) state.badges.push(badge);
  }

  function createPlacement(typeId, x, y, zone) {
    const type = solution(typeId);
    if (!type || !zone) return;
    const targetError = validateTarget(typeId, zone, x);
    if (targetError) {
      showToast(targetError, true);
      return;
    }
    const placement = {
      id: `place-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
      type: typeId, x: Math.round(x), y: Math.round(y), zoneId: zone.id, quantity: typeId === "trees" ? 20 : 1, enabled: true
    };
    const first = state.placements.length === 0;
    updatePlacements([...state.placements, placement]);
    state.pendingSolution = null;
    state.selectedZone = zone.id;
    state.selectedPlacement = placement.id;
    if (first) awardPoints(25, "first-solution");
    state.planGenerated = false;
    renderAll();
    openPlacementDialog(placement.id);
    if (first) showToast("First solution placed · 25 demo points earned.");
    else showToast(`${type.name} placed in ${zone.name}.`);
  }

  function placePendingAt(x, y, zone = null) {
    if (state.movingPlacement) {
      const placement = state.placements.find((item) => item.id === state.movingPlacement);
      if (!placement) { state.movingPlacement = null; renderAll(); return; }
      const targetZone = zone || closestZone(x, y);
      const targetError = validateTarget(placement.type, targetZone, x);
      if (targetError) {
        showToast(targetError, true);
        return;
      }
      rememberPlacements();
      state.placements = state.placements.map((item) => item.id === placement.id
        ? { ...item, x: Math.round(x), y: Math.round(y), zoneId: targetZone.id } : item);
      state.selectedZone = targetZone.id;
      state.selectedPlacement = placement.id;
      state.movingPlacement = null;
      state.planGenerated = false;
      renderAll();
      showToast(`Solution moved to ${targetZone.name}.`);
      openPlacementDialog(placement.id);
      return;
    }
    if (!state.pendingSolution) return;
    const targetZone = zone || closestZone(x, y);
    createPlacement(state.pendingSolution, x, y, targetZone);
  }

  function selectPendingSolution(id) {
    state.pendingSolution = state.pendingSolution === id ? null : id;
    state.movingPlacement = null;
    if (state.pendingSolution) {
      $("#mapStage").classList.add("is-drop-target");
      window.setTimeout(() => $("#mapStage").classList.remove("is-drop-target"), 1500);
      showToast(`Select a neighbourhood on the map to place ${solution(id).name}.`);
    }
    renderAll();
    if (state.pendingSolution) $("#cityMap").focus({ preventScroll: true });
  }

  function undo() {
    if (!undoStack.length) return;
    redoStack.push(JSON.stringify(state.placements));
    state.placements = JSON.parse(undoStack.pop());
    state.selectedPlacement = null;
    state.planGenerated = false;
    renderAll();
    showToast("Last scenario change undone.");
  }

  function redo() {
    if (!redoStack.length) return;
    undoStack.push(JSON.stringify(state.placements));
    state.placements = JSON.parse(redoStack.pop());
    state.selectedPlacement = null;
    state.planGenerated = false;
    renderAll();
    showToast("Scenario change restored.");
  }

  function dialogOpen(content) {
    $("#dialogContent").innerHTML = content;
    const dialog = $("#appDialog");
    if (!dialog.open) dialog.showModal();
  }

  function dialogClose() {
    if ($("#appDialog").open) $("#appDialog").close();
  }

  function openPlacementDialog(id) {
    const placement = state.placements.find((item) => item.id === id);
    if (!placement) return;
    const type = solution(placement.type);
    const zone = zoneById(placement.zoneId);
    state.selectedPlacement = id;
    dialogOpen(`<span class="dialog-content-eyebrow">SOLUTION CONFIGURATION · ${escapeHtml(zone?.name || "Neighbourhood")}</span>
      <h2 class="dialog-content-title">${type.icon} ${escapeHtml(type.name)}</h2>
      <p class="dialog-content-copy">${escapeHtml(type.short)} Indicative impact band: <strong>${escapeHtml(type.band)}</strong>. Local results depend on placement, design, area and maintenance.</p>
      <div class="field-row"><div class="field-group"><label for="quantityInput">Quantity / scale</label><input id="quantityInput" type="number" min="1" max="500" step="1" value="${placement.quantity}" required><div class="field-help">Illustrative units for this demo placement.</div></div>
      <div class="field-group"><label for="statusInput">Scenario status</label><select id="statusInput"><option value="enabled"${placement.enabled !== false ? " selected" : ""}>Active in scenario</option><option value="disabled"${placement.enabled === false ? " selected" : ""}>Disabled</option></select><div class="field-help">Disabled items remain visible but are excluded.</div></div></div>
      <div class="field-group"><label>Suitable targets</label><p class="field-help">${escapeHtml(type.valid)} · ${escapeHtml(type.time)} · ${escapeHtml(type.role)}</p></div>
      <div class="dialog-actions"><button class="dialog-primary" type="button" data-placement-save="${id}">Save configuration</button><button class="dialog-secondary" type="button" data-placement-move="${id}">Move on map</button><button class="dialog-secondary" type="button" data-placement-duplicate="${id}">Duplicate</button><button class="dialog-secondary" type="button" data-placement-remove="${id}">Remove</button></div>`);
  }

  function generatePlan() {
    if (!activeCount()) {
      showToast("Place at least one solution on the map before generating a plan.", true);
      return;
    }
    const wasGenerated = state.planGenerated;
    state.planGenerated = true;
    state.compare = "scenario";
    if (!wasGenerated) awardPoints(25, "scenario");
    renderAll();
    switchAssistantTab("plan");
    showToast(wasGenerated ? "Action plan refreshed to match your scenario." : "Draft action plan generated · 25 demo points earned.");
  }

  function switchAssistantTab(tab) {
    const assistantSelected = tab === "assistant";
    $("#assistantTab").classList.toggle("active", assistantSelected);
    $("#plannerTab").classList.toggle("active", !assistantSelected);
    $("#assistantTab").setAttribute("aria-selected", String(assistantSelected));
    $("#plannerTab").setAttribute("aria-selected", String(!assistantSelected));
    $("#chatView").hidden = !assistantSelected;
    $("#planView").hidden = assistantSelected;
    if (!assistantSelected && state.planGenerated) renderPlan();
  }

  function addChatMessage(role, text, action = null) {
    state.chat.push({ role, text, action, time: timeNow() });
    if (state.chat.length > 40) state.chat = state.chat.slice(-40);
  }

  function answerAssistant(question) {
    const lower = question.toLowerCase();
    const zone = currentZone();
    const placeNames = [...new Set(state.placements.map((item) => solution(item.type).name))];
    const count = activeCount();
    const selectedName = zone ? zone.name : "the selected city";
    const temp = zone ? (state.compare === "scenario" ? scenarioForZone(zone).temperature : zone.temp) : averageTemperature();
    const risk = riskForTemperature(temp).label.toLowerCase();
    if (/recommend|combination|what should|what would|suggest|practical/.test(lower)) {
      return {
        text: `For ${selectedName} in ${city().name}, consider tree planting for shade, cool roofs on suitable buildings, and a small park where land and community access permit. These illustrative options address different surfaces and can complement one another, but their effects are local, uncertain and not directly additive. Would you like me to add a draft mix to the map for your review?`,
        action: "add-recommendations"
      };
    }
    if (/compare|versus|\bvs\b|tree.*roof|roof.*tree/.test(lower)) {
      return { text: `Tree planting prioritises shade, habitat and street comfort; establishment takes time and requires species choice, irrigation and maintenance. Cool roofs can be quicker on suitable buildings and may reduce roof heat gain, but need building-owner coordination. In this demo, each has an illustrative local impact band—not a guaranteed or directly comparable result. Your current scenario has ${count} active solution${count === 1 ? "" : "s"}${placeNames.length ? ` (${placeNames.join(", ")})` : ""}.` };
    }
    if (/assumption|how.*estimate|method|calculation|accurate|certainty/.test(lower)) {
      return { text: `This is a transparent rules-based demo, not a physical climate model. Each active solution contributes a small type-specific score in its assigned neighbourhood, scaled by quantity; combined returns diminish and local cooling is capped at 1.4°C. City averages are area-weighted, so unaffected neighbourhoods retain their baseline. Co-benefits use illustrative factors. Real outcomes depend on design, local climate, maintenance and site conditions.` };
    }
    if (/plan|implementation|timeline|phase|generate/.test(lower)) {
      if (!state.placements.length) return { text: `I can draft a phased plan once you place at least one solution. Choose a toolbox card and select a neighbourhood on the map; then I can organise the work packages by indicative timeline and responsible stakeholder.` };
      return { text: `Your current draft includes ${count} active solution${count === 1 ? "" : "s"} across ${new Set(state.placements.map((item) => item.zoneId)).size} neighbourhood${new Set(state.placements.map((item) => item.zoneId)).size === 1 ? "" : "s"}. I can turn them into a phased, indicative work plan. You can review it before exporting.`, action: "generate-plan" };
    }
    if (/impact|cool|reduc|scenario|after|temperature/.test(lower)) {
      const baseline = averageTemperature(false);
      const after = averageTemperature(true);
      const local = zone ? scenarioForZone(zone) : null;
      return { text: count
        ? `The illustrative area-weighted city average moves from ${baseline.toFixed(1)}°C to ${after.toFixed(1)}°C (about ${(baseline - after).toFixed(1)}°C lower in this rules-based scenario).${local ? ` In ${zone.name}, the demo estimate is ${zone.temp.toFixed(1)}°C baseline and ${local.temperature.toFixed(1)}°C after ${local.count} local intervention${local.count === 1 ? "" : "s"}.` : ""} This is not a validated forecast; neighbourhood placement and local conditions matter.`
        : `There is no intervention scenario yet. The illustrative city average is ${baseline.toFixed(1)}°C. Place a solution on the map to compare an area-weighted estimate; it will not assume a citywide temperature reduction.` };
    }
    if (/hottest|hotspot|why.*hot|driver|heat stress|explain this/.test(lower)) {
      const hottest = city().zones.reduce((hot, item) => item.temp > hot.temp ? item : hot, city().zones[0]);
      const target = zone || hottest;
      const targetTemp = state.compare === "scenario" ? scenarioForZone(target).temperature : target.temp;
      const topDrivers = [
        ["built surfaces", target.drivers[0]], ["low vegetation", target.drivers[1]], ["traffic / industry", target.drivers[2]], ["other local context", target.drivers[3]]
      ].sort((a, b) => b[1] - a[1]).slice(0, 2);
      return { text: `${target.name} is shown at ${targetTemp.toFixed(1)}°C with ${riskForTemperature(targetTemp).label.toLowerCase()} demo heat stress. The illustrative driver mix highlights ${topDrivers[0][0]} (${topDrivers[0][1]}%) and ${topDrivers[1][0]} (${topDrivers[1][1]}%). These are seeded demo shares, not validated local measurements. Consider the ${target.population.toLocaleString()} population-context figure alongside shade, access and community needs.` };
    }
    if (/summari|municipal|officer|brief/.test(lower)) {
      return { text: `${city().name} demo briefing: the citywide illustrative baseline average is ${averageTemperature(false).toFixed(1)}°C, with ${count} active intervention${count === 1 ? "" : "s"}${placeNames.length ? ` (${placeNames.join(", ")})` : ""} across ${new Set(state.placements.map((item) => item.zoneId)).size} neighbourhood${new Set(state.placements.map((item) => item.zoneId)).size === 1 ? "" : "s"}. The current rules-based scenario average is ${averageTemperature(true).toFixed(1)}°C. Treat these outputs as discussion prompts; verify priorities, feasibility, costs and outcomes with local data and stakeholders.` };
    }
    if (/layer|vegetation|wind|humidity|land use|population/.test(lower)) {
      return { text: `The active map layer is ${layerDefinitions.find((item) => item.id === state.activeLayer)?.label || "Heat map"}. The layer controls show independent illustrative overlays for land surface temperature, land use, vegetation, wind, humidity and population context. Select a neighbourhood to see its seeded values and drivers.` };
    }
    return { text: `I can help explain a hotspot, identify demo heat drivers, recommend or compare interventions, estimate your scenario, explain assumptions, or draft a municipal action plan. I’m using ${city().name}${zone ? ` and the ${zone.name} neighbourhood` : ""} context, with ${count} active intervention${count === 1 ? "" : "s"}. What would you like to explore?` };
  }

  function sendAssistantMessage(text) {
    const question = text.trim();
    if (!question || chatBusy) return;
    addChatMessage("user", question);
    chatBusy = true;
    renderChat();
    $("#chatInput").value = "";
    window.setTimeout(() => {
      const response = answerAssistant(question);
      chatBusy = false;
      addChatMessage("assistant", response.text, response.action || null);
      renderChat();
      persistState();
    }, 360);
  }

  function applyRecommendations() {
    const zone = currentZone() || city().zones.reduce((hot, item) => item.temp > hot.temp ? item : hot, city().zones[0]);
    const shape = zoneShapes.find((item) => item.key === zone.id);
    const choices = [
      { type: "trees", x: shape.cx - 37, y: shape.cy + 15, quantity: 20 },
      { type: "cool-roofs", x: shape.cx + 34, y: shape.cy - 23, quantity: 8 },
      { type: "parks", x: shape.cx + 3, y: shape.cy + 46, quantity: 1 }
    ];
    rememberPlacements();
    const additions = choices.map((choice, index) => ({
      id: `place-${Date.now().toString(36)}-${index}-${Math.random().toString(36).slice(2, 5)}`,
      type: choice.type, x: choice.x, y: choice.y, zoneId: zone.id, quantity: choice.quantity, enabled: true
    }));
    const first = state.placements.length === 0;
    state.placements = [...state.placements, ...additions];
    state.selectedZone = zone.id;
    state.selectedPlacement = null;
    state.pendingSolution = null;
    state.planGenerated = false;
    if (first) awardPoints(25, "first-solution");
    addChatMessage("assistant", `Added a reviewable draft mix—tree planting, cool roofs and a small park—in ${zone.name}. These illustrative placements are not site-approved; open each marker to adjust quantities, move or remove it.`, null);
    renderAll();
    showToast("Three reviewable draft solutions added to the map.");
  }

  function downloadCsv(filename, rows) {
    const quote = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
    const text = rows.map((row) => row.map(quote).join(",")).join("\r\n");
    try {
      const blob = new Blob(["\uFEFF", text], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.append(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1200);
      showToast(`${filename} downloaded.`);
    } catch (error) {
      console.error("CSV export failed:", error);
      showToast(`Could not create ${filename}. Your scenario is unchanged; try the download again.`, true);
    }
  }

  function interventionRows() {
    const rows = [["Intervention ID", "Type", "Neighbourhood", "Quantity / scale", "Footprint", "Indicative impact band", "Timeline", "Dependencies / notes", "Status", "Data note"]];
    state.placements.forEach((item, index) => {
      const type = solution(item.type);
      rows.push([item.id || `NXT-${index + 1}`, type.name, zoneById(item.zoneId)?.name || "Neighbourhood", item.quantity, "Illustrative local placement", type.band, type.time, type.valid, item.enabled === false ? "Disabled" : "Draft", "Illustrative demo data"]);
    });
    return rows;
  }

  function zoneRows() {
    const rows = [["Zone", "Baseline temperature (°C)", "Baseline risk", "Scenario temperature (°C)", "Scenario risk", "Exposed population context", "Dataset timestamp", "Data note"]];
    city().zones.forEach((zone) => {
      const predicted = scenarioForZone(zone).temperature;
      rows.push([zone.name, zone.temp.toFixed(1), riskForTemperature(zone.temp).label, predicted.toFixed(1), riskForTemperature(predicted).label, zone.population, city().timestamp, "Illustrative demo data; not live"]);
    });
    return rows;
  }

  function printReportMarkup() {
    const baseline = averageTemperature(false);
    const predicted = averageTemperature(true);
    const active = state.placements.filter((item) => item.enabled !== false);
    const rows = active.map((item) => {
      const type = solution(item.type);
      return `<tr><td>${escapeHtml(type.name)}</td><td>${escapeHtml(zoneById(item.zoneId)?.name || "Neighbourhood")}</td><td>${item.quantity}</td><td>${escapeHtml(type.time)}</td><td>${escapeHtml(type.role)}</td></tr>`;
    }).join("");
    const zoneTable = city().zones.map((zone) => `<tr><td>${escapeHtml(zone.name)}</td><td>${zone.temp.toFixed(1)}°C · ${riskForTemperature(zone.temp).label}</td><td>${scenarioForZone(zone).temperature.toFixed(1)}°C · ${riskForTemperature(scenarioForZone(zone).temperature).label}</td><td>${zone.population.toLocaleString()}</td></tr>`).join("");
    const planText = state.planGenerated ? "Draft action plan generated from the currently placed solutions. Confirm site suitability, local dependencies, costs and approvals before implementation." : "No implementation plan has been generated. This report contains the current scenario placements.";
    return `<div class="print-kicker">NEX TERRA · URBAN HEAT PLANNING DEMO</div>
      <h1>${escapeHtml(city().name)} cooling scenario</h1>
      <p class="print-meta">Generated ${new Date().toLocaleString()} · Illustrative neighbourhood dataset · Dataset ${escapeHtml(city().timestamp)}</p>
      <div class="print-disclaimer"><strong>Demo data — illustrative, not live or engineering-certified.</strong><br>Temperatures, population context, impact estimates and co-benefits in this report are synthetic scenario values, not verified observations or forecasts.</div>
      <section class="print-report-section"><h2>Scenario summary</h2><table><thead><tr><th>Metric</th><th>Baseline</th><th>Illustrative scenario</th></tr></thead><tbody>
      <tr><td>Area-weighted city average</td><td>${baseline.toFixed(1)}°C</td><td>${predicted.toFixed(1)}°C</td></tr>
      <tr><td>Active placed solutions</td><td>—</td><td>${active.length}</td></tr>
      <tr><td>Neighbourhoods with active solutions</td><td>—</td><td>${new Set(active.map((item) => item.zoneId)).size}</td></tr></tbody></table><p>${escapeHtml(planText)}</p></section>
      <section class="print-report-section"><h2>Intervention register</h2><table><thead><tr><th>Solution</th><th>Neighbourhood</th><th>Quantity</th><th>Indicative timing</th><th>Responsible role</th></tr></thead><tbody>${rows || `<tr><td colspan="5">No interventions placed.</td></tr>`}</tbody></table></section>
      <section class="print-report-section"><h2>Neighbourhood metrics</h2><table><thead><tr><th>Neighbourhood</th><th>Baseline</th><th>Scenario</th><th>Population context</th></tr></thead><tbody>${zoneTable}</tbody></table></section>
      <section class="print-report-section"><h2>How to interpret this estimate</h2><p>The demo uses a deterministic rules engine. Illustrative cooling contributions are type-weighted, scaled by quantity, diminished when combined and capped at 1.4°C within each affected neighbourhood. City averages are area-weighted; unaffected neighbourhoods retain baseline values. Co-benefit figures are illustrative factors, not validated engineering predictions.</p><p>Actual outcomes depend on local climate, site design, materials, water availability, species suitability, construction, operations and maintenance. Validate with qualified local teams and current data.</p></section>
      <div class="print-footer">NexTerra interactive urban heat-planning demo · Synthetic geometry and seeded sample values · Not for engineering, procurement or public-health decisions.</div>`;
  }

  function openPrintReport() {
    $("#printReport").innerHTML = printReportMarkup();
    document.body.classList.add("printing");
    showToast("Print-ready report opened. Choose “Save as PDF” in the print dialog.");
    window.setTimeout(() => window.print(), 80);
  }

  function showTutorial() {
    tourStep = 0;
    renderTutorial();
  }

  function renderTutorial() {
    const steps = [
      { eyebrow: "WELCOME TO NEX TERRA", title: "Make urban heat actionable", copy: "Explore a schematic heat map, inspect a neighbourhood and test a practical cooling scenario. Every value is illustrative—not a live measurement or validated forecast.", list: ["Bengaluru and Vadodara demo cities", "Seven independent map overlays", "A deterministic, transparent scenario engine"] },
      { eyebrow: "STEP 1 OF 3", title: "Explore the heat map", copy: "Choose a hotspot or neighbourhood to inspect its demo temperature, heat-stress category, exposure context and seeded drivers. Toggle the map layers to compare local context.", list: ["Use the controls to zoom and switch views", "Keyboard: Tab to a neighbourhood and press Enter", "Use the accessible zone list when you prefer a table"] },
      { eyebrow: "STEP 2 OF 3", title: "Place and compare solutions", copy: "Drag any toolbox card onto the map, or select a card and click a neighbourhood. Open a marker to change its quantity, disable, duplicate, move or remove it.", list: ["Tap-to-place works on touch devices", "Undo / redo with the toolbar or Ctrl+Z / Ctrl+Y", "Scenario reductions are localised, diminishing and capped"] },
      { eyebrow: "STEP 3 OF 3", title: "Plan, ask and export", copy: "Ask Terra for contextual guidance, confirm any suggested placements, generate a phased action plan, then export CSVs or a print-ready report.", list: ["Review indicative timeline and responsible roles", "Exports include scenario assumptions and demo labels", "Use Reset demo to return to the clean starting state"] }
    ];
    const step = steps[tourStep];
    const last = tourStep === steps.length - 1;
    dialogOpen(`<span class="dialog-content-eyebrow">${step.eyebrow}</span><h2 class="dialog-content-title">${step.title}</h2><p class="dialog-content-copy">${step.copy}</p>
      <ul class="dialog-list">${step.list.map((item) => `<li>${item}</li>`).join("")}</ul>
      <div class="dialog-actions"><button class="dialog-primary" type="button" data-tour-next>${last ? "Start exploring" : "Continue →"}</button>${tourStep > 0 ? `<button class="dialog-secondary" type="button" data-tour-back>Back</button>` : ""}<button class="dialog-secondary" type="button" data-tour-skip>Close tour</button></div>`);
  }

  function showAssumptions() {
    dialogOpen(`<span class="dialog-content-eyebrow">TRANSPARENT DEMO METHODOLOGY</span><h2 class="dialog-content-title">How this estimate works</h2>
      <p class="dialog-content-copy">This is a deterministic rules engine for exploring concepts—not a high-fidelity microclimate or CFD model. The same inputs always produce the same illustrative outputs.</p>
      <ul class="dialog-list"><li><strong>Local effect:</strong> each intervention adds a type-specific score, scaled by a capped quantity factor, to its assigned neighbourhood only.</li><li><strong>Diminishing returns:</strong> multiple solutions in one zone receive a diminishing factor rather than a direct sum of their maximum impact bands.</li><li><strong>Conservative cap:</strong> the combined demo reduction is capped at 1.4°C per affected neighbourhood.</li><li><strong>City average:</strong> zone temperatures are weighted by illustrative neighbourhood area; unaffected zones keep their baseline.</li><li><strong>Co-benefits:</strong> CO₂, energy and water values use static illustrative factors and are not validated estimates.</li><li><strong>Important:</strong> actual outcomes depend on design, site, climate, maintenance, water, species and community context.</li></ul>
      <div class="dialog-actions"><button class="dialog-primary" type="button" data-dialog-close>Got it</button></div>`);
  }

  function showZoneList() {
    dialogOpen(`<span class="dialog-content-eyebrow">ACCESSIBLE MAP DIRECTORY</span><h2 class="dialog-content-title">${escapeHtml(city().name)} neighbourhoods</h2><p class="dialog-content-copy">Select a row to inspect that zone. Temperatures and population context are illustrative demo values.</p>
      <table class="zone-table"><thead><tr><th>Neighbourhood</th><th>Temp.</th><th>Heat stress</th></tr></thead><tbody>${city().zones.map((zone) => `<tr><td><button type="button" data-zone-select="${zone.id}">${escapeHtml(zone.name)}</button></td><td>${zone.temp.toFixed(1)}°C</td><td>${riskForTemperature(zone.temp).label}</td></tr>`).join("")}</tbody></table><div class="dialog-actions"><button class="dialog-secondary" type="button" data-dialog-close>Close</button></div>`);
  }

  function showLayersDialog() {
    dialogOpen(`<span class="dialog-content-eyebrow">ILLUSTRATIVE CITY OVERLAYS</span><h2 class="dialog-content-title">Map layers</h2><p class="dialog-content-copy">Turn each layer on or off. When several are enabled, the most recently selected layer is shown on the map.</p>
      <div class="dialog-layer-list">${layerDefinitions.map((layer) => `<button class="layer-toggle" type="button" data-dialog-layer="${layer.id}" aria-pressed="${state.layers[layer.id]}" aria-label="${state.layers[layer.id] ? "Hide" : "Show"} ${escapeHtml(layer.label)} layer"><span class="layer-check">${state.layers[layer.id] ? "✓" : ""}</span><span>${escapeHtml(layer.label)}</span><i class="layer-swatch" style="--swatch:${layer.color}"></i></button>`).join("")}</div>
      <div class="dialog-actions"><button class="dialog-secondary" type="button" data-dialog-close>Done</button></div>`);
  }

  function toggleLayer(layerId) {
    if (!layerDefinitions.some((item) => item.id === layerId)) return;
    state.layers[layerId] = !state.layers[layerId];
    if (state.layers[layerId]) state.activeLayer = layerId;
    else if (state.activeLayer === layerId) state.activeLayer = layerDefinitions.filter((item) => state.layers[item.id]).slice(-1)[0]?.id || "heat";
    renderLayerControls();
    renderMap();
    renderAnalytics();
    persistState();
  }

  function showResetConfirm() {
    dialogOpen(`<span class="dialog-content-eyebrow">RESET DEMO SESSION</span><h2 class="dialog-content-title">Start with a clean map?</h2><p class="dialog-content-copy">This clears scenario placements, chat, plan and demo points, and restores Bengaluru’s baseline heat map. This cannot be undone.</p>
      <div class="dialog-actions"><button class="dialog-primary" type="button" data-reset-confirm>Reset the demo</button><button class="dialog-secondary" type="button" data-dialog-close>Keep exploring</button></div>`);
  }

  function resetDemo() {
    state = freshState();
    undoStack = [];
    redoStack = [];
    chatBusy = false;
    try { localStorage.removeItem(STORAGE_KEY); }
    catch (error) { console.error("Could not clear the saved demo session:", error); showToast("Could not remove the saved browser session.", true); }
    dialogClose();
    switchAssistantTab("assistant");
    renderAll();
    showToast("Demo reset. Bengaluru’s baseline is ready.");
  }

  function changeCity(cityId) {
    if (!cityData[cityId] || cityId === state.city) return;
    const previousCount = state.placements.length;
    state.city = cityId;
    state.selectedZone = null;
    state.placements = [];
    state.selectedPlacement = null;
    state.pendingSolution = null;
    state.movingPlacement = null;
    state.planGenerated = false;
    state.compare = "baseline";
    state.panX = 0;
    state.panY = 0;
    state.zoom = 1;
    undoStack = [];
    redoStack = [];
    addChatMessage("assistant", `City context changed to ${city().name}. I have cleared the previous city's placements so the new scenario starts safely on its own illustrative neighbourhoods.`, null);
    renderAll();
    showToast(previousCount ? `Switched to ${city().name}; prior-city placements were cleared.` : `Demo city changed to ${city().name}.`);
  }

  function attachEvents() {
    $("#citySelect").addEventListener("change", (event) => changeCity(event.target.value));
    $("#helpButton").addEventListener("click", showTutorial);
    $("#tourButton").addEventListener("click", showTutorial);
    $("#resetButton").addEventListener("click", showResetConfirm);
    $("#baselineButton").addEventListener("click", () => { state.compare = "baseline"; renderAll(); });
    $("#scenarioButton").addEventListener("click", () => { state.compare = "scenario"; renderAll(); });
    $("#undoButton").addEventListener("click", undo);
    $("#redoButton").addEventListener("click", redo);
    $("#zoomInButton").addEventListener("click", () => {
      state.zoom = Math.min(1.7, state.zoom + .12);
      setMapTransform();
      persistState();
    });
    $("#zoomOutButton").addEventListener("click", () => {
      state.zoom = Math.max(.8, state.zoom - .12);
      setMapTransform();
      persistState();
    });
    $("#viewButton").addEventListener("click", () => { state.elevated = !state.elevated; renderAll(); });
    $("#layerResetButton").addEventListener("click", () => {
      state.layers = { heat: true, lst: false, landuse: false, vegetation: false, wind: false, humidity: false, population: false };
      state.activeLayer = "heat";
      renderAll();
    });
    $("#zoneListButton").addEventListener("click", showZoneList);
    $("#layersButton").addEventListener("click", showLayersDialog);
    $("#assumptionsButton").addEventListener("click", showAssumptions);
    $("#assistantTab").addEventListener("click", () => switchAssistantTab("assistant"));
    $("#plannerTab").addEventListener("click", () => switchAssistantTab("plan"));
    $("#analyticsPlanButton").addEventListener("click", () => switchAssistantTab("plan"));
    $("#generatePlanButton").addEventListener("click", generatePlan);
    $("#clearChatButton").addEventListener("click", () => {
      state.chat = [];
      renderChat();
      persistState();
      showToast("Assistant conversation cleared.");
    });
    $("#chatForm").addEventListener("submit", (event) => {
      event.preventDefault();
      sendAssistantMessage($("#chatInput").value);
    });
    $("#promptChips").addEventListener("click", (event) => {
      const button = event.target.closest("button");
      if (button) sendAssistantMessage(button.textContent);
    });
    $("#exportPdfButton").addEventListener("click", openPrintReport);
    $("#printButton").addEventListener("click", openPrintReport);
    $("#exportInterventionsButton").addEventListener("click", () => downloadCsv(`${state.city}-intervention-register.csv`, interventionRows()));
    $("#exportZonesButton").addEventListener("click", () => downloadCsv(`${state.city}-zone-metrics.csv`, zoneRows()));
    $("#cityMap").addEventListener("click", (event) => {
      if (suppressMapClick) {
        suppressMapClick = false;
        return;
      }
      const placement = event.target.closest("[data-placement]");
      if (placement) {
        openPlacementDialog(placement.dataset.placement);
        return;
      }
      const hotspot = event.target.closest("[data-hotspot-zone]");
      if (hotspot) {
        state.selectedZone = hotspot.dataset.hotspotZone;
        renderAll();
        return;
      }
      const zoneElement = event.target.closest("[data-zone]");
      if (zoneElement) {
        const zone = zoneById(zoneElement.dataset.zone);
        if (state.pendingSolution || state.movingPlacement) {
          const shape = zoneShapes.find((item) => item.key === zone.id);
          placePendingAt(shape.cx, shape.cy, zone);
        } else {
          state.selectedZone = zone.id;
          renderAll();
        }
        return;
      }
      if (state.pendingSolution || state.movingPlacement) {
        const point = svgPointFromEvent(event);
        placePendingAt(point.x, point.y);
      }
    });
    $("#cityMap").addEventListener("keydown", (event) => {
      const target = event.target.closest("[data-zone], [data-hotspot-zone], [data-placement]");
      if (event.key === "Enter" || event.key === " ") {
        if (target) {
          event.preventDefault();
          target.dispatchEvent(new MouseEvent("click", { bubbles: true }));
        } else if (state.pendingSolution || state.movingPlacement) {
          event.preventDefault();
          const zone = currentZone() || city().zones[0];
          const shape = zoneShapes.find((item) => item.key === zone.id);
          placePendingAt(shape.cx, shape.cy, zone);
        }
      } else if (event.key === "Escape" && (state.pendingSolution || state.movingPlacement)) {
        state.pendingSolution = null;
        state.movingPlacement = null;
        renderAll();
        showToast("Map placement cancelled.");
      }
    });
    $("#cityMap").addEventListener("dragover", (event) => {
      if (event.dataTransfer?.types.includes("text/nexterra-solution")) {
        event.preventDefault();
        $("#mapStage").classList.add("is-drop-target");
      }
    });
    $("#cityMap").addEventListener("dragleave", (event) => {
      if (!$("#mapStage").contains(event.relatedTarget)) $("#mapStage").classList.remove("is-drop-target");
    });
    $("#cityMap").addEventListener("drop", (event) => {
      const typeId = event.dataTransfer?.getData("text/nexterra-solution");
      if (!typeId) return;
      event.preventDefault();
      $("#mapStage").classList.remove("is-drop-target");
      const point = svgPointFromEvent(event);
      createPlacement(typeId, point.x, point.y, closestZone(point.x, point.y));
    });
    $("#cityMap").addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || state.pendingSolution || state.movingPlacement ||
          event.target.closest("[data-zone], [data-hotspot-zone], [data-placement]")) return;
      panSession = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, panX: state.panX, panY: state.panY, moved: false };
      $("#cityMap").setPointerCapture(event.pointerId);
    });
    $("#cityMap").addEventListener("pointermove", (event) => {
      if (!panSession || panSession.pointerId !== event.pointerId) return;
      const dx = event.clientX - panSession.x;
      const dy = event.clientY - panSession.y;
      if (Math.abs(dx) + Math.abs(dy) > 3) panSession.moved = true;
      if (!panSession.moved) return;
      state.panX = Math.max(-180, Math.min(180, panSession.panX + dx));
      state.panY = Math.max(-140, Math.min(140, panSession.panY + dy));
      setMapTransform();
    });
    const finishPan = (event) => {
      if (!panSession || panSession.pointerId !== event.pointerId) return;
      const moved = panSession.moved;
      panSession = null;
      if (moved) {
        suppressMapClick = true;
        window.setTimeout(() => { suppressMapClick = false; }, 250);
      }
    };
    $("#cityMap").addEventListener("pointerup", finishPan);
    $("#cityMap").addEventListener("pointercancel", finishPan);
    $("#solutionList").addEventListener("click", (event) => {
      const card = event.target.closest("[data-solution]");
      if (card) selectPendingSolution(card.dataset.solution);
    });
    $("#solutionList").addEventListener("keydown", (event) => {
      const card = event.target.closest("[data-solution]");
      if (card && (event.key === "Enter" || event.key === " ")) {
        event.preventDefault();
        selectPendingSolution(card.dataset.solution);
      }
    });
    $("#solutionList").addEventListener("dragstart", (event) => {
      const card = event.target.closest("[data-solution]");
      if (!card || !event.dataTransfer) return;
      event.dataTransfer.setData("text/nexterra-solution", card.dataset.solution);
      event.dataTransfer.effectAllowed = "copy";
      state.pendingSolution = card.dataset.solution;
      card.classList.add("is-selected");
      $("#mapStage").classList.add("is-drop-target");
    });
    $("#solutionList").addEventListener("dragend", () => {
      $("#mapStage").classList.remove("is-drop-target");
      if (state.pendingSolution) {
        state.pendingSolution = null;
        renderSolutions();
        $("#mapInstructions").classList.remove("visible");
      }
    });
    $("#layerList").addEventListener("click", (event) => {
      const button = event.target.closest("[data-layer]");
      if (!button) return;
      toggleLayer(button.dataset.layer);
    });
    $("#zoneCard").addEventListener("click", (event) => {
      if (event.target.closest(".zone-card-close")) { state.selectedZone = null; renderAll(); }
      if (event.target.closest("[data-zone-list]")) showZoneList();
      if (event.target.closest("[data-zone-place]")) {
        const zone = currentZone();
        const shape = zoneShapes.find((item) => item.key === zone?.id);
        const typeId = state.pendingSolution || "trees";
        if (zone && shape) createPlacement(typeId, shape.cx, shape.cy, zone);
      }
    });
    $("#chatMessages").addEventListener("click", (event) => {
      const button = event.target.closest("[data-assistant-action]");
      if (!button) return;
      if (button.dataset.assistantAction === "add-recommendations") applyRecommendations();
      if (button.dataset.assistantAction === "generate-plan") generatePlan();
    });
    $("#dialogContent").addEventListener("click", (event) => {
      const target = event.target.closest("button");
      if (!target) return;
      if (target.hasAttribute("data-dialog-close") || target.hasAttribute("data-tour-skip")) { dialogClose(); return; }
      if (target.hasAttribute("data-tour-next")) {
        if (tourStep < 3) { tourStep += 1; renderTutorial(); }
        else dialogClose();
        return;
      }
      if (target.hasAttribute("data-tour-back")) { tourStep = Math.max(0, tourStep - 1); renderTutorial(); return; }
      if (target.hasAttribute("data-reset-confirm")) { resetDemo(); return; }
      if (target.hasAttribute("data-zone-select")) {
        state.selectedZone = target.dataset.zoneSelect;
        dialogClose();
        renderAll();
        return;
      }
      if (target.hasAttribute("data-dialog-layer")) {
        const layerId = target.dataset.dialogLayer;
        toggleLayer(layerId);
        showLayersDialog();
        return;
      }
      if (target.hasAttribute("data-placement-save")) {
        const id = target.dataset.placementSave;
        const quantity = Number($("#quantityInput")?.value);
        if (!Number.isInteger(quantity) || quantity < 1 || quantity > 500) { showToast("Quantity must be a whole number between 1 and 500.", true); return; }
        const enabled = $("#statusInput")?.value !== "disabled";
        const current = state.placements.find((item) => item.id === id);
        if (!current) { showToast("That placement no longer exists.", true); dialogClose(); return; }
        if (current.quantity !== quantity || (current.enabled !== false) !== enabled) {
          rememberPlacements();
          state.placements = state.placements.map((item) => item.id === id ? { ...item, quantity, enabled } : item);
          state.planGenerated = false;
        }
        dialogClose();
        renderAll();
        showToast("Solution configuration saved.");
        return;
      }
      if (target.hasAttribute("data-placement-move")) {
        state.movingPlacement = target.dataset.placementMove;
        state.pendingSolution = null;
        dialogClose();
        renderMap();
        $("#cityMap").focus({ preventScroll: true });
        showToast("Click a new neighbourhood or map location to move this solution.");
        return;
      }
      if (target.hasAttribute("data-placement-duplicate")) {
        const placement = state.placements.find((item) => item.id === target.dataset.placementDuplicate);
        if (!placement) return;
        const next = { ...placement, id: `place-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`, x: Math.min(838, placement.x + 34), y: Math.min(585, placement.y + 30) };
        updatePlacements([...state.placements, next]);
        dialogClose();
        showToast("Solution duplicated. Adjust its location or quantity.");
        return;
      }
      if (target.hasAttribute("data-placement-remove")) {
        const id = target.dataset.placementRemove;
        updatePlacements(state.placements.filter((item) => item.id !== id));
        dialogClose();
        showToast("Solution removed from the scenario.");
      }
    });
    $("#appDialog").addEventListener("click", (event) => {
      if (event.target === $("#appDialog")) dialogClose();
    });
    document.addEventListener("keydown", (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
        event.preventDefault();
        event.shiftKey ? redo() : undo();
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "y") {
        event.preventDefault();
        redo();
      } else if (event.key === "Escape" && (state.pendingSolution || state.movingPlacement) && !$("#appDialog").open) {
        state.pendingSolution = null;
        state.movingPlacement = null;
        renderAll();
      }
    });
    window.addEventListener("afterprint", () => document.body.classList.remove("printing"));
    window.addEventListener("beforeunload", persistState);
  }

  loadSavedState();
  attachEvents();
  renderAll();
  $("#cityMap").style.transform = `scale(${state.zoom})`;
  switchAssistantTab("assistant");
})();
