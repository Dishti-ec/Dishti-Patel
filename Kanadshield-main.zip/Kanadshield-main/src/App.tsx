import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import { AnimatePresence, motion } from "framer-motion";
import { I18nProvider } from "@/lib/i18n";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Emergency from "@/pages/emergency";
import Family from "@/pages/family";
import Resources from "@/pages/resources";
import Contact from "@/pages/contact";
import AiProtection from "@/pages/ai-protection";
import ReportScam from "@/pages/report-scam";
import CaseTracker from "@/pages/case-tracker";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import ChatBot from "@/components/ChatBot";
import AccessibilityPanel from "@/components/AccessibilityPanel";

const queryClient = new QueryClient();

const pageVariants = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.35, ease: "easeOut" } },
  exit: { opacity: 0, y: -12, transition: { duration: 0.2, ease: "easeIn" } },
};

function AnimatedRoute({ component: Component }: { component: React.ComponentType }) {
  return (
    <motion.div variants={pageVariants} initial="initial" animate="animate" exit="exit">
      <Component />
    </motion.div>
  );
}

function Router() {
  const [location] = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Switch key={location}>
        <Route path="/" component={() => <AnimatedRoute component={Home} />} />
        <Route path="/emergency" component={() => <AnimatedRoute component={Emergency} />} />
        <Route path="/family" component={() => <AnimatedRoute component={Family} />} />
        <Route path="/resources" component={() => <AnimatedRoute component={Resources} />} />
        <Route path="/contact" component={() => <AnimatedRoute component={Contact} />} />
        <Route path="/ai-protection" component={() => <AnimatedRoute component={AiProtection} />} />
        <Route path="/report-scam" component={() => <AnimatedRoute component={ReportScam} />} />
        <Route path="/case-tracker" component={() => <AnimatedRoute component={CaseTracker} />} />
        <Route component={NotFound} />
      </Switch>
    </AnimatePresence>
  );
}

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
      <I18nProvider>
        <QueryClientProvider client={queryClient}>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <div className="min-h-screen flex flex-col bg-background">
                <Navbar />
                <main className="flex-1">
                  <Router />
                </main>
                <Footer />
              </div>
              <ChatBot />
              <AccessibilityPanel />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </QueryClientProvider>
      </I18nProvider>
    </ThemeProvider>
  );
}

export default App;
