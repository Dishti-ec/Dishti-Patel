import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  AlertTriangle, Upload, FileText, Image, Mic, CheckCircle, Shield,
  CreditCard, TrendingUp, QrCode, Smartphone, Video, Phone, Clock,
  Lock, ArrowRight, Siren
} from "lucide-react";

const scamTypes = [
  { label: "OTP Scam", icon: <Smartphone className="w-5 h-5" />, color: "text-blue-600 bg-blue-50 border-blue-200" },
  { label: "UPI Fraud", icon: <CreditCard className="w-5 h-5" />, color: "text-green-600 bg-green-50 border-green-200" },
  { label: "Investment Fraud", icon: <TrendingUp className="w-5 h-5" />, color: "text-purple-600 bg-purple-50 border-purple-200" },
  { label: "KYC Scam", icon: <FileText className="w-5 h-5" />, color: "text-amber-600 bg-amber-50 border-amber-200" },
  { label: "QR Code Scam", icon: <QrCode className="w-5 h-5" />, color: "text-red-600 bg-red-50 border-red-200" },
  { label: "Voice Phishing", icon: <Mic className="w-5 h-5" />, color: "text-orange-600 bg-orange-50 border-orange-200" },
  { label: "Deepfake Scam", icon: <Video className="w-5 h-5" />, color: "text-pink-600 bg-pink-50 border-pink-200" },
  { label: "Other", icon: <AlertTriangle className="w-5 h-5" />, color: "text-gray-600 bg-gray-50 border-gray-200" },
];

const schema = z.object({
  fullName: z.string().min(2, "Name must be at least 2 characters"),
  mobile: z.string().regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit mobile number"),
  email: z.string().email("Enter a valid email").or(z.literal("")),
  scamDate: z.string().min(1, "Please select the date of incident"),
  amountLost: z.string().optional(),
  scammerMobile: z.string().optional(),
  transactionId: z.string().optional(),
  description: z.string().min(30, "Please provide at least 30 characters of detail"),
});

type FormData = z.infer<typeof schema>;

type UploadedFile = { name: string; type: string; size: string };

export default function ReportScam() {
  const [selectedScamType, setSelectedScamType] = useState("");
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [caseId] = useState(`CC${new Date().getFullYear()}-${Math.floor(Math.random() * 9000) + 1000}`);
  const fileRef = useRef<HTMLInputElement>(null);

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { fullName: "", mobile: "", email: "", scamDate: "", amountLost: "", scammerMobile: "", transactionId: "", description: "" },
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newFiles: UploadedFile[] = Array.from(files).map(f => ({
      name: f.name,
      type: f.type.startsWith("image") ? "image" : f.type.startsWith("audio") ? "audio" : "document",
      size: `${(f.size / 1024).toFixed(0)} KB`,
    }));
    setUploadedFiles(prev => [...prev, ...newFiles]);
  };

  const onSubmit = () => {
    if (!selectedScamType) return;
    // Save to localStorage so Case Tracker can find it
    const data = form.getValues();
    const newCase = {
      id: caseId,
      type: selectedScamType,
      amount: data.amountLost ? `₹${data.amountLost}` : "Not specified",
      filedOn: new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }),
      stage: "received" as const,
      victim: `${data.fullName}, ${data.mobile}`,
      priority: "High" as const,
      riskScore: 72,
      estimatedResolution: "Within 7 days",
      officer: { name: "To be assigned", badge: "Pending", phone: "1930", unit: "VRIDDHAKSHA Response Network" },
      updates: [
        { date: new Date().toLocaleString("en-IN"), by: "System", note: `Complaint received via VRIDDHAKSHA Platform. Type: ${selectedScamType}. AI classification in progress.`, stage: "received" as const },
      ],
    };
    try {
      const existing = JSON.parse(localStorage.getItem("shield_complaints") || "[]");
      localStorage.setItem("shield_complaints", JSON.stringify([newCase, ...existing]));
    } catch {}
    setSubmitted(true);
  };

  const steps = [
    { n: 1, label: "Scam Type" },
    { n: 2, label: "Your Details" },
    { n: 3, label: "Incident Info" },
    { n: 4, label: "Evidence" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-r from-red-700 to-red-500 text-white py-10">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <Siren className="w-8 h-8" />
            <h1 className="text-3xl font-heading font-bold">Report a Cyber Crime</h1>
          </div>
          <p className="text-red-200 max-w-2xl mx-auto">Your complaint will be securely received by the VRIDDHAKSHA response network. All information is secure and confidential.</p>
          <div className="mt-6 flex items-center justify-center gap-6 flex-wrap">
            <div className="flex items-center gap-2 text-sm">
              <Lock className="w-4 h-4 text-red-200" />
              <span className="text-red-100">End-to-End Encrypted</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Shield className="w-4 h-4 text-red-200" />
              <span className="text-red-100">Government Verified</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4 text-red-200" />
              <span className="text-red-100">24×7 Processing</span>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Banner */}
      <div className="bg-amber-50 dark:bg-amber-950/20 border-b border-amber-200 dark:border-amber-800 py-3">
        <div className="container mx-auto px-4 flex items-center justify-center gap-6 flex-wrap text-sm">
          <span className="text-amber-800 dark:text-amber-300 font-medium flex items-center gap-2">
            <Phone className="w-4 h-4" />For immediate help: Call <strong>1930</strong> (Cyber Crime Helpline) · <strong>100</strong> (Police)
          </span>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10 max-w-3xl">
        {submitted ? (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-white dark:bg-card rounded-3xl border border-border p-10 shadow-sm text-center">
            <div className="w-24 h-24 bg-green-100 dark:bg-green-950/30 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <h2 className="text-3xl font-heading font-bold text-foreground mb-3">Complaint Filed!</h2>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">Your complaint has been received by the VRIDDHAKSHA response network and assigned a case number.</p>
            <div className="bg-blue-50 dark:bg-blue-950/20 rounded-2xl p-6 border border-blue-200 dark:border-blue-800 mb-6">
              <div className="text-xs text-muted-foreground uppercase tracking-widest mb-2">Your Case ID</div>
              <div className="text-4xl font-heading font-bold text-[#0B3D91] mb-2">{caseId}</div>
              <div className="text-sm text-muted-foreground">Save this for tracking your case status</div>
            </div>
            <div className="space-y-3 mb-8 text-left">
              {[
                { step: "Complaint Received", status: "done", time: "Just now" },
                { step: "AI Processing & Classification", status: "done", time: "Just now" },
                { step: "Assigned to Police Safety Officer", status: "active", time: "Within 30 min" },
                { step: "Investigation Initiated", status: "pending", time: "Within 24 hrs" },
                { step: "Status Update to You", status: "pending", time: "Within 48 hrs" },
              ].map((s, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${s.status === "done" ? "bg-green-100 text-green-600" : s.status === "active" ? "bg-blue-100 text-blue-600 animate-pulse" : "bg-muted text-muted-foreground"}`}>
                    {s.status === "done" ? <CheckCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                  </div>
                  <div className="flex-1 text-sm text-foreground">{s.step}</div>
                  <div className="text-xs text-muted-foreground">{s.time}</div>
                </div>
              ))}
            </div>
            <div className="bg-amber-50 dark:bg-amber-950/20 rounded-xl p-4 border border-amber-200 dark:border-amber-800 text-sm text-muted-foreground text-left">
              <strong className="text-amber-700 dark:text-amber-400">Important:</strong> Contact your bank immediately to freeze the account if money was lost. Call 1930 for urgent escalation.
            </div>
          </motion.div>
        ) : (
          <div className="bg-white dark:bg-card rounded-3xl border border-border shadow-sm overflow-hidden">
            {/* Progress */}
            <div className="p-6 border-b border-border">
              <div className="flex items-center gap-2 justify-between mb-4">
                {steps.map((s, i) => (
                  <React.Fragment key={s.n}>
                    <div className="flex flex-col items-center gap-1">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-all ${step > s.n ? "bg-green-500 text-white" : step === s.n ? "bg-[#0B3D91] text-white" : "bg-muted text-muted-foreground"}`}>
                        {step > s.n ? <CheckCircle className="w-5 h-5" /> : s.n}
                      </div>
                      <span className="text-xs text-muted-foreground hidden sm:block">{s.label}</span>
                    </div>
                    {i < steps.length - 1 && <div className={`flex-1 h-0.5 mx-1 rounded-full transition-all ${step > s.n ? "bg-green-500" : "bg-muted"}`} />}
                  </React.Fragment>
                ))}
              </div>
              <div className="text-sm text-muted-foreground text-center">Step {step} of {steps.length}: <strong className="text-foreground">{steps[step - 1].label}</strong></div>
            </div>

            <div className="p-8">
              <AnimatePresence mode="wait">
                {/* Step 1: Scam Type */}
                {step === 1 && (
                  <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <h2 className="text-xl font-heading font-bold text-foreground mb-2">What type of scam occurred?</h2>
                    <p className="text-muted-foreground text-sm mb-6">Select the category that best describes the fraud.</p>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {scamTypes.map(t => (
                        <button key={t.label} onClick={() => setSelectedScamType(t.label)}
                          className={`p-4 rounded-2xl border-2 text-center transition-all hover:shadow-md ${selectedScamType === t.label ? "border-[#0B3D91] bg-blue-50 dark:bg-blue-950/20" : `border-border ${t.color.split(" ")[1]} hover:border-gray-300`}`}
                          data-testid={`button-scam-type-${t.label}`}>
                          <div className={`flex justify-center mb-2 ${t.color.split(" ")[0]}`}>{t.icon}</div>
                          <div className={`text-xs font-semibold ${selectedScamType === t.label ? "text-[#0B3D91]" : "text-foreground"}`}>{t.label}</div>
                        </button>
                      ))}
                    </div>
                    {!selectedScamType && <p className="text-xs text-red-500 mt-2">Please select a scam type</p>}
                    <Button onClick={() => selectedScamType && setStep(2)} className="mt-6 w-full rounded-xl bg-[#0B3D91] text-white py-6 font-semibold">
                      Continue <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </motion.div>
                )}

                {/* Step 2: Your Details */}
                {step === 2 && (
                  <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <h2 className="text-xl font-heading font-bold text-foreground mb-2">Your Details</h2>
                    <p className="text-muted-foreground text-sm mb-6">Victim / Reporter information. All data is secure.</p>
                    <Form {...form}>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField control={form.control} name="fullName" render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name *</FormLabel>
                              <FormControl><Input {...field} placeholder="Ramesh Patel" className="rounded-xl" /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )} />
                          <FormField control={form.control} name="mobile" render={({ field }) => (
                            <FormItem>
                              <FormLabel>Mobile Number *</FormLabel>
                              <FormControl><Input {...field} placeholder="9876543210" className="rounded-xl" /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )} />
                        </div>
                        <FormField control={form.control} name="email" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email (optional)</FormLabel>
                            <FormControl><Input {...field} type="email" placeholder="ramesh@example.com" className="rounded-xl" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>
                    </Form>
                    <div className="flex gap-3 mt-6">
                      <Button onClick={() => setStep(1)} variant="outline" className="flex-1 rounded-xl">Back</Button>
                      <Button onClick={() => form.trigger(["fullName", "mobile", "email"]).then(v => v && setStep(3))} className="flex-1 rounded-xl bg-[#0B3D91] text-white">
                        Continue <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </div>
                  </motion.div>
                )}

                {/* Step 3: Incident Info */}
                {step === 3 && (
                  <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <h2 className="text-xl font-heading font-bold text-foreground mb-2">Incident Information</h2>
                    <p className="text-muted-foreground text-sm mb-6">Tell us what happened. More details help investigators act faster.</p>
                    <Form {...form}>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField control={form.control} name="scamDate" render={({ field }) => (
                            <FormItem>
                              <FormLabel>Date of Incident *</FormLabel>
                              <FormControl><Input {...field} type="date" className="rounded-xl" /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )} />
                          <FormField control={form.control} name="amountLost" render={({ field }) => (
                            <FormItem>
                              <FormLabel>Amount Lost (₹)</FormLabel>
                              <FormControl><Input {...field} placeholder="e.g. 45000" className="rounded-xl" /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )} />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <FormField control={form.control} name="scammerMobile" render={({ field }) => (
                            <FormItem>
                              <FormLabel>Scammer's Mobile/Number</FormLabel>
                              <FormControl><Input {...field} placeholder="+91 98765 43210" className="rounded-xl" /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )} />
                          <FormField control={form.control} name="transactionId" render={({ field }) => (
                            <FormItem>
                              <FormLabel>Transaction ID / UTR</FormLabel>
                              <FormControl><Input {...field} placeholder="e.g. UTR123456789" className="rounded-xl" /></FormControl>
                              <FormMessage />
                            </FormItem>
                          )} />
                        </div>
                        <FormField control={form.control} name="description" render={({ field }) => (
                          <FormItem>
                            <FormLabel>What Happened? * (min 30 characters)</FormLabel>
                            <FormControl>
                              <textarea {...field} rows={4} placeholder="Describe the fraud in detail — how the scammer contacted you, what they said, what happened..." className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring resize-none" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>
                    </Form>
                    <div className="flex gap-3 mt-6">
                      <Button onClick={() => setStep(2)} variant="outline" className="flex-1 rounded-xl">Back</Button>
                      <Button onClick={() => form.trigger(["scamDate", "description"]).then(v => v && setStep(4))} className="flex-1 rounded-xl bg-[#0B3D91] text-white">
                        Continue <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </div>
                  </motion.div>
                )}

                {/* Step 4: Evidence */}
                {step === 4 && (
                  <motion.div key="s4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <h2 className="text-xl font-heading font-bold text-foreground mb-2">Upload Evidence</h2>
                    <p className="text-muted-foreground text-sm mb-6">Upload screenshots, call recordings, or bank statements. Evidence strengthens your case significantly.</p>

                    <div
                      onClick={() => fileRef.current?.click()}
                      className="border-2 border-dashed border-border rounded-2xl p-8 text-center cursor-pointer hover:border-[#0B3D91] hover:bg-blue-50/40 dark:hover:bg-blue-950/10 transition-all group mb-4"
                      data-testid="upload-evidence"
                    >
                      <Upload className="w-10 h-10 text-muted-foreground group-hover:text-[#0B3D91] mx-auto mb-3 transition-colors" />
                      <div className="text-sm font-semibold text-foreground mb-1">Click to upload or drag & drop</div>
                      <div className="text-xs text-muted-foreground">Screenshots (JPG, PNG) · Call recordings (MP3, WAV) · Bank statements (PDF)</div>
                      <div className="text-xs text-muted-foreground mt-1">Max 10 MB per file</div>
                    </div>
                    <input ref={fileRef} type="file" multiple accept="image/*,audio/*,.pdf,.doc,.docx" onChange={handleFileUpload} className="hidden" />

                    {uploadedFiles.length > 0 && (
                      <div className="space-y-2 mb-4">
                        {uploadedFiles.map((f, i) => (
                          <div key={i} className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-950/20 rounded-xl border border-green-200 dark:border-green-900/50">
                            <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
                              {f.type === "image" ? <Image className="w-4 h-4 text-green-600" /> : f.type === "audio" ? <Mic className="w-4 h-4 text-green-600" /> : <FileText className="w-4 h-4 text-green-600" />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium text-foreground truncate">{f.name}</div>
                              <div className="text-xs text-muted-foreground">{f.size}</div>
                            </div>
                            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="bg-blue-50 dark:bg-blue-950/20 rounded-xl p-4 border border-blue-100 dark:border-blue-900/50 text-sm text-muted-foreground mb-6">
                      <strong className="text-[#0B3D91]">Tip:</strong> Useful evidence includes: SMS screenshots showing the scam message, bank transaction screenshots, call logs from the scammer's number, WhatsApp chat screenshots.
                    </div>

                    <div className="flex gap-3">
                      <Button onClick={() => setStep(3)} variant="outline" className="flex-1 rounded-xl">Back</Button>
                      <Button onClick={form.handleSubmit(onSubmit)} className="flex-1 rounded-xl bg-red-600 hover:bg-red-700 text-white py-6 font-semibold text-base">
                        <Siren className="w-5 h-5 mr-2" />Submit Complaint
                      </Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
