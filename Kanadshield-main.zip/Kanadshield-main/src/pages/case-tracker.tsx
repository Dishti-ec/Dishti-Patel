import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Search, Shield, CheckCircle, Clock, AlertCircle, User, Phone,
  FileText, MapPin, Calendar, ArrowRight, RefreshCw, Lock,
  Fingerprint, TrendingUp, MessageCircle, Download, Copy, Star
} from "lucide-react";

type CaseStage = "received" | "ai_processing" | "assigned" | "investigating" | "legal" | "resolved" | "closed";

interface CaseData {
  id: string;
  type: string;
  amount: string;
  filedOn: string;
  stage: CaseStage;
  victim: string;
  officer: { name: string; badge: string; phone: string; unit: string };
  updates: { date: string; by: string; note: string; stage: CaseStage }[];
  recoveredAmount?: string;
  estimatedResolution: string;
  riskScore: number;
  priority: "Critical" | "High" | "Medium" | "Low";
}

const CASES: Record<string, CaseData> = {
  "CC2024-4821": {
    id: "CC2024-4821",
    type: "UPI Fraud / Fake KYC",
    amount: "₹1,25,000",
    filedOn: "12 Jun 2024",
    stage: "investigating",
    victim: "Ramesh Patel, 68",
    priority: "High",
    riskScore: 78,
    estimatedResolution: "15–20 Jun 2024",
    officer: { name: "SI Deepak Sharma", badge: "SHD-1142", phone: "1930", unit: "VRIDDHAKSHA Response Network" },
    recoveredAmount: "₹62,000 (freezing order issued)",
    updates: [
      { date: "12 Jun · 11:30", by: "System", note: "Complaint received. AI classification: High-priority UPI fraud.", stage: "received" },
      { date: "12 Jun · 11:31", by: "AI Engine", note: "Scam pattern matched: fake KYC + UPI collect request. Confidence: 96%.", stage: "ai_processing" },
      { date: "12 Jun · 12:15", by: "VRIDDHAKSHA Case Manager", note: "Case assigned to SI Deepak Sharma, VRIDDHAKSHA Response Network.", stage: "assigned" },
      { date: "12 Jun · 14:00", by: "SI Deepak Sharma", note: "Transaction trace initiated. Freeze request sent to HDFC Bank for 3 mule accounts.", stage: "investigating" },
      { date: "13 Jun · 09:45", by: "SI Deepak Sharma", note: "₹62,000 frozen across 2 accounts. Cybercrime court order obtained. Suspect mobile traced to UP.", stage: "investigating" },
      { date: "13 Jun · 16:00", by: "SI Deepak Sharma", note: "Coordination with UP Cyber Cell. Suspect identified. Arrest warrant being processed.", stage: "investigating" },
    ],
  },
  "CC2024-3310": {
    id: "CC2024-3310",
    type: "Investment Fraud / Ponzi Scheme",
    amount: "₹8,50,000",
    filedOn: "05 Jun 2024",
    stage: "legal",
    victim: "Sunita Mehta, 72",
    priority: "Critical",
    riskScore: 94,
    estimatedResolution: "20–30 Jun 2024",
    officer: { name: "PI Ankit Joshi", badge: "SHD-0987", phone: "1930", unit: "VRIDDHAKSHA Response Network" },
    recoveredAmount: "₹3,20,000 (court-ordered freeze)",
    updates: [
      { date: "05 Jun · 09:10", by: "System", note: "Complaint received. Classified as high-value investment fraud.", stage: "received" },
      { date: "05 Jun · 09:11", by: "AI Engine", note: "Ponzi scheme pattern detected. 14 other victims identified in same fraud ring.", stage: "ai_processing" },
      { date: "05 Jun · 10:30", by: "VRIDDHAKSHA Case Manager", note: "Assigned to PI Ankit Joshi with Critical priority.", stage: "assigned" },
      { date: "05 Jun · 14:00", by: "PI Ankit Joshi", note: "FIR registered. Traced to fraudulent firm: 'CapGrow Investments Pvt Ltd' — shell company.", stage: "investigating" },
      { date: "08 Jun · 11:00", by: "PI Ankit Joshi", note: "Charge sheet filed. ₹3.2L frozen. Primary suspect in custody.", stage: "legal" },
      { date: "10 Jun · 15:30", by: "Court", note: "Case listed for hearing on 20 Jun 2024. Victim recovery proceedings underway.", stage: "legal" },
    ],
  },
  "CC2024-1085": {
    id: "CC2024-1085",
    type: "OTP Scam / Impersonation",
    amount: "₹45,000",
    filedOn: "18 May 2024",
    stage: "resolved",
    victim: "Vinod Shah, 65",
    priority: "Medium",
    riskScore: 65,
    estimatedResolution: "Resolved",
    officer: { name: "ASI Priya Nair", badge: "SHD-2203", phone: "1930", unit: "VRIDDHAKSHA Response Network" },
    recoveredAmount: "₹45,000 (fully recovered)",
    updates: [
      { date: "18 May · 08:55", by: "System", note: "Complaint received. Classified as OTP impersonation scam.", stage: "received" },
      { date: "18 May · 08:56", by: "AI Engine", note: "Suspect matched to known scammer database. Previous 8 victims.", stage: "ai_processing" },
      { date: "18 May · 10:00", by: "VRIDDHAKSHA Case Manager", note: "Assigned to ASI Priya Nair.", stage: "assigned" },
      { date: "19 May · 13:00", by: "ASI Priya Nair", note: "Suspect arrested in Rajkot. Full amount recovered from suspect's account.", stage: "investigating" },
      { date: "22 May · 16:00", by: "ASI Priya Nair", note: "₹45,000 returned to victim. Suspect remanded to judicial custody.", stage: "resolved" },
    ],
  },
};

const stages: { key: CaseStage; label: string; icon: React.ReactNode }[] = [
  { key: "received", label: "Received", icon: <FileText className="w-4 h-4" /> },
  { key: "ai_processing", label: "AI Analysis", icon: <Shield className="w-4 h-4" /> },
  { key: "assigned", label: "Assigned", icon: <User className="w-4 h-4" /> },
  { key: "investigating", label: "Investigating", icon: <Search className="w-4 h-4" /> },
  { key: "legal", label: "Legal Action", icon: <FileText className="w-4 h-4" /> },
  { key: "resolved", label: "Resolved", icon: <CheckCircle className="w-4 h-4" /> },
];

const stageOrder: CaseStage[] = ["received", "ai_processing", "assigned", "investigating", "legal", "resolved"];

const priorityColors: Record<string, string> = {
  Critical: "text-red-600 bg-red-50 border-red-200",
  High: "text-orange-600 bg-orange-50 border-orange-200",
  Medium: "text-amber-600 bg-amber-50 border-amber-200",
  Low: "text-green-600 bg-green-50 border-green-200",
};

const stageColors: Record<CaseStage, string> = {
  received: "text-blue-600 bg-blue-50 border-blue-200",
  ai_processing: "text-purple-600 bg-purple-50 border-purple-200",
  assigned: "text-indigo-600 bg-indigo-50 border-indigo-200",
  investigating: "text-amber-600 bg-amber-50 border-amber-200",
  legal: "text-orange-600 bg-orange-50 border-orange-200",
  resolved: "text-green-600 bg-green-50 border-green-200",
  closed: "text-gray-600 bg-gray-50 border-gray-200",
};

const stageLabels: Record<CaseStage, string> = {
  received: "Received",
  ai_processing: "AI Analysis",
  assigned: "Assigned",
  investigating: "Investigating",
  legal: "Legal Action",
  resolved: "Resolved",
  closed: "Closed",
};

function CaseResult({ data }: { data: CaseData }) {
  const [copied, setCopied] = useState(false);
  const currentIdx = stageOrder.indexOf(data.stage);

  const copy = () => {
    navigator.clipboard.writeText(data.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      {/* Header Card */}
      <div className="bg-white dark:bg-card rounded-3xl border border-border shadow-sm overflow-hidden">
        <div className="bg-gradient-to-r from-[#0B3D91] to-blue-600 p-6 text-white">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-blue-200 text-sm">Case ID</span>
                <button onClick={copy} className="flex items-center gap-1 text-xs bg-white/10 hover:bg-white/20 rounded-full px-2 py-0.5 transition-colors">
                  {copied ? <CheckCircle className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                  {copied ? "Copied!" : "Copy"}
                </button>
              </div>
              <h2 className="text-3xl font-heading font-bold mb-1">{data.id}</h2>
              <p className="text-blue-200">{data.type}</p>
            </div>
            <div className="text-right">
              <Badge className={`mb-2 text-xs font-bold border ${priorityColors[data.priority]}`}>{data.priority} Priority</Badge>
              <div className="text-sm text-blue-200">Filed: {data.filedOn}</div>
              <div className="text-sm text-blue-200">Victim: {data.victim}</div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-y md:divide-y-0 divide-border">
          {[
            { label: "Amount Reported", value: data.amount, icon: <TrendingUp className="w-4 h-4 text-red-500" /> },
            { label: "Amount Recovered", value: data.recoveredAmount ?? "Pending", icon: <CheckCircle className="w-4 h-4 text-green-500" /> },
            { label: "Case Status", value: stageLabels[data.stage], icon: <Shield className="w-4 h-4 text-[#0B3D91]" /> },
            { label: "Est. Resolution", value: data.estimatedResolution, icon: <Calendar className="w-4 h-4 text-purple-500" /> },
          ].map((s, i) => (
            <div key={i} className="p-4 text-center">
              <div className="flex justify-center mb-1">{s.icon}</div>
              <div className="text-xs text-muted-foreground mb-1">{s.label}</div>
              <div className="text-sm font-bold text-foreground">{s.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Progress Timeline */}
      <div className="bg-white dark:bg-card rounded-3xl border border-border p-6 shadow-sm">
        <h3 className="font-heading font-bold text-foreground mb-6 flex items-center gap-2">
          <Shield className="w-5 h-5 text-[#0B3D91]" />Investigation Progress
        </h3>
        <div className="relative">
          {/* Track line */}
          <div className="absolute top-5 left-5 right-5 h-0.5 bg-muted hidden md:block" />
          <div
            className="absolute top-5 left-5 h-0.5 bg-[#0B3D91] hidden md:block transition-all duration-700"
            style={{ width: `${Math.min((currentIdx / (stageOrder.length - 1)) * 100, 100)}%` }}
          />

          <div className="grid grid-cols-3 md:grid-cols-6 gap-4 relative">
            {stages.map((s, i) => {
              const done = i <= currentIdx;
              const active = i === currentIdx;
              return (
                <div key={s.key} className="flex flex-col items-center gap-2">
                  <motion.div
                    initial={{ scale: 0.8 }}
                    animate={{ scale: 1 }}
                    className={`w-10 h-10 rounded-full flex items-center justify-center border-2 z-10 relative transition-all ${active ? "bg-[#0B3D91] border-[#0B3D91] text-white shadow-lg shadow-blue-200" : done ? "bg-[#2E8B57] border-[#2E8B57] text-white" : "bg-background border-border text-muted-foreground"}`}
                  >
                    {done && !active ? <CheckCircle className="w-5 h-5" /> : s.icon}
                    {active && (
                      <motion.div className="absolute inset-0 rounded-full border-2 border-blue-400" animate={{ scale: [1, 1.4], opacity: [0.8, 0] }} transition={{ repeat: Infinity, duration: 1.5 }} />
                    )}
                  </motion.div>
                  <div className={`text-xs text-center font-medium leading-tight ${active ? "text-[#0B3D91] font-bold" : done ? "text-[#2E8B57]" : "text-muted-foreground"}`}>
                    {s.label}
                    {active && <div className="text-[10px] text-blue-500 font-normal">← Current</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Assigned Officer */}
        <div className="bg-white dark:bg-card rounded-3xl border border-border p-6 shadow-sm">
          <h3 className="font-heading font-bold text-foreground mb-4 flex items-center gap-2">
            <User className="w-5 h-5 text-[#0B3D91]" />Assigned Officer
          </h3>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#0B3D91] to-blue-600 flex items-center justify-center text-white text-2xl font-heading font-bold">
              {data.officer.name.charAt(0)}
            </div>
            <div>
              <div className="font-semibold text-foreground text-sm">{data.officer.name}</div>
              <div className="text-xs text-muted-foreground">Badge: {data.officer.badge}</div>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4 flex-shrink-0" />{data.officer.unit}
            </div>
            <a href={`tel:${data.officer.phone}`} className="flex items-center gap-2 text-sm text-[#0B3D91] font-medium hover:underline">
              <Phone className="w-4 h-4 flex-shrink-0" />Helpline: {data.officer.phone}
            </a>
          </div>

          <div className="mt-4 pt-4 border-t border-border">
            <div className="text-xs text-muted-foreground mb-1">AI Risk Score</div>
            <div className="h-2 bg-muted rounded-full overflow-hidden mb-1">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${data.riskScore}%` }}
                transition={{ duration: 0.8 }}
                className={`h-full rounded-full ${data.riskScore > 80 ? "bg-red-500" : data.riskScore > 60 ? "bg-amber-500" : "bg-green-500"}`}
              />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Risk Score</span>
              <span className="font-bold text-foreground">{data.riskScore}/100</span>
            </div>
          </div>
        </div>

        {/* Activity Log — takes 2 cols */}
        <div className="md:col-span-2 bg-white dark:bg-card rounded-3xl border border-border p-6 shadow-sm">
          <h3 className="font-heading font-bold text-foreground mb-5 flex items-center gap-2">
            <Clock className="w-5 h-5 text-[#0B3D91]" />Investigation Activity Log
          </h3>
          <div className="space-y-4 max-h-64 overflow-y-auto pr-1">
            {[...data.updates].reverse().map((u, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                className="flex gap-3">
                <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${u.stage === "resolved" ? "bg-green-500" : u.stage === "investigating" ? "bg-amber-500" : u.stage === "legal" ? "bg-orange-500" : "bg-blue-500"}`} />
                <div className="flex-1 pb-4 border-b border-border/50 last:border-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-semibold text-[#0B3D91]">{u.by}</span>
                    <span className="text-xs text-muted-foreground">{u.date}</span>
                  </div>
                  <p className="text-sm text-foreground leading-relaxed">{u.note}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Recovery Info if applicable */}
      {data.recoveredAmount && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          className="bg-green-50 dark:bg-green-950/20 rounded-2xl border border-green-200 dark:border-green-900/50 p-5 flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-green-100 dark:bg-green-900/30 flex items-center justify-center flex-shrink-0">
            <CheckCircle className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <div className="font-semibold text-green-800 dark:text-green-300 mb-0.5">Amount Recovery In Progress</div>
            <div className="text-sm text-green-700 dark:text-green-400">{data.recoveredAmount}</div>
            <div className="text-xs text-green-600 dark:text-green-500 mt-1">Courts have ordered the freeze. Disbursement follows case resolution.</div>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}

export default function CaseTracker() {
  const [input, setInput] = useState("");
  const [searched, setSearched] = useState("");
  const [loading, setLoading] = useState(false);
  const [notFound, setNotFound] = useState(false);

  const handleSearch = () => {
    const val = input.trim().toUpperCase();
    if (!val) return;
    setLoading(true);
    setNotFound(false);
    setSearched("");
    setTimeout(() => {
      setLoading(false);
      // Check built-in demo cases first
      if (CASES[val]) {
        setSearched(val);
        return;
      }
      // Check user-filed complaints from localStorage
      try {
        const stored: CaseData[] = JSON.parse(localStorage.getItem("shield_complaints") || "[]");
        const found = stored.find(c => c.id.toUpperCase() === val);
        if (found) {
          // Merge into CASES map so CaseResult can render it
          CASES[val] = found;
          setSearched(val);
          return;
        }
      } catch {}
      setNotFound(true);
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="bg-gradient-to-r from-[#0B3D91] via-blue-700 to-indigo-700 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center justify-center gap-3 mb-3">
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                <Fingerprint className="w-7 h-7" />
              </div>
              <h1 className="text-3xl font-heading font-bold">FIR & Case Status Tracker</h1>
            </div>
            <p className="text-blue-200 max-w-xl mx-auto text-sm">
              Enter your Case ID to see real-time investigation progress, assigned officer, amount recovery status, and estimated resolution.
            </p>

            {/* Search Box */}
            <div className="max-w-lg mx-auto mt-8">
              <div className="flex gap-3">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
                  <input
                    type="text"
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && handleSearch()}
                    placeholder="Enter Case ID (e.g. CC2024-4821)"
                    className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl pl-12 pr-4 py-4 text-white placeholder:text-white/40 outline-none focus:border-white/50 focus:bg-white/15 transition-all text-sm font-medium"
                    data-testid="input-case-id"
                  />
                </div>
                <Button
                  onClick={handleSearch}
                  disabled={loading || !input.trim()}
                  className="bg-[#FFB703] text-gray-900 hover:bg-[#e5a400] rounded-2xl px-6 font-bold text-sm h-auto"
                  data-testid="button-track-case"
                >
                  {loading ? (
                    <span className="flex items-center gap-2"><span className="w-4 h-4 border-2 border-gray-400 border-t-gray-800 rounded-full animate-spin" />Searching</span>
                  ) : (
                    <span className="flex items-center gap-2"><Search className="w-4 h-4" />Track</span>
                  )}
                </Button>
              </div>

              <div className="flex flex-wrap gap-2 mt-4 justify-center">
                <span className="text-blue-300 text-xs">Try demo cases:</span>
                {Object.keys(CASES).map(id => (
                  <button key={id} onClick={() => { setInput(id); setSearched(""); setNotFound(false); }}
                    className="text-xs bg-white/10 hover:bg-white/20 rounded-full px-3 py-1 text-white transition-colors border border-white/20">
                    {id}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10 max-w-5xl">
        {/* Info Boxes */}
        {!searched && !notFound && !loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="grid md:grid-cols-3 gap-5 mb-10">
              {[
                { icon: <Lock className="w-6 h-6 text-[#0B3D91]" />, title: "Secure & Private", desc: "Case details visible only to the complainant. End-to-end encrypted." },
                { icon: <RefreshCw className="w-6 h-6 text-[#2E8B57]" />, title: "Real-Time Updates", desc: "Investigation log updated within minutes of every action taken by the officer." },
                { icon: <MessageCircle className="w-6 h-6 text-purple-600" />, title: "Direct Contact", desc: "Contact your assigned officer directly via the case portal or call 1930." },
              ].map((c, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                  className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm text-center">
                  <div className="flex justify-center mb-3">{c.icon}</div>
                  <div className="font-heading font-bold text-foreground text-sm mb-1">{c.title}</div>
                  <div className="text-xs text-muted-foreground">{c.desc}</div>
                </motion.div>
              ))}
            </div>

            {/* How to get a case ID */}
            <div className="bg-blue-50 dark:bg-blue-950/20 rounded-2xl border border-blue-200 dark:border-blue-900/50 p-6">
              <h3 className="font-heading font-bold text-[#0B3D91] dark:text-blue-300 mb-3 flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />How to Get Your Case ID
              </h3>
              <div className="grid md:grid-cols-3 gap-4">
                {[
                  { n: "1", label: "File a Complaint", desc: "Use the 'Report Scam' button on this platform or call 1930." },
                  { n: "2", label: "Receive Case ID", desc: "A unique Case ID (CC2024-XXXX) is sent to your registered mobile via SMS." },
                  { n: "3", label: "Track Progress", desc: "Enter the Case ID here anytime to check your investigation status." },
                ].map(s => (
                  <div key={s.n} className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#0B3D91] text-white flex items-center justify-center text-sm font-bold flex-shrink-0">{s.n}</div>
                    <div>
                      <div className="text-sm font-semibold text-foreground mb-0.5">{s.label}</div>
                      <div className="text-xs text-muted-foreground">{s.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Not Found */}
        <AnimatePresence>
          {notFound && (
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
              className="bg-white dark:bg-card rounded-3xl border border-border p-10 shadow-sm text-center">
              <AlertCircle className="w-16 h-16 text-amber-400 mx-auto mb-4" />
              <h3 className="text-xl font-heading font-bold text-foreground mb-2">Case Not Found</h3>
              <p className="text-muted-foreground mb-6 max-w-sm mx-auto">No case found with ID <strong className="text-foreground">{input.toUpperCase()}</strong>. Please check your Case ID and try again.</p>
              <div className="bg-blue-50 dark:bg-blue-950/20 rounded-xl p-4 border border-blue-100 dark:border-blue-900/50 text-sm text-muted-foreground max-w-sm mx-auto mb-6">
                Your Case ID is sent via SMS to your registered mobile number when you file a complaint. It looks like <strong className="text-foreground">CC2024-XXXX</strong>.
              </div>
              <div className="flex flex-wrap gap-3 justify-center">
                <Button onClick={() => { setInput(""); setNotFound(false); }} variant="outline" className="rounded-full">Try Again</Button>
                <Button asChild className="rounded-full bg-[#0B3D91] text-white">
                  <a href="/report-scam">File New Complaint <ArrowRight className="ml-2 w-4 h-4" /></a>
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Case Result */}
        <AnimatePresence>
          {searched && CASES[searched] && <CaseResult key={searched} data={CASES[searched]} />}
        </AnimatePresence>

        {/* Stats footer */}
        {!searched && !notFound && (
          <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Cases Resolved", value: "8,241", icon: <CheckCircle className="w-5 h-5 text-green-500" /> },
              { label: "Avg Resolution Time", value: "4.2 days", icon: <Clock className="w-5 h-5 text-blue-500" /> },
              { label: "Amount Recovered", value: "₹12.4 Cr", icon: <TrendingUp className="w-5 h-5 text-amber-500" /> },
              { label: "Cases Active", value: "342", icon: <Search className="w-5 h-5 text-purple-500" /> },
            ].map((s, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                className="bg-white dark:bg-card rounded-2xl border border-border p-4 shadow-sm text-center">
                <div className="flex justify-center mb-2">{s.icon}</div>
                <div className="text-xl font-heading font-bold text-foreground">{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
