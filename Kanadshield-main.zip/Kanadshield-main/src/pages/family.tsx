import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Heart, MapPin, CheckCircle, Bell, Activity, Clock,
  Phone, Shield, Pill, Eye, TrendingUp, AlertTriangle, Users,
  Plus, X, Navigation
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

const seniors = [
  { id: 1, name: "Shantaben Patel", age: 72, avatar: "SP", status: "safe", lastSeen: "2 min ago", location: "Satellite Society", color: "bg-[#2E8B57]", phone: "+919876543210" },
  { id: 2, name: "Ramanbhai Shah", age: 68, avatar: "RS", status: "safe", lastSeen: "14 min ago", location: "Vastrapur", color: "bg-[#0B3D91]", phone: "+918765432109" },
  { id: 3, name: "Kamala Mehta", age: 75, avatar: "KM", status: "warning", lastSeen: "1 hr ago", location: "Bopal", color: "bg-amber-600", phone: "+917654321098" },
];

const heartRateData = [
  { time: "6am", rate: 72 }, { time: "9am", rate: 78 }, { time: "12pm", rate: 81 },
  { time: "3pm", rate: 76 }, { time: "6pm", rate: 74 }, { time: "9pm", rate: 70 },
];

const initialMedicines = [
  { id: 1, name: "Aspirin 75mg", time: "9:00 AM", status: "taken", next: "Tomorrow 9:00 AM" },
  { id: 2, name: "Metformin 500mg", time: "2:30 PM", status: "taken", next: "Tomorrow 2:30 PM" },
  { id: 3, name: "Amlodipine 5mg", time: "9:00 PM", status: "upcoming", next: "Today 9:00 PM" },
  { id: 4, name: "Vitamin D3", time: "9:00 AM", status: "taken", next: "Tomorrow 9:00 AM" },
];

export default function Family() {
  const [selected, setSelected] = useState(seniors[0]);
  const [checkedIn, setCheckedIn] = useState(false);
  const [checkInTime, setCheckInTime] = useState<string>("");
  const [medicines, setMedicines] = useState(initialMedicines);
  const [addMed, setAddMed] = useState(false);
  const [newMed, setNewMed] = useState({ name: "", time: "" });
  const [timeline, setTimeline] = useState([
    { time: "9:00 AM", event: "Daily check-in completed", type: "checkin" },
    { time: "9:15 AM", event: "Aspirin 75mg reminder — taken", type: "medicine" },
    { time: "11:30 AM", event: "Morning walk — 2,340 steps", type: "activity" },
    { time: "1:00 PM", event: "Location: Satellite Market", type: "location" },
    { time: "2:30 PM", event: "Metformin 500mg reminder — taken", type: "medicine" },
    { time: "4:00 PM", event: "Heart rate check — 76 BPM (Normal)", type: "health" },
  ]);
  const [alerts, setAlerts] = useState([
    { id: 1, msg: "Kamala Mehta: No check-in for 1 hour", severity: "warning", time: "20 min ago" },
    { id: 2, msg: "Shantaben: Medicine Amlodipine — due at 9:00 PM", severity: "info", time: "2 hr ago" },
    { id: 3, msg: "Ramanbhai: Weekly welfare visit scheduled", severity: "info", time: "3 hr ago" },
  ]);

  const handleCheckIn = () => {
    const now = new Date();
    const t = now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
    setCheckedIn(true);
    setCheckInTime(t);
    setTimeline(prev => [{ time: t, event: `Check-in confirmed for ${selected.name}`, type: "checkin" }, ...prev]);
    setAlerts(prev => prev.filter(a => !a.msg.includes(selected.name)));
  };

  const markMedicineTaken = (id: number) => {
    setMedicines(prev => prev.map(m => m.id === id ? { ...m, status: "taken" } : m));
    const med = medicines.find(m => m.id === id);
    if (med) {
      const now = new Date();
      const t = now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
      setTimeline(prev => [{ time: t, event: `${med.name} marked as taken`, type: "medicine" }, ...prev]);
    }
  };

  const addMedicine = () => {
    if (!newMed.name || !newMed.time) return;
    const id = Date.now();
    setMedicines(prev => [...prev, { id, name: newMed.name, time: newMed.time, status: "upcoming", next: `Today ${newMed.time}` }]);
    setNewMed({ name: "", time: "" });
    setAddMed(false);
  };

  const dismissAlert = (id: number) => setAlerts(prev => prev.filter(a => a.id !== id));

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#0B3D91] text-white py-8">
        <div className="container mx-auto px-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <Users className="w-6 h-6" />
              <h1 className="text-2xl font-heading font-bold">Family Dashboard</h1>
            </div>
            <p className="text-blue-200 text-sm">Real-time monitoring for your loved ones</p>
          </div>
          <Button onClick={handleCheckIn} disabled={checkedIn}
            className={`rounded-full font-semibold ${checkedIn ? "bg-green-500 hover:bg-green-600" : "bg-[#FFB703] text-gray-900 hover:bg-[#e5a400]"}`}
            data-testid="button-daily-checkin">
            {checkedIn ? (
              <><CheckCircle className="w-4 h-4 mr-2" />Checked In at {checkInTime}</>
            ) : (
              <><CheckCircle className="w-4 h-4 mr-2" />Daily Check-In</>
            )}
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Alerts */}
        <AnimatePresence>
          {alerts.length > 0 && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-6 space-y-2">
              {alerts.map(alert => (
                <motion.div key={alert.id} exit={{ opacity: 0, height: 0, marginBottom: 0 }} transition={{ duration: 0.2 }}
                  className={`flex items-center gap-3 rounded-xl px-4 py-3 border text-sm ${alert.severity === "warning" ? "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300" : "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900 text-blue-800 dark:text-blue-300"}`}>
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span className="flex-1">{alert.msg}</span>
                  <span className="text-xs opacity-70 flex-shrink-0">{alert.time}</span>
                  <button onClick={() => dismissAlert(alert.id)} className="opacity-60 hover:opacity-100 transition-opacity ml-1">
                    <X className="w-4 h-4" />
                  </button>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Senior Selector */}
        <div className="flex gap-3 mb-6 overflow-x-auto pb-2">
          {seniors.map((s) => (
            <button key={s.id} onClick={() => { setSelected(s); setCheckedIn(false); }}
              className={`flex items-center gap-3 px-4 py-3 rounded-2xl border-2 transition-all flex-shrink-0 ${selected.id === s.id ? "border-[#0B3D91] bg-blue-50 dark:bg-blue-950/20" : "border-border bg-white dark:bg-card hover:border-gray-300"}`}>
              <div className={`w-10 h-10 rounded-full ${s.color} flex items-center justify-center text-white text-sm font-bold flex-shrink-0`}>{s.avatar}</div>
              <div className="text-left">
                <div className="font-semibold text-foreground text-sm">{s.name}</div>
                <div className="text-xs text-muted-foreground">Age {s.age} · {s.lastSeen}</div>
              </div>
              <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${s.status === "safe" ? "bg-green-400" : "bg-amber-400 animate-pulse"}`} />
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="flex flex-col gap-5">
            {/* Status Card */}
            <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className="flex items-center gap-4 mb-5">
                <div className={`w-16 h-16 rounded-2xl ${selected.color} flex items-center justify-center text-white text-2xl font-heading font-bold`}>{selected.avatar}</div>
                <div>
                  <h2 className="font-heading font-bold text-foreground text-lg">{selected.name}</h2>
                  <div className="text-sm text-muted-foreground">Age {selected.age}</div>
                  <Badge className={`mt-1 text-xs ${selected.status === "safe" ? "bg-green-50 text-green-700 border-green-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}>
                    {selected.status === "safe" ? "✅ Safe" : "⚠️ Check Required"}
                  </Badge>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="w-4 h-4 text-[#0B3D91]" />{selected.location}
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="w-4 h-4 text-green-600" />Last seen: {selected.lastSeen}
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2">
                <a href={`tel:${selected.phone}`}
                  className="flex items-center justify-center gap-1.5 bg-[#0B3D91] text-white rounded-xl py-2.5 text-sm font-semibold hover:bg-[#0a3480] transition-colors">
                  <Phone className="w-4 h-4" />Call Now
                </a>
                <a href={`https://maps.google.com/?q=${encodeURIComponent(selected.location)}`} target="_blank" rel="noopener noreferrer"
                  className="flex items-center justify-center gap-1.5 border border-border text-foreground rounded-xl py-2.5 text-sm font-semibold hover:bg-muted transition-colors">
                  <Navigation className="w-4 h-4" />Location
                </a>
              </div>
            </div>

            {/* Heart Rate */}
            <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="font-semibold text-foreground flex items-center gap-2"><Heart className="w-4 h-4 text-red-500" />Heart Rate Today</div>
                <Badge className="bg-green-50 text-green-700 border-green-200">Normal</Badge>
              </div>
              <ResponsiveContainer width="100%" height={100}>
                <LineChart data={heartRateData}>
                  <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} domain={[60, 95]} />
                  <Tooltip />
                  <Line type="monotone" dataKey="rate" stroke="#ef4444" strokeWidth={2} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
              <div className="text-center text-2xl font-bold text-foreground mt-2">
                76 <span className="text-sm font-normal text-muted-foreground">BPM</span>
              </div>
            </div>
          </div>

          {/* Centre Column */}
          <div className="flex flex-col gap-5">
            {/* Medicine Tracker */}
            <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="font-semibold text-foreground flex items-center gap-2"><Pill className="w-4 h-4 text-purple-600" />Medicine Reminders</div>
                <button onClick={() => setAddMed(a => !a)} className="w-7 h-7 rounded-full bg-[#0B3D91] text-white flex items-center justify-center hover:bg-[#0a3480] transition-colors" aria-label="Add medicine">
                  {addMed ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                </button>
              </div>

              <AnimatePresence>
                {addMed && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                    className="mb-4 overflow-hidden">
                    <div className="bg-muted/50 rounded-xl p-3 space-y-2">
                      <input type="text" value={newMed.name} onChange={e => setNewMed(n => ({ ...n, name: e.target.value }))}
                        placeholder="Medicine name (e.g. Atorvastatin 10mg)" className="w-full text-sm bg-background border border-border rounded-lg px-3 py-2 outline-none focus:border-[#0B3D91]" />
                      <input type="time" value={newMed.time} onChange={e => setNewMed(n => ({ ...n, time: e.target.value }))}
                        className="w-full text-sm bg-background border border-border rounded-lg px-3 py-2 outline-none focus:border-[#0B3D91]" />
                      <Button onClick={addMedicine} size="sm" className="w-full bg-[#0B3D91] text-white rounded-lg text-xs">Add Reminder</Button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="space-y-3">
                {medicines.map((m) => (
                  <div key={m.id} className={`flex items-center justify-between p-3 rounded-xl border ${m.status === "taken" ? "bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-900/50" : "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800"}`}>
                    <div>
                      <div className="font-medium text-foreground text-sm">{m.name}</div>
                      <div className="text-xs text-muted-foreground">{m.time} · Next: {m.next}</div>
                    </div>
                    {m.status === "taken" ? (
                      <Badge className="bg-green-100 text-green-700 border-green-300 text-xs">✓ Taken</Badge>
                    ) : (
                      <Button onClick={() => markMedicineTaken(m.id)} size="sm"
                        className="bg-amber-500 hover:bg-amber-600 text-white text-xs rounded-full h-7 px-3" data-testid={`button-medicine-taken-${m.id}`}>
                        Mark Taken
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className="font-semibold text-foreground mb-4">Quick Actions</div>
              <div className="grid grid-cols-2 gap-3">
                <a href={`tel:${selected.phone}`} className="flex flex-col items-center gap-2 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-xl border border-blue-200 dark:border-blue-900/50 hover:bg-blue-100 transition-colors text-center">
                  <Phone className="w-6 h-6 text-[#0B3D91]" />
                  <span className="text-xs font-semibold text-foreground">Call Senior</span>
                </a>
                <a href="tel:100" className="flex flex-col items-center gap-2 p-4 bg-red-50 dark:bg-red-950/20 rounded-xl border border-red-200 dark:border-red-900/50 hover:bg-red-100 transition-colors text-center">
                  <Shield className="w-6 h-6 text-red-600" />
                  <span className="text-xs font-semibold text-foreground">Police SOS</span>
                </a>
                <a href="tel:108" className="flex flex-col items-center gap-2 p-4 bg-green-50 dark:bg-green-950/20 rounded-xl border border-green-200 dark:border-green-900/50 hover:bg-green-100 transition-colors text-center">
                  <Heart className="w-6 h-6 text-[#2E8B57]" />
                  <span className="text-xs font-semibold text-foreground">Ambulance 108</span>
                </a>
                <a href="tel:1930" className="flex flex-col items-center gap-2 p-4 bg-purple-50 dark:bg-purple-950/20 rounded-xl border border-purple-200 dark:border-purple-900/50 hover:bg-purple-100 transition-colors text-center">
                  <Bell className="w-6 h-6 text-purple-600" />
                  <span className="text-xs font-semibold text-foreground">Cyber Crime</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column — Timeline */}
          <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
            <div className="font-semibold text-foreground mb-4 flex items-center gap-2"><Activity className="w-4 h-4 text-[#0B3D91]" />Today's Activity</div>
            <div className="space-y-4 max-h-[480px] overflow-y-auto pr-1">
              {timeline.map((t, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                  className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    t.type === "checkin" ? "bg-green-100 text-green-600" :
                    t.type === "medicine" ? "bg-purple-100 text-purple-600" :
                    t.type === "activity" ? "bg-blue-100 text-blue-600" :
                    t.type === "location" ? "bg-amber-100 text-amber-600" :
                    "bg-red-100 text-red-600"
                  }`}>
                    {t.type === "checkin" ? <CheckCircle className="w-4 h-4" /> :
                     t.type === "medicine" ? <Pill className="w-4 h-4" /> :
                     t.type === "activity" ? <Activity className="w-4 h-4" /> :
                     t.type === "location" ? <MapPin className="w-4 h-4" /> :
                     <Heart className="w-4 h-4" />}
                  </div>
                  <div className="flex-1 pb-4 border-b border-border/50 last:border-0">
                    <div className="text-sm text-foreground">{t.event}</div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Clock className="w-3 h-3" />{t.time}</div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
