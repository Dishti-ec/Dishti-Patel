import React, { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Link, useLocation } from "wouter";
import {
  Phone, Mail, MapPin, Clock, Shield, CheckCircle, AlertTriangle,
  MessageSquare, Send, Siren, ExternalLink
} from "lucide-react";

const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit mobile number"),
  email: z.string().email("Enter a valid email address"),
  subject: z.string().min(5, "Subject must be at least 5 characters"),
  message: z.string().min(20, "Message must be at least 20 characters"),
});

type FormData = z.infer<typeof formSchema>;

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [refId] = useState(`SC-${Math.floor(Math.random() * 90000) + 10000}`);
  const [, setLocation] = useLocation();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: { name: "", phone: "", email: "", subject: "", message: "" },
  });

  const onSubmit = (data: FormData) => {
    // Open mailto as a real fallback
    const body = encodeURIComponent(`Name: ${data.name}\nMobile: ${data.phone}\nEmail: ${data.email}\n\nSubject: ${data.subject}\n\n${data.message}`);
    const mailtoLink = `mailto:support@vriddhaksha.in?subject=${encodeURIComponent(data.subject)}&body=${body}`;
    window.open(mailtoLink, "_blank");
    setTimeout(() => setSubmitted(true), 500);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#0B3D91] text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <MessageSquare className="w-7 h-7" />
            <h1 className="text-3xl font-heading font-bold">Contact Us</h1>
          </div>
          <p className="text-blue-200 max-w-2xl mx-auto">Reach out to the VRIDDHAKSHA support team. We're here to help — 24 hours a day, 7 days a week.</p>
        </div>
      </div>

      {/* Emergency Hotline Banner — all numbers are clickable */}
      <div className="bg-red-600 text-white py-5">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap items-center justify-center gap-8">
            {[
              { label: "Cyber Crime Helpline", num: "1930", tel: "1930" },
              { label: "Police Emergency", num: "100", tel: "100" },
              { label: "Ambulance", num: "108", tel: "108" },
              { label: "National Emergency", num: "112", tel: "112" },
            ].map((h, i) => (
              <a key={i} href={`tel:${h.tel}`} className="flex items-center gap-3 hover:opacity-80 transition-opacity group">
                <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 1.5, delay: i * 0.3 }}>
                  <Phone className="w-7 h-7" />
                </motion.div>
                <div>
                  <div className="text-xs opacity-80 uppercase tracking-wider">{h.label}</div>
                  <div className="text-3xl font-heading font-bold group-hover:underline">{h.num}</div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-2 gap-10 max-w-5xl mx-auto">
          {/* Contact Info */}
          <div>
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
              <h2 className="text-2xl font-heading font-bold text-foreground mb-6">Get in Touch</h2>

              <div className="space-y-5 mb-8">
                {[
                  {
                    icon: <MapPin className="w-5 h-5" />, label: "Support",
                    value: "VRIDDHAKSHA Support Center — online assistance available nationwide",
                    color: "text-[#0B3D91] bg-blue-50 dark:bg-blue-950/30",
                    href: null,
                  },
                  {
                    icon: <Phone className="w-5 h-5" />, label: "Phone",
                    value: "1930 (Cyber Safety Helpline) · +91-79-2562-1111",
                    color: "text-[#2E8B57] bg-green-50 dark:bg-green-950/30",
                    href: "tel:1930",
                  },
                  {
                    icon: <Mail className="w-5 h-5" />, label: "Email",
                    value: "support@vriddhaksha.in",
                    color: "text-amber-600 bg-amber-50 dark:bg-amber-950/30",
                    href: "mailto:support@vriddhaksha.in",
                  },
                  {
                    icon: <Clock className="w-5 h-5" />, label: "Office Hours",
                    value: "Mon–Sat: 9:00 AM – 8:00 PM · Emergency Helpline: 24 × 7",
                    color: "text-purple-600 bg-purple-50 dark:bg-purple-950/30",
                    href: null,
                  },
                ].map((info, i) => (
                  <div key={i} className="flex items-start gap-4">
                    <div className={`w-10 h-10 rounded-xl ${info.color} flex items-center justify-center flex-shrink-0`}>{info.icon}</div>
                    <div>
                      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">{info.label}</div>
                      {info.href ? (
                        <a href={info.href} target={info.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer"
                          className="text-sm text-foreground leading-relaxed hover:underline hover:text-[#0B3D91] transition-colors">
                          {info.value}
                        </a>
                      ) : (
                        <div className="text-sm text-foreground leading-relaxed">{info.value}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-blue-50 dark:bg-blue-950/20 rounded-2xl p-4 border border-blue-200 dark:border-blue-900/50 mb-6">
                <div className="flex items-center gap-2">
                  <Shield className="w-8 h-8 text-[#0B3D91] flex-shrink-0" />
                  <div className="flex-1">
                    <div className="font-semibold text-[#0B3D91] text-sm">24×7 Online Support</div>
                    <div className="text-xs text-muted-foreground">Reach us by phone, email, or the contact form below</div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-[#0B3D91] to-blue-600 rounded-2xl p-6 text-white mb-6">
                <div className="flex items-center gap-3 mb-3">
                  <Shield className="w-6 h-6" />
                  <div className="font-heading font-bold text-lg">VRIDDHAKSHA Protection</div>
                </div>
                <p className="text-blue-200 text-sm mb-4">Register your senior family members for round-the-clock protection, AI scam detection, and direct police integration.</p>
                <div className="flex items-center gap-2 text-sm mb-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span>Free for all senior citizens above age 60</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span>Registration takes less than 5 minutes</span>
                </div>
              </div>

              <div className="bg-amber-50 dark:bg-amber-950/20 rounded-2xl p-5 border border-amber-200 dark:border-amber-800">
                <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 font-semibold mb-2">
                  <AlertTriangle className="w-4 h-4" />Report a Cyber Crime
                </div>
                <p className="text-sm text-muted-foreground mb-3">If you or a family member has been cheated online, report immediately. The faster you report, the higher the chance of recovering your money.</p>
                <div className="grid grid-cols-2 gap-3">
                  <Link href="/report-scam">
                    <Button className="w-full bg-[#0B3D91] text-white rounded-xl font-semibold hover:bg-[#0a3480]" data-testid="button-report-online">
                      <Shield className="w-4 h-4 mr-2" />Report Online
                    </Button>
                  </Link>
                  <a href="tel:1930">
                    <Button variant="outline" className="w-full rounded-xl font-semibold border-[#0B3D91] text-[#0B3D91] hover:bg-blue-50" data-testid="button-call-1930">
                      <Phone className="w-4 h-4 mr-2" />Call 1930
                    </Button>
                  </a>
                </div>
              </div>

              {/* Social + Official Links */}
              <div className="mt-6">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Official Resources</div>
                <div className="space-y-2">
                  {[
                    { label: "National Cyber Crime Portal", href: "https://cybercrime.gov.in", icon: "🌐" },
                    { label: "National Consumer Helpline", href: "https://consumerhelpline.gov.in", icon: "📞" },
                    { label: "SEBI Investor Complaint Portal", href: "https://scores.sebi.gov.in", icon: "📋" },
                  ].map((link, i) => (
                    <a key={i} href={link.href} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-3 p-3 bg-muted/50 rounded-xl hover:bg-muted transition-colors text-sm text-foreground hover:text-[#0B3D91]">
                      <span>{link.icon}</span>
                      <span className="flex-1">{link.label}</span>
                      <ExternalLink className="w-3.5 h-3.5 text-muted-foreground" />
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>

          {/* Contact Form */}
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
            <div className="bg-white dark:bg-card rounded-3xl border border-border p-8 shadow-sm">
              {submitted ? (
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12">
                  <div className="w-20 h-20 bg-green-100 dark:bg-green-950/30 rounded-full flex items-center justify-center mx-auto mb-5">
                    <CheckCircle className="w-10 h-10 text-green-600" />
                  </div>
                  <h3 className="text-2xl font-heading font-bold text-foreground mb-3">Message Sent!</h3>
                  <p className="text-muted-foreground mb-3">Your email client opened with the message pre-filled. Our team will respond within 24 hours.</p>
                  <p className="text-muted-foreground text-sm mb-6">For urgent matters, call <a href="tel:1930" className="font-bold text-[#0B3D91] hover:underline">1930</a>.</p>
                  <Badge className="bg-green-50 text-green-700 border-green-200 px-4 py-2 text-sm">Reference: {refId}</Badge>
                  <div className="mt-6">
                    <Button onClick={() => setSubmitted(false)} variant="outline" className="rounded-full">Send Another Message</Button>
                  </div>
                </motion.div>
              ) : (
                <>
                  <h2 className="text-2xl font-heading font-bold text-foreground mb-6">Send a Message</h2>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField control={form.control} name="name" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground font-medium">Full Name</FormLabel>
                            <FormControl><Input {...field} placeholder="Ramesh Patel" className="rounded-xl" data-testid="input-name" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="phone" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground font-medium">Mobile Number</FormLabel>
                            <FormControl><Input {...field} placeholder="9876543210" className="rounded-xl" data-testid="input-phone" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>
                      <FormField control={form.control} name="email" render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground font-medium">Email Address</FormLabel>
                          <FormControl><Input {...field} type="email" placeholder="ramesh@example.com" className="rounded-xl" data-testid="input-email" /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={form.control} name="subject" render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground font-medium">Subject</FormLabel>
                          <FormControl><Input {...field} placeholder="Report a scam / Register for VRIDDHAKSHA / General enquiry" className="rounded-xl" data-testid="input-subject" /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={form.control} name="message" render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground font-medium">Message</FormLabel>
                          <FormControl>
                            <textarea {...field} rows={4} placeholder="Describe your concern in detail..."
                              className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 resize-none"
                              data-testid="input-message" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <Button type="submit" className="w-full bg-[#0B3D91] hover:bg-[#0a3480] text-white rounded-xl py-6 font-semibold text-base" data-testid="button-submit-contact">
                        <Send className="w-5 h-5 mr-2" />Send Message
                      </Button>
                      <p className="text-xs text-center text-muted-foreground">
                        This will open your email client with the message pre-filled to support@vriddhaksha.in
                      </p>
                    </form>
                  </Form>
                </>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
