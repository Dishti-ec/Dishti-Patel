import React, { useState } from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Search, BookOpen, Smartphone, CreditCard, TrendingUp, FileText,
  QrCode, Mic, Video, Shield, ArrowRight, AlertTriangle, Bell
} from "lucide-react";

const categories = ["All", "Cyber Fraud", "Digital Safety", "Emergency", "Health"];

const articles = [
  {
    category: "Cyber Fraud", severity: "Critical",
    icon: <Smartphone className="w-6 h-6" />, color: "text-blue-600 bg-blue-50",
    title: "OTP Scam: How Fraudsters Steal in Seconds",
    preview: "Learn the telltale signs of OTP fraud and why you should never share your one-time password with anyone.",
    content: `An OTP (One-Time Password) scam is one of the most common frauds targeting senior citizens. Here's what you need to know:\n\n**How it happens:**\nA caller claims to be from your bank, RBI, or a government department. They say your account is blocked, your KYC is pending, or you've won a prize. They ask you to share the OTP received on your phone to "verify" your identity or "process" something.\n\n**The truth:**\nThe moment you share the OTP, they use it to transfer money out of your account or make unauthorized purchases.\n\n**Golden Rules:**\n• No bank, RBI, or government body will EVER ask for your OTP\n• Your OTP is as sensitive as your account PIN — never share it\n• Hang up immediately if asked for OTP\n• Call your bank's official number to verify any concern\n\n**If it happens to you:**\nCall your bank immediately (number on the card back), file a complaint at 1930 (Cyber Safety Helpline), and visit the nearest police station.`
  },
  {
    category: "Cyber Fraud", severity: "High",
    icon: <CreditCard className="w-6 h-6" />, color: "text-green-600 bg-green-50",
    title: "UPI Fraud: Approving is Paying",
    preview: "A 'collect request' on UPI means money goes OUT of your account — learn why and how to stay safe.",
    content: `UPI (Unified Payments Interface) frauds are increasingly targeting senior citizens who may not be familiar with how payment apps work.\n\n**The common trap:**\nFraudsters send a UPI 'collect' or 'payment request' saying they are sending you money, a refund, or a prize. When you click 'Approve' or enter your UPI PIN, money is deducted from YOUR account.\n\n**Why this works:**\nThe interface for sending and receiving looks similar. Scammers exploit this confusion, especially with seniors.\n\n**How UPI actually works:**\n• To RECEIVE money: the sender initiates — you do nothing\n• To SEND money: you scan QR code or enter UPI ID and your PIN\n• Any request asking for your PIN to "receive" money is ALWAYS a scam\n\n**Safe UPI practices:**\n• Never enter PIN for incoming payments\n• Never approve collect requests from strangers\n• Use BHIM or bank apps — avoid third-party apps you don't recognize\n• Enable transaction limits in your UPI app`
  },
  {
    category: "Cyber Fraud", severity: "Critical",
    icon: <TrendingUp className="w-6 h-6" />, color: "text-purple-600 bg-purple-50",
    title: "Fake Investment Schemes Targeting Retirees",
    preview: "Promises of 30%+ monthly returns are always fraudulent. Understand how Ponzi schemes work to protect your savings.",
    content: `Investment fraud is devastating for seniors because it targets retirement savings that took a lifetime to accumulate.\n\n**Common schemes:**\n• WhatsApp/Telegram groups promising 'stock tips' for massive returns\n• Fake apps showing daily 'profits' on a dashboard\n• Agents promising 3-5x returns in 6 months\n• Cryptocurrency investment platforms with guaranteed returns\n\n**How Ponzi schemes work:**\nEarly investors are paid using money from new investors — creating the illusion of real returns. Eventually the scheme collapses and everyone loses.\n\n**Warning signs:**\n• Guaranteed returns (no legitimate investment guarantees returns)\n• Pressure to invest quickly or "lose the offer"\n• Returns that seem too good to be true (>12% annually is already high)\n• Requests to recruit friends/family\n• Unregistered brokers or platforms\n\n**Verify before investing:**\nCheck if the platform/advisor is registered with SEBI at sebi.gov.in. Any entity offering financial advice or investment products must be SEBI registered.`
  },
  {
    category: "Cyber Fraud", severity: "High",
    icon: <FileText className="w-6 h-6" />, color: "text-amber-600 bg-amber-50",
    title: "KYC Scam: The Update That Drains Accounts",
    preview: "Fake KYC update requests are a gateway to complete account takeover. Real KYC never happens over the phone.",
    content: `KYC (Know Your Customer) fraud exploits the mandatory compliance requirements that banks enforce.\n\n**The scam:**\nYou receive a call or message saying your account will be blocked in 24 hours if you don't complete KYC. They send a link or ask you to share documents, Aadhaar number, bank details.\n\n**What really happens:**\nWith your Aadhaar and bank details, fraudsters can clone your SIM, access your bank account, take loans in your name, and file fake income tax refunds.\n\n**The truth about KYC:**\n• Real KYC is done physically at your bank branch\n• Banks never ask for KYC over phone calls\n• Banks never send links for KYC — they send physical notices or in-app notifications\n• No KYC process requires you to share your OTP or password\n\n**If you receive a KYC call:**\nHang up. Call your bank's official customer care (number on the back of your card) and ask if there's actually a KYC requirement.`
  },
  {
    category: "Digital Safety", severity: "Medium",
    icon: <QrCode className="w-6 h-6" />, color: "text-red-600 bg-red-50",
    title: "QR Code Fraud: Scanning is Paying",
    preview: "Scanning a QR code can only send money from your account — never receive it. This simple fact prevents many scams.",
    content: `QR code scams are highly effective because many people don't understand how QR codes work.\n\n**The scam:**\n"I'm sending you ₹10,000 for the item. Scan this QR code to receive it." When you scan and enter your PIN, ₹10,000 goes OUT of your account.\n\n**How QR codes actually work:**\nIn UPI, a QR code is always a payment destination — it tells your app WHERE to send money. There is no mechanism for a QR code to push money INTO your account.\n\n**Variations of this scam:**\n• Selling items online — buyer sends QR code for payment\n• "Refund" QR codes from fake customer service\n• WhatsApp messages with QR codes for prizes\n\n**Simple rule:**\nIf someone sends you a QR code and says "scan to receive money" — it is ALWAYS a scam. You can only receive money if the other person initiates from their end.`
  },
  {
    category: "Digital Safety", severity: "Critical",
    icon: <Smartphone className="w-6 h-6" />, color: "text-teal-600 bg-teal-50",
    title: "SIM Swap Attack: When Your Number is Stolen",
    preview: "Losing mobile signal suddenly can mean a SIM swap attack is underway. Act within minutes to protect your accounts.",
    content: `SIM swap is one of the most technically sophisticated frauds targeting bank accounts.\n\n**How it works:**\n1. Fraudsters gather your personal info (often from data breaches or social engineering)\n2. They visit a mobile store with fake ID documents\n3. They convince the operator that they lost their SIM and need a new one\n4. Your SIM gets deactivated — you lose signal\n5. They now receive all your OTPs and calls\n6. They drain your bank accounts using your OTPs\n\n**Warning signs:**\n• Your phone suddenly loses all signal for no reason\n• You can't make or receive calls or SMS\n• You stop receiving OTPs for transactions you didn't initiate\n\n**Immediate action (within minutes):**\n• Call your mobile operator from another phone — report SIM fraud\n• Call your bank — freeze all accounts and internet banking\n• File a complaint at 1930\n\n**Prevention:**\n• Enable SIM lock at your telecom provider\n• Set a complex PIN for SIM changes at the operator level\n• Don't share personal details on social media`
  },
  {
    category: "Digital Safety", severity: "High",
    icon: <Mic className="w-6 h-6" />, color: "text-orange-600 bg-orange-50",
    title: "Voice Phishing (Vishing): The Convincing Caller",
    preview: "Caller ID can be faked to show any number — including real bank numbers. Learn to verify calls independently.",
    content: `Vishing (voice phishing) uses phone calls to deceive victims, often using social engineering and caller ID spoofing.\n\n**Common scenarios:**\n• Fake RBI officials threatening account suspension\n• Fake police warning about illegal activity in your name\n• Fake bank staff asking to "verify" your details\n• Fake tech support for your computer or phone\n• Fake customs officials about a package containing cash\n\n**The tactics:**\n• Creating urgency ("your account will be blocked in 2 hours")\n• Using fear ("you'll be arrested if you don't cooperate")\n• Impersonating authority ("I am calling from the police")\n• Caller ID spoofing (making calls appear to come from legitimate numbers)\n\n**Always remember:**\n• No government body will demand immediate payment by phone\n• Police don't arrest people over phone calls\n• Banks won't ask for your full card number, CVV, PIN, or OTP\n• Hang up and call back on the OFFICIAL number — never the one they give you`
  },
  {
    category: "Digital Safety", severity: "Critical",
    icon: <Video className="w-6 h-6" />, color: "text-pink-600 bg-pink-50",
    title: "AI Deepfake Scam: When You Can't Trust Your Eyes",
    preview: "AI can clone anyone's face and voice. Learn to spot deepfake video calls and protect yourself from this emerging threat.",
    content: `AI deepfake scams are the newest and most alarming cyber threat. They use artificial intelligence to create hyper-realistic fake videos and audio.\n\n**How it happens:**\nYou receive a video call from what appears to be your son/daughter/relative. They look real, sound real, and their face matches. They say they're in an emergency — an accident, arrested, or hospitalized — and need money urgently. You transfer money before realizing it was fake.\n\n**Why it's so convincing:**\nModern AI can clone a face from as few as 10 photos (available on social media) and create real-time video. Voice cloning needs only a few seconds of audio.\n\n**How to protect yourself:**\n• Always call back the person on their KNOWN phone number before sending money\n• Establish a family code word that only real family members know\n• Ask the caller something only the real person would know\n• If receiving a video call for money — always say "I'll call you back"\n• Check if the face looks slightly off, blurry at edges, or unnatural\n\n**The 24-hour rule:**\nFor any financial request from family over video/voice — wait 24 hours and verify through a second channel. Real emergencies have multiple ways to verify.`
  },
];

export default function Resources() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [selected, setSelected] = useState<typeof articles[0] | null>(null);

  const filtered = articles.filter(a =>
    (category === "All" || a.category === category) &&
    (a.title.toLowerCase().includes(search.toLowerCase()) || a.preview.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#0B3D91] text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <BookOpen className="w-7 h-7" />
            <h1 className="text-3xl font-heading font-bold">Awareness Center</h1>
          </div>
          <p className="text-blue-200 max-w-2xl mx-auto">Knowledge is your strongest defence. Learn to recognise and avoid every type of cyber scam.</p>

          <div className="mt-8 max-w-xl mx-auto">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-blue-300" />
              <input
                type="search"
                placeholder="Search articles..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-12 pr-4 py-3 rounded-full bg-white/10 border border-white/20 text-white placeholder:text-blue-200 focus:outline-none focus:ring-2 focus:ring-white/30 backdrop-blur-sm"
                data-testid="input-search"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Scam Alert Banner */}
      <div className="bg-red-600 text-white py-3">
        <div className="container mx-auto px-4 flex items-center gap-3">
          <Bell className="w-5 h-5 flex-shrink-0 animate-pulse" />
          <p className="text-sm font-medium">
            <strong>SCAM ALERT:</strong> Fraudsters posing as KBC representatives are calling seniors offering prizes. Do NOT call back or share any details.
          </p>
          <Badge className="bg-white text-red-600 text-xs flex-shrink-0">NEW</Badge>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Category Tabs */}
        <div className="flex gap-3 mb-8 flex-wrap">
          {categories.map(cat => (
            <button key={cat} onClick={() => setCategory(cat)}
              className={`px-5 py-2 rounded-full text-sm font-semibold border transition-all ${category === cat ? "bg-[#0B3D91] text-white border-[#0B3D91]" : "bg-white dark:bg-card text-foreground border-border hover:border-[#0B3D91] hover:text-[#0B3D91]"}`}
              data-testid={`tab-category-${cat}`}>
              {cat}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Shield className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p>No articles found for your search.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
            {filtered.map((article, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                whileHover={{ y: -4 }}
                onClick={() => setSelected(article)}
                className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm hover:shadow-lg transition-all cursor-pointer group"
                data-testid={`card-article-${i}`}>
                <div className={`w-12 h-12 rounded-xl ${article.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  {article.icon}
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge className="text-xs bg-muted text-muted-foreground border-0">{article.category}</Badge>
                  <Badge className={`text-xs ${article.severity === "Critical" ? "bg-red-50 text-red-600 border-red-200" : article.severity === "High" ? "bg-amber-50 text-amber-600 border-amber-200" : "bg-green-50 text-green-600 border-green-200"}`}>
                    {article.severity}
                  </Badge>
                </div>
                <h3 className="font-heading font-bold text-foreground text-sm mb-2 leading-snug">{article.title}</h3>
                <p className="text-xs text-muted-foreground line-clamp-3 mb-4">{article.preview}</p>
                <div className="flex items-center gap-1 text-xs font-semibold text-[#0B3D91] group-hover:gap-2 transition-all">
                  Learn More <ArrowRight className="w-3 h-3" />
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Government Resources Download Section */}
      <div className="bg-muted/50 border-t border-border mt-4">
        <div className="container mx-auto px-4 py-10">
          <h2 className="text-xl font-heading font-bold text-foreground mb-2">Official Government Resources</h2>
          <p className="text-sm text-muted-foreground mb-6">Download official guides and access government portals for cyber safety</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { title: "National Cyber Crime Handbook", desc: "Official handbook by MeitY on cyber crime prevention", icon: "📘", href: "https://www.meity.gov.in/content/cyber-crime" },
              { title: "RBI Safe Banking Guide", desc: "Reserve Bank of India — avoid digital payment frauds", icon: "🏦", href: "https://www.rbi.org.in/Scripts/PublicationsView.aspx?id=20430" },
              { title: "Report at Cybercrime.gov.in", desc: "File an official complaint on the national portal", icon: "🌐", href: "https://cybercrime.gov.in" },
              { title: "CERT-In Security Advisories", desc: "Latest cyber threat alerts from India's CERT", icon: "🔒", href: "https://www.cert-in.org.in/s2cMainServlet?pageid=PUBADVISE" },
              { title: "TRAI Spam Reporting (SANCHARSAATHI)", desc: "Report fraud calls and SMS through the govt. portal", icon: "📱", href: "https://sancharsaathi.gov.in/sfc/" },
              { title: "National Consumer Helpline", desc: "Report fraud and consumer grievances — toll-free support", icon: "📞", href: "https://consumerhelpline.gov.in" },
            ].map((r, i) => (
              <a key={i} href={r.href} target="_blank" rel="noopener noreferrer"
                className="flex items-start gap-4 p-4 bg-white dark:bg-card rounded-2xl border border-border hover:border-[#0B3D91] hover:shadow-md transition-all group">
                <div className="text-2xl flex-shrink-0">{r.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-foreground text-sm mb-1 group-hover:text-[#0B3D91] transition-colors">{r.title}</div>
                  <div className="text-xs text-muted-foreground leading-relaxed">{r.desc}</div>
                </div>
                <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-[#0B3D91] group-hover:translate-x-0.5 transition-all flex-shrink-0 mt-0.5" />
              </a>
            ))}
          </div>
        </div>
      </div>

      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-lg rounded-2xl max-h-[80vh] overflow-y-auto">
          {selected && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className={`w-12 h-12 rounded-xl ${selected.color} flex items-center justify-center flex-shrink-0`}>{selected.icon}</div>
                  <DialogTitle className="text-lg font-heading leading-snug">{selected.title}</DialogTitle>
                </div>
                <div className="flex gap-2">
                  <Badge className="w-fit bg-muted text-muted-foreground border-0">{selected.category}</Badge>
                  <Badge className={`w-fit ${selected.severity === "Critical" ? "bg-red-50 text-red-600 border-red-200" : "bg-amber-50 text-amber-600 border-amber-200"}`}>{selected.severity} Risk</Badge>
                </div>
              </DialogHeader>
              <div className="space-y-3">
                {selected.content.split("\n\n").map((para, i) => (
                  <p key={i} className={`text-sm leading-relaxed ${para.startsWith("**") ? "font-semibold text-foreground" : "text-muted-foreground"}`}>
                    {para.replace(/\*\*/g, "")}
                  </p>
                ))}
              </div>
              <div className="bg-red-50 dark:bg-red-950/20 rounded-xl p-4 border border-red-100 dark:border-red-900/50 mt-4">
                <div className="flex items-center gap-2 text-red-700 dark:text-red-400 font-semibold text-sm mb-2">
                  <AlertTriangle className="w-4 h-4" />If you are a victim — act immediately:
                </div>
                <div className="text-sm text-muted-foreground mb-3">Don't delay — the faster you report, the higher the chance of recovering your money.</div>
                <div className="grid grid-cols-2 gap-2">
                  <a href="tel:1930" className="flex items-center justify-center gap-2 bg-red-600 text-white rounded-xl py-2.5 text-sm font-bold hover:bg-red-700 transition-colors">
                    <Shield className="w-4 h-4" />Call 1930
                  </a>
                  <a href="https://cybercrime.gov.in" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 border border-red-300 text-red-700 dark:text-red-400 rounded-xl py-2.5 text-sm font-semibold hover:bg-red-100/50 dark:hover:bg-red-950/30 transition-colors">
                    <ArrowRight className="w-4 h-4" />Report Online
                  </a>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
