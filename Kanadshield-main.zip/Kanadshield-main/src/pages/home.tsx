import React, { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useI18n } from "@/lib/i18n";
import {
  Shield, AlertTriangle, Phone, Users, Heart, FileText,
  Activity, MapPin, Bell, CheckCircle, ChevronDown, Zap,
  Eye, Lock, Wifi, Smartphone, Star, TrendingUp, Clock,
  ArrowRight, Play, Bot, BookOpen, AlertCircle,
  PhoneCall, Siren, CreditCard, QrCode, Mic, Video,
  ShieldCheck, Cpu, ScanLine, Database
} from "lucide-react";

function AnimatedCounter({ target, suffix = "", duration = 2000 }: { target: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) { setCount(target); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [inView, target, duration]);

  return <span ref={ref}>{count}{suffix}</span>;
}

const features = [
  {
    icon: <Siren className="w-7 h-7" />,
    title: "Emergency SOS",
    color: "text-red-500",
    bg: "bg-red-50 dark:bg-red-950/30",
    border: "border-red-100 dark:border-red-900/50",
    items: ["Large emergency button", "Voice activation", "GPS location sharing", "Medical alerts", "Police notification", "Family notification"],
    link: "/emergency"
  },
  {
    icon: <Shield className="w-7 h-7" />,
    title: "Cyber Fraud Protection",
    color: "text-[#0B3D91]",
    bg: "bg-blue-50 dark:bg-blue-950/30",
    border: "border-blue-100 dark:border-blue-900/50",
    items: ["AI Scam Detection", "Phishing Detection", "OTP Scam Alerts", "Fake Investment Detection", "Bank Fraud Warning", "Real-time Scam Alerts"],
  },
  {
    icon: <Database className="w-7 h-7" />,
    title: "Evidence Collection",
    color: "text-purple-600",
    bg: "bg-purple-50 dark:bg-purple-950/30",
    border: "border-purple-100 dark:border-purple-900/50",
    items: ["Upload screenshots", "Upload call recordings", "Timestamp evidence", "Secure encrypted storage", "Case history tracking"],
  },
  {
    icon: <ShieldCheck className="w-7 h-7" />,
    title: "Police Integration",
    color: "text-[#2E8B57]",
    bg: "bg-green-50 dark:bg-green-950/30",
    border: "border-green-100 dark:border-green-900/50",
    items: ["Direct Cyber Crime reporting", "FIR status tracking", "Case management", "Emergency dispatch", "24/7 live support"],
    link: "/case-tracker"
  },
  {
    icon: <Users className="w-7 h-7" />,
    title: "Family Dashboard",
    color: "text-orange-500",
    bg: "bg-orange-50 dark:bg-orange-950/30",
    border: "border-orange-100 dark:border-orange-900/50",
    items: ["Caregiver monitoring", "Emergency notifications", "Daily check-ins", "Real-time location updates"],
    link: "/family"
  },
  {
    icon: <Heart className="w-7 h-7" />,
    title: "Health & Welfare",
    color: "text-pink-500",
    bg: "bg-pink-50 dark:bg-pink-950/30",
    border: "border-pink-100 dark:border-pink-900/50",
    items: ["Medicine reminders", "Wearable integration", "Health alerts", "Police welfare visits", "Daily wellness tracking"],
  },
];

const steps = [
  { icon: <ScanLine className="w-6 h-6" />, title: "Detect Threat", desc: "AI monitors calls, messages & transactions for suspicious patterns", color: "bg-blue-500" },
  { icon: <Cpu className="w-6 h-6" />, title: "Verify with AI", desc: "Advanced ML model classifies threat with 97.3% accuracy", color: "bg-purple-500" },
  { icon: <Bell className="w-6 h-6" />, title: "Alert Senior Citizen", desc: "Immediate notification via app, SMS and voice alert", color: "bg-amber-500" },
  { icon: <Users className="w-6 h-6" />, title: "Notify Family", desc: "Caregivers get real-time update and can intervene instantly", color: "bg-orange-500" },
  { icon: <ShieldCheck className="w-6 h-6" />, title: "Notify Police Safety Network", desc: "Case securely routed to the appropriate response team", color: "bg-green-500" },
  { icon: <CheckCircle className="w-6 h-6" />, title: "Track Resolution", desc: "End-to-end case tracking until scammer is caught", color: "bg-teal-500" },
];

const scamMessages = {
  message: "URGENT: Your SBI account has been blocked. Click here to update KYC immediately: bit.ly/sbi-kyc-update",
  call: "Caller: Hello, I am calling from RBI. Your bank account has suspicious transactions. To avoid freezing, share your OTP now.",
  whatsapp: "Congratulations! You have won Rs. 50,000 in KBC Lucky Draw. Send your Aadhaar card and bank details to claim prize.",
  email: "Dear Customer, Your PAN card has been linked to illegal activities. Pay Rs. 5000 fine within 24 hours to avoid arrest.",
};

const scamResults: Record<string, { label: "SAFE" | "SUSPICIOUS" | "SCAM"; confidence: number; reasons: string[] }> = {
  message: { label: "SCAM", confidence: 97, reasons: ["Fake bank domain link", "Urgency pressure tactic", "KYC scam pattern", "Shortened URL (bit.ly) masking real destination"] },
  call: { label: "SCAM", confidence: 99, reasons: ["Impersonation of RBI", "OTP solicitation (banks never ask for OTP)", "Threat-based coercion", "Voice phishing (Vishing) pattern"] },
  whatsapp: { label: "SCAM", confidence: 95, reasons: ["Lottery prize fraud pattern", "Requesting personal identity documents", "Bank details solicitation", "KBC lottery fraud"] },
  email: { label: "SCAM", confidence: 98, reasons: ["Fake arrest threat (a common tactic)", "Demand for immediate payment", "PAN card fraud pattern", "Time pressure manipulation"] },
};

const testimonials = [
  {
    name: "ACP Rajesh Sharma",
    role: "Police safety response team",
    text: "VRIDDHAKSHA has transformed how we protect senior citizens. Our response time dropped from 45 minutes to under 8 minutes. The AI detection is remarkably accurate.",
    avatar: "RS",
    color: "bg-[#0B3D91]",
  },
  {
    name: "Meena Patel",
    role: "Senior Citizen, Age 68",
    text: "Mane phone aavyo ke mara account blocked thashe. Maine VRIDDHAKSHA button dabavyo — 5 minute maa police aa gaya! Hu haju bhi surakshit chhu.",
    avatar: "MP",
    color: "bg-[#2E8B57]",
  },
  {
    name: "Vikram Shah",
    role: "Family Caregiver",
    text: "The family dashboard gives me complete peace of mind about my 72-year-old mother. I get instant alerts and can see her health and location from anywhere in the world.",
    avatar: "VS",
    color: "bg-purple-600",
  },
  {
    name: "Dr. Priya Mehta",
    role: "Cyber Security Expert, IIT Ahmedabad",
    text: "The AI fraud detection accuracy is remarkable — 97.3% across all scam types. The architecture is technically sound and the UI is the most accessible govtech interface I've seen.",
    avatar: "PM",
    color: "bg-[#FFB703]",
  },
];

const awarenessCards = [
  { icon: <Smartphone className="w-6 h-6" />, title: "OTP Scam", color: "text-blue-600 bg-blue-50", desc: "Never share OTP with anyone. Banks never ask for OTP over phone.", detail: "Fraudsters call pretending to be bank officials, ask for OTP to 'verify your account'. Once you share, they drain your account. RBI rules: No bank will ever ask for your OTP, PIN, CVV or password.", severity: "High" },
  { icon: <CreditCard className="w-6 h-6" />, title: "UPI Fraud", color: "text-green-600 bg-green-50", desc: "Receiving money requests are payment requests — approve nothing suspicious.", detail: "Scammers send UPI 'collect' requests claiming to send you money. When you approve, money is deducted from your account. You should only scan and pay — never approve incoming requests from strangers.", severity: "High" },
  { icon: <TrendingUp className="w-6 h-6" />, title: "Investment Fraud", color: "text-purple-600 bg-purple-50", desc: "Promises of 30%+ monthly returns are always scams.", detail: "Fake investment apps, WhatsApp groups, and calls promise guaranteed high returns. They pay early investors (Ponzi scheme) then disappear with everyone's money. SEBI-registered advisors never guarantee returns.", severity: "Critical" },
  { icon: <FileText className="w-6 h-6" />, title: "KYC Scam", color: "text-amber-600 bg-amber-50", desc: "KYC is never done over phone or WhatsApp — only at bank branches.", detail: "Fraudsters send fake KYC update links or call posing as bank staff. Never click links for KYC. Real KYC is done physically at the branch with proper documentation.", severity: "High" },
  { icon: <QrCode className="w-6 h-6" />, title: "QR Code Scam", color: "text-red-600 bg-red-50", desc: "Scanning QR codes can only SEND money, never receive it.", detail: "If someone says 'scan this QR to receive money', it is always a scam. QR codes are used for payments only. Any scenario where scanning supposedly gives you money is fraudulent.", severity: "Medium" },
  { icon: <Smartphone className="w-6 h-6" />, title: "SIM Swap", color: "text-teal-600 bg-teal-50", desc: "If your phone loses signal suddenly, call your operator immediately.", detail: "Fraudsters impersonate you at telecom stores and get a new SIM issued. Your number stops working, and they receive your OTPs. If your phone loses signal without reason, call your operator from another phone immediately.", severity: "Critical" },
  { icon: <Mic className="w-6 h-6" />, title: "Voice Phishing", color: "text-orange-600 bg-orange-50", desc: "Never trust caller ID — it can be spoofed to show any number.", detail: "Vishing calls impersonate banks, RBI, police, or government. They use fear tactics (account frozen, legal action) to get you to share information or transfer money. Hang up and call the official number.", severity: "High" },
  { icon: <Video className="w-6 h-6" />, title: "AI Deepfake Scam", color: "text-pink-600 bg-pink-50", desc: "Video/voice of known people asking for money — always verify in person.", detail: "AI can clone anyone's face and voice. Scammers create fake video calls showing your relative in distress, asking for urgent money transfer. Always call the person back on their known number before sending money.", severity: "Critical" },
];

export default function Home() {
  const { t } = useI18n();
  const [activeScamTab, setActiveScamTab] = useState("message");
  const [analyzing, setAnalyzing] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [selectedAwareness, setSelectedAwareness] = useState<typeof awarenessCards[0] | null>(null);
  const [shieldHovered, setShieldHovered] = useState(false);
  const [safetyScanning, setSafetyScanning] = useState(false);
  const [safetyComplete, setSafetyComplete] = useState(false);
  const [threatPhase, setThreatPhase] = useState(0);

  useEffect(() => {
    const phaseTimer = setInterval(() => setThreatPhase((phase) => (phase + 1) % 4), 9000);
    return () => clearInterval(phaseTimer);
  }, []);

  const runSafetyCheck = () => {
    setSafetyComplete(false);
    setSafetyScanning(true);
    setTimeout(() => {
      setSafetyScanning(false);
      setSafetyComplete(true);
    }, 2600);
  };

  const handleAnalyze = () => {
    setShowResult(false);
    setAnalyzing(true);
    setTimeout(() => {
      setAnalyzing(false);
      setShowResult(true);
    }, 1800);
  };

  const result = scamResults[activeScamTab];

  return (
    <div className="bg-background">
      {/* HERO */}
      <section className="relative min-h-[92vh] flex items-center overflow-hidden bg-gradient-to-br from-slate-50 via-background to-blue-50/70 dark:from-slate-950 dark:via-background dark:to-blue-950/30">
        <div className="absolute inset-0 pointer-events-none opacity-50 dark:opacity-20" style={{ backgroundImage: "linear-gradient(rgba(11,61,145,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(11,61,145,0.08) 1px, transparent 1px)", backgroundSize: "42px 42px" }} />
        <svg className="absolute inset-0 h-full w-full pointer-events-none opacity-25 dark:opacity-15" viewBox="0 0 1200 700" preserveAspectRatio="none" aria-hidden="true">
          <path d="M0 170 C180 100 260 280 440 190 S760 100 920 210 S1080 310 1200 160 M20 560 C180 470 300 600 470 500 S760 430 900 540 S1080 600 1200 470" fill="none" stroke="#0B3D91" strokeWidth="1" strokeDasharray="3 12" />
          <path d="M120 0 C210 150 180 300 320 410 S650 570 740 700 M1040 0 C930 170 1010 290 860 390 S650 520 560 700" fill="none" stroke="#2E8B57" strokeWidth="1" strokeDasharray="2 16" />
          <circle cx="440" cy="190" r="3" fill="#FFB703" /><circle cx="920" cy="210" r="3" fill="#2E8B57" /><circle cx="470" cy="500" r="3" fill="#0B3D91" /><circle cx="860" cy="390" r="3" fill="#FFB703" />
        </svg>
        <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-blue-100/50 to-transparent dark:from-blue-900/20" />
        <div className="absolute -right-24 top-24 h-72 w-72 rounded-full border-[32px] border-[#FFB703]/10" />
        <div className="absolute -left-32 bottom-0 h-80 w-80 rounded-full border-[40px] border-[#2E8B57]/10" />
        <div className="container mx-auto px-4 pt-24 pb-20 relative z-10">
          <div className="grid md:grid-cols-[1.05fr_0.95fr] gap-12 lg:gap-20 items-center">
          <motion.div initial={{ opacity: 0, x: -40 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7 }}>
            <Badge className="mb-6 bg-white/80 dark:bg-card/80 text-[#0B3D91] dark:text-blue-300 border-blue-200 dark:border-blue-700 px-4 py-1.5 text-sm font-semibold rounded-full shadow-sm">
              <span className="mr-2 inline-block h-2 w-2 rounded-full bg-[#2E8B57] animate-pulse" />{t("hero_badge")}
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-heading font-bold leading-[1.05] tracking-tight text-foreground mb-6">
              {t("hero_h1_1")}<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#0B3D91] via-blue-500 to-[#2E8B57]">{t("hero_h1_2")}</span>
              <br />{t("hero_h1_3")}
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 leading-relaxed max-w-xl">
              {t("hero_sub")}
            </p>
            <div className="flex flex-wrap gap-4">
              <Button asChild size="lg" className="bg-[#0B3D91] hover:bg-[#0a3480] text-white px-8 py-6 rounded-full font-semibold text-lg shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5" data-testid="button-get-protected">
                <Link href="/emergency"><ShieldCheck className="w-5 h-5 mr-2" />{t("hero_btn1")}</Link>
              </Button>
              <Button asChild size="lg" className="bg-[#FFB703] hover:bg-[#e5a400] text-gray-900 px-8 py-6 rounded-full font-semibold text-lg shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5" data-testid="button-report-scam">
                <Link href="/report-scam"><AlertTriangle className="w-5 h-5 mr-2" />{t("hero_btn2")}</Link>
              </Button>
              <Button variant="outline" size="lg" className="px-8 py-6 rounded-full font-semibold text-lg border-2 bg-background/60 hover:-translate-y-0.5 transition-all" data-testid="button-watch-demo"
                onClick={() => document.getElementById("ai-demo")?.scrollIntoView({ behavior: "smooth" })}>
                <Play className="w-5 h-5 mr-2" />{t("hero_btn3")}
              </Button>
            </div>
            <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-[#2E8B57]" />24/7 protection</span>
              <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-[#2E8B57]" />Police-connected response</span>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8, delay: 0.2 }} className="relative flex min-h-[480px] items-center justify-center">
            <div
              className="relative h-[390px] w-[390px] max-w-full cursor-pointer"
              onMouseEnter={() => setShieldHovered(true)}
              onMouseLeave={() => setShieldHovered(false)}
            >
              <div className="absolute inset-6 rounded-full border border-[#0B3D91]/20 shadow-[0_0_0_18px_rgba(11,61,145,0.04),0_0_0_42px_rgba(11,61,145,0.03)]" />
              <motion.div className="absolute inset-12 rounded-full border border-[#2E8B57]/35" animate={{ scale: [1, 1.08, 1], opacity: [0.45, 0.9, 0.45] }} transition={{ repeat: Infinity, duration: 3.4, ease: "easeInOut" }} />
              <motion.div className="absolute inset-3 rounded-full border border-dashed border-[#0B3D91]/25" animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 24, ease: "linear" }} />
              <motion.div className="absolute left-1/2 top-8 h-16 w-px origin-bottom bg-gradient-to-b from-transparent via-[#FFB703] to-transparent opacity-80" animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 5, ease: "linear" }} />
              <div className="absolute inset-[22%] overflow-hidden rounded-[42%] bg-gradient-to-br from-[#0B3D91] via-[#145bb0] to-[#2E8B57] shadow-[0_20px_60px_rgba(11,61,145,0.35)] transition-transform duration-500 hover:scale-105">
                <div className="absolute inset-0 bg-[linear-gradient(115deg,transparent_35%,rgba(255,255,255,0.28)_50%,transparent_65%)] animate-[scan_3.8s_linear_infinite]" />
                <div className="relative flex h-full flex-col items-center justify-center text-center text-white">
                  <Shield className="mb-2 h-20 w-20 stroke-[1.2]" />
                  <span className="font-heading text-2xl font-bold tracking-tight">VRIDDHAKSHA</span>
                  <span className="mt-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-blue-100">{shieldHovered ? "VRIDDHAKSHA ACTIVE — ALL SYSTEMS SECURE" : "AI protection active"}</span>
                </div>
              </div>
              {[
                { icon: <Shield className="h-4 w-4" />, label: "Cyber Protection", position: "left-0 top-24" },
                { icon: <Siren className="h-4 w-4" />, label: "Emergency Detection", position: "right-0 top-28" },
                { icon: <MapPin className="h-4 w-4" />, label: "Location Tracking", position: "left-4 bottom-16" },
                { icon: <Heart className="h-4 w-4" />, label: "Family Safety", position: "right-4 bottom-12" },
              ].map((node) => (
                <motion.div key={node.label} className={`absolute ${node.position} flex items-center gap-2 rounded-full border border-white/70 bg-white/80 px-3 py-2 text-[10px] font-semibold text-[#0B3D91] shadow-lg backdrop-blur-md dark:border-white/10 dark:bg-slate-900/75 dark:text-blue-200`} animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}>
                  <span className="text-[#2E8B57]">{node.icon}</span>{node.label}
                </motion.div>
              ))}
            </div>
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 rounded-full border border-[#0B3D91]/10 bg-white/60 px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground backdrop-blur-md dark:bg-slate-900/60">
              {['Scam detected', 'AI analyzing', 'Threat blocked', 'Police alerted'][threatPhase]}
            </div>
          </motion.div>
        </div>
        </div>

        <motion.div className="absolute bottom-8 left-1/2 -translate-x-1/2" animate={{ y: [0, 8, 0] }} transition={{ repeat: Infinity, duration: 1.5 }}>
          <ChevronDown className="w-8 h-8 text-muted-foreground" />
        </motion.div>

        <style>{`@keyframes scan { 0%{transform:translateX(-120%)} 55%,100%{transform:translateX(120%)} }`}</style>
      </section>

      <section className="relative overflow-hidden border-b border-blue-100 bg-white py-12 dark:border-blue-900/30 dark:bg-slate-950">
        <div className="container mx-auto flex flex-col items-center px-4 text-center">
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-[#0B3D91] dark:text-blue-300">Is your digital life protected?</p>
          <Button onClick={runSafetyCheck} disabled={safetyScanning} size="lg" className="rounded-full bg-[#0B3D91] px-8 py-6 text-base font-bold text-white shadow-lg hover:bg-[#0a3480]">
            {safetyScanning ? <><ScanLine className="animate-pulse" />SCANNING...</> : <>RUN SAFETY CHECK <ArrowRight /></>}
          </Button>
          <AnimatePresence mode="wait">
            {(safetyScanning || safetyComplete) && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="mt-6 grid max-w-2xl grid-cols-2 gap-x-8 gap-y-2 text-left text-sm text-muted-foreground md:grid-cols-5">
                {["Scam Protection", "Emergency Contacts", "Location Safety", "Family Connection", "Device Security"].map((item) => <span key={item} className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-[#2E8B57]" />{item}</span>)}
                {safetyComplete && <strong className="col-span-2 mt-3 text-center text-[#2E8B57] md:col-span-5">VRIDDHAKSHA STATUS: 100% ACTIVE — YOU'RE PROTECTED.</strong>}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* STATS */}
      <section className="py-20 bg-gradient-to-b from-[#0B3D91] to-[#0a3480]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: 95, suffix: "%", label: "Scams Prevented", icon: <ShieldCheck className="w-8 h-8" /> },
              { value: 24, suffix: "×7", label: "Monitoring", icon: <Activity className="w-8 h-8" /> },
              { value: 1, suffix: "-Tap", label: "Emergency SOS", icon: <Siren className="w-8 h-8" /> },
              { value: 97, suffix: "%", label: "AI Accuracy", icon: <Cpu className="w-8 h-8" /> },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="text-center text-white"
              >
                <div className="flex justify-center mb-3 opacity-80">{stat.icon}</div>
                <div className="text-5xl md:text-6xl font-heading font-bold mb-2">
                  <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-blue-200 text-sm font-medium uppercase tracking-widest">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <Badge className="mb-4 bg-blue-50 dark:bg-blue-950/50 text-[#0B3D91] dark:text-blue-300 border-blue-200">{t("features_badge")}</Badge>
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-4">{t("features_h2")}</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t("features_sub")}</p>
          </motion.div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                viewport={{ once: true }}
                whileHover={{ y: -4 }}
                className={`rounded-2xl border ${f.border} bg-white dark:bg-card p-6 shadow-sm hover:shadow-lg transition-all cursor-default group`}
              >
                <div className={`w-14 h-14 rounded-xl ${f.bg} flex items-center justify-center ${f.color} mb-5 group-hover:scale-110 transition-transform`}>
                  {f.icon}
                </div>
                <h3 className="text-xl font-heading font-bold text-foreground mb-4">{f.title}</h3>
                <ul className="space-y-2">
                  {f.items.map((item, j) => (
                    <li key={j} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle className="w-4 h-4 text-[#2E8B57] flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
                {f.link && (
                  <Button asChild variant="ghost" size="sm" className={`mt-4 ${f.color} font-semibold p-0 hover:bg-transparent`}>
                    <Link href={f.link}>{t("learn_more")} <ArrowRight className="w-4 h-4 ml-1" /></Link>
                  </Button>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="py-24 bg-muted/40">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <Badge className="mb-4 bg-blue-50 dark:bg-blue-950/50 text-[#0B3D91] dark:text-blue-300 border-blue-200">{t("hiw_badge")}</Badge>
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-4">{t("hiw_h2")}</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t("hiw_sub")}</p>
          </motion.div>
          <div className="max-w-4xl mx-auto">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: i % 2 === 0 ? -40 : 40 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="flex items-start gap-6 mb-8 relative"
              >
                <div className="flex flex-col items-center">
                  <div className={`w-14 h-14 rounded-full ${step.color} flex items-center justify-center text-white shadow-lg flex-shrink-0 z-10`}>
                    {step.icon}
                  </div>
                  {i < steps.length - 1 && (
                    <div className="w-0.5 h-12 bg-gradient-to-b from-gray-300 to-transparent mt-2" />
                  )}
                </div>
                <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 flex-1 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Step {i + 1}</span>
                  </div>
                  <h3 className="text-lg font-heading font-bold text-foreground mb-1">{step.title}</h3>
                  <p className="text-muted-foreground text-sm">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* AI SCAM DETECTION DEMO */}
      <section className="py-24 bg-background" id="ai-demo">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <Badge className="mb-4 bg-purple-50 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 border-purple-200">{t("ai_badge")}</Badge>
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-4">{t("ai_h2")}</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t("ai_sub")}</p>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            <motion.div initial={{ opacity: 0, scale: 0.97 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} className="bg-white dark:bg-card rounded-3xl border border-border shadow-xl overflow-hidden">
              <div className="bg-gradient-to-r from-[#0B3D91] to-blue-600 p-6 text-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-heading font-bold">{t("ai_engine")}</div>
                    <div className="text-xs text-blue-200">{t("ai_poweredby")}</div>
                  </div>
                  <div className="ml-auto flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-xs">{t("ai_live")}</span>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <Tabs value={activeScamTab} onValueChange={(v) => { setActiveScamTab(v); setShowResult(false); }}>
                  <TabsList className="grid grid-cols-4 mb-6">
                    <TabsTrigger value="message" data-testid="tab-message">Message</TabsTrigger>
                    <TabsTrigger value="call" data-testid="tab-call">Call</TabsTrigger>
                    <TabsTrigger value="whatsapp" data-testid="tab-whatsapp">WhatsApp</TabsTrigger>
                    <TabsTrigger value="email" data-testid="tab-email">Email</TabsTrigger>
                  </TabsList>

                  {Object.entries(scamMessages).map(([key, msg]) => (
                    <TabsContent key={key} value={key}>
                      <div className="bg-muted/50 rounded-xl p-4 text-sm text-foreground font-mono leading-relaxed border border-border min-h-[80px]">
                        {msg}
                      </div>
                    </TabsContent>
                  ))}
                </Tabs>

                <Button onClick={handleAnalyze} disabled={analyzing} className="w-full mt-4 bg-[#0B3D91] hover:bg-[#0a3480] text-white font-semibold py-3 rounded-xl text-base" data-testid="button-analyze">
                  {analyzing ? (
                    <span className="flex items-center gap-2"><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> {t("ai_analyzing")}</span>
                  ) : (
                    <span className="flex items-center gap-2"><Cpu className="w-5 h-5" /> {t("ai_analyze")}</span>
                  )}
                </Button>

                <AnimatePresence>
                  {showResult && (
                    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-6">
                      <div className={`rounded-2xl border-2 p-6 ${result.label === "SCAM" ? "border-red-200 bg-red-50 dark:bg-red-950/20" : result.label === "SUSPICIOUS" ? "border-amber-200 bg-amber-50 dark:bg-amber-950/20" : "border-green-200 bg-green-50 dark:bg-green-950/20"}`}>
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            {result.label === "SCAM" && <AlertCircle className="w-8 h-8 text-red-500" />}
                            {result.label === "SUSPICIOUS" && <AlertTriangle className="w-8 h-8 text-amber-500" />}
                            {result.label === "SAFE" && <CheckCircle className="w-8 h-8 text-green-500" />}
                            <span className={`text-2xl font-heading font-bold ${result.label === "SCAM" ? "text-red-600" : result.label === "SUSPICIOUS" ? "text-amber-600" : "text-green-600"}`}>
                              {result.label}
                            </span>
                          </div>
                          <span className="text-3xl font-bold text-foreground">{result.confidence}%</span>
                        </div>
                        <div className="bg-gray-200 dark:bg-gray-700 rounded-full h-3 mb-4 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${result.confidence}%` }}
                            transition={{ duration: 0.8 }}
                            className={`h-full rounded-full ${result.label === "SCAM" ? "bg-red-500" : result.label === "SUSPICIOUS" ? "bg-amber-500" : "bg-green-500"}`}
                          />
                        </div>
                        <div className="text-sm font-semibold text-foreground mb-2">{t("ai_threat_indicators")}</div>
                        {result.reasons.map((r, i) => (
                          <div key={i} className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                            <AlertTriangle className="w-3 h-3 text-red-400 flex-shrink-0" />
                            {r}
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* EMERGENCY DASHBOARD PREVIEW */}
      <section className="py-24 bg-gradient-to-b from-red-50 to-background dark:from-red-950/20 dark:to-background">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <Badge className="mb-4 bg-red-50 dark:bg-red-950/50 text-red-700 dark:text-red-300 border-red-200">{t("em_badge")}</Badge>
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-4">{t("em_h2")}</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t("em_sub")}</p>
          </motion.div>

          <div className="max-w-5xl mx-auto grid md:grid-cols-3 gap-6">
            <motion.div initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} className="md:col-span-1 flex flex-col gap-6">
              <div className="bg-white dark:bg-card rounded-2xl border border-border p-6 shadow-sm text-center">
                <div className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-4">Emergency SOS</div>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  animate={{ boxShadow: ["0 0 0 0 rgba(239,68,68,0.4)", "0 0 0 20px rgba(239,68,68,0)", "0 0 0 0 rgba(239,68,68,0)"] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                  className="w-36 h-36 mx-auto rounded-full bg-gradient-to-br from-red-500 to-red-700 text-white font-heading font-bold text-2xl shadow-2xl flex flex-col items-center justify-center cursor-pointer border-4 border-white"
                  data-testid="button-sos"
                >
                  <Siren className="w-10 h-10 mb-1" />
                  SOS
                </motion.button>
                <p className="text-xs text-muted-foreground mt-4">Hold for 3 seconds to activate</p>
              </div>

              <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
                <div className="text-sm font-semibold text-foreground mb-3">Health Status</div>
                {[
                  { label: "Heart Rate", value: "78 BPM", icon: <Heart className="w-4 h-4 text-red-500" />, status: "normal" },
                  { label: "Blood Pressure", value: "120/80", icon: <Activity className="w-4 h-4 text-blue-500" />, status: "normal" },
                  { label: "SpO2", value: "98%", icon: <Zap className="w-4 h-4 text-green-500" />, status: "normal" },
                ].map((h, i) => (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <div className="flex items-center gap-2">{h.icon}<span className="text-sm text-muted-foreground">{h.label}</span></div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-foreground">{h.value}</span>
                      <span className="w-2 h-2 bg-green-400 rounded-full" />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: 0.1 }} className="md:col-span-2 flex flex-col gap-6">
              <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <div className="text-sm font-semibold text-foreground">GPS Location</div>
                  <Badge className="bg-green-50 text-green-700 border-green-200 text-xs">Active</Badge>
                </div>
                <div className="bg-blue-50 dark:bg-blue-950/30 rounded-xl h-32 flex items-center justify-center relative overflow-hidden border border-blue-100 dark:border-blue-900/50">
                  <div className="absolute inset-0 opacity-20">
                    {Array.from({ length: 6 }).map((_, i) => (
                      <div key={i} className="absolute border border-blue-400" style={{ left: `${i * 20}%`, top: 0, bottom: 0, width: 0 }} />
                    ))}
                    {Array.from({ length: 4 }).map((_, i) => (
                      <div key={i} className="absolute border border-blue-400" style={{ top: `${i * 33}%`, left: 0, right: 0, height: 0 }} />
                    ))}
                  </div>
                  <div className="text-center z-10">
                    <MapPin className="w-8 h-8 text-[#0B3D91] mx-auto" />
                    <div className="text-sm font-semibold text-[#0B3D91] mt-1">Satellite Society</div>
                    <div className="text-xs text-muted-foreground">23.0225° N, 72.5714° E</div>
                  </div>
                </div>
                <div className="flex gap-3 mt-3">
                  <div className="flex-1 bg-blue-50 dark:bg-blue-950/30 rounded-lg p-3 text-center">
                    <div className="text-xs text-muted-foreground">Police Station</div>
                    <div className="text-sm font-bold text-[#0B3D91]">1.2 km</div>
                  </div>
                  <div className="flex-1 bg-red-50 dark:bg-red-950/30 rounded-lg p-3 text-center">
                    <div className="text-xs text-muted-foreground">Ambulance</div>
                    <div className="text-sm font-bold text-red-600">2.3 km</div>
                  </div>
                  <div className="flex-1 bg-green-50 dark:bg-green-950/30 rounded-lg p-3 text-center">
                    <div className="text-xs text-muted-foreground">Hospital</div>
                    <div className="text-sm font-bold text-green-600">3.1 km</div>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
                <div className="text-sm font-semibold text-foreground mb-3">Emergency Contacts</div>
                {[
                  { name: "Ravi Shah (Son)", phone: "+91 98765 43210", relation: "Son" },
                  { name: "Dr. Anjali Patel", phone: "+91 99999 12345", relation: "Doctor" },
                  { name: "Cyber Safety Helpline", phone: "1930", relation: "Police" },
                ].map((c, i) => (
                  <div key={i} className="flex items-center justify-between py-2.5 border-b border-border last:border-0">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-[#0B3D91] text-xs font-bold">{c.name[0]}</div>
                      <div>
                        <div className="text-sm font-medium text-foreground">{c.name}</div>
                        <div className="text-xs text-muted-foreground">{c.phone}</div>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" className="rounded-full h-8 text-xs border-[#2E8B57] text-[#2E8B57] hover:bg-green-50">
                      <PhoneCall className="w-3 h-3 mr-1" />Call
                    </Button>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          <div className="text-center mt-10">
            <Button asChild size="lg" className="bg-red-600 hover:bg-red-700 text-white rounded-full px-10 py-6 font-semibold text-lg shadow-lg">
              <Link href="/emergency">{t("em_open")} <ArrowRight className="ml-2 w-5 h-5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* AWARENESS CENTER */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <Badge className="mb-4 bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border-amber-200">{t("aw_badge")}</Badge>
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-4">{t("aw_h2")}</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t("aw_sub")}</p>
          </motion.div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-5 max-w-5xl mx-auto">
            {awarenessCards.map((card, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                viewport={{ once: true }}
                whileHover={{ y: -4 }}
                onClick={() => setSelectedAwareness(card)}
                className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm hover:shadow-lg transition-all cursor-pointer group"
                data-testid={`card-awareness-${i}`}
              >
                <div className={`w-12 h-12 rounded-xl ${card.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  {card.icon}
                </div>
                <h3 className="font-heading font-bold text-foreground text-sm mb-2">{card.title}</h3>
                <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{card.desc}</p>
                <Badge className={`text-xs ${card.severity === "Critical" ? "bg-red-50 text-red-600 border-red-200" : "bg-amber-50 text-amber-600 border-amber-200"}`}>{card.severity}</Badge>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-24 bg-gradient-to-b from-muted/40 to-background">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <Badge className="mb-4 bg-green-50 dark:bg-green-950/50 text-[#2E8B57] dark:text-green-300 border-green-200">{t("test_badge")}</Badge>
            <h2 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-4">{t("test_h2")}</h2>
          </motion.div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {testimonials.map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="bg-white dark:bg-card rounded-2xl border border-border p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-12 h-12 rounded-full ${t.color} flex items-center justify-center text-white font-bold text-lg flex-shrink-0`}>{t.avatar}</div>
                  <div>
                    <div className="font-heading font-bold text-foreground text-sm">{t.name}</div>
                    <div className="text-xs text-muted-foreground">{t.role}</div>
                  </div>
                </div>
                <div className="flex gap-0.5 mb-3">{Array.from({ length: 5 }).map((_, j) => <Star key={j} className="w-3 h-3 fill-amber-400 text-amber-400" />)}</div>
                <p className="text-sm text-muted-foreground leading-relaxed">&ldquo;{t.text}&rdquo;</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA STRIP */}
      <section className="py-20 bg-gradient-to-r from-[#0B3D91] to-blue-600">
        <div className="container mx-auto px-4 text-center text-white">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-4xl md:text-5xl font-heading font-bold mb-4">{t("cta_h2")}</h2>
            <p className="text-xl text-blue-200 mb-10 max-w-2xl mx-auto">{t("cta_sub")}</p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-[#0B3D91] hover:bg-blue-50 px-10 py-6 rounded-full font-bold text-lg shadow-xl">
                <Link href="/emergency">{t("cta_btn1")} <ShieldCheck className="ml-2 w-5 h-5" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10 px-10 py-6 rounded-full font-semibold text-lg">
                <Link href="/contact">{t("cta_btn2")}</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Awareness Modal */}
      <Dialog open={!!selectedAwareness} onOpenChange={() => setSelectedAwareness(null)}>
        <DialogContent className="max-w-md rounded-2xl">
          {selectedAwareness && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className={`w-12 h-12 rounded-xl ${selectedAwareness.color} flex items-center justify-center`}>{selectedAwareness.icon}</div>
                  <DialogTitle className="text-xl font-heading">{selectedAwareness.title}</DialogTitle>
                </div>
              </DialogHeader>
              <Badge className={`w-fit ${selectedAwareness.severity === "Critical" ? "bg-red-50 text-red-600 border-red-200" : "bg-amber-50 text-amber-600 border-amber-200"}`}>{selectedAwareness.severity} Risk</Badge>
              <p className="text-muted-foreground leading-relaxed mt-3">{selectedAwareness.detail}</p>
              <div className="bg-blue-50 dark:bg-blue-950/30 rounded-xl p-4 mt-2 border border-blue-100 dark:border-blue-900/50">
                <div className="text-sm font-semibold text-[#0B3D91] mb-1">What to do if you receive this?</div>
                <div className="text-sm text-muted-foreground">Do NOT share any information. Hang up / delete immediately. Report to Cyber Crime Helpline: <strong>1930</strong></div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
