import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bot, Shield, Cpu, Mic, MicOff, Eye, Zap, Brain, ScanLine,
  ShieldCheck, AlertTriangle, CheckCircle, AlertCircle, Play,
  Lock, Radio, Activity, TrendingUp, Waves, BarChart3
} from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

const detectionData = [
  { time: "00:00", accuracy: 94 }, { time: "04:00", accuracy: 96 }, { time: "08:00", accuracy: 97 },
  { time: "12:00", accuracy: 97.3 }, { time: "16:00", accuracy: 98 }, { time: "20:00", accuracy: 97.5 },
  { time: "24:00", accuracy: 97.8 },
];

const aiModels = [
  { name: "Scam Text Classifier", accuracy: 97.3, type: "NLP", status: "active", scansToday: "14,281" },
  { name: "Voice Phishing Detector", accuracy: 94.1, type: "Audio ML", status: "active", scansToday: "3,847" },
  { name: "Deepfake Video Analysis", accuracy: 91.8, type: "Computer Vision", status: "active", scansToday: "512" },
  { name: "Transaction Anomaly", accuracy: 98.7, type: "Time Series", status: "active", scansToday: "82,341" },
  { name: "Behavioural Biometrics", accuracy: 95.2, type: "Pattern ML", status: "beta", scansToday: "9,104" },
  { name: "Network Threat Intelligence", accuracy: 99.1, type: "Graph ML", status: "active", scansToday: "210,500" },
];

const liveThreats = [
  { id: "TH-8821", type: "OTP Phishing Call", risk: "Critical", target: "+91 98765 ****", confidence: 99, ts: "14:32:01" },
  { id: "TH-8820", type: "Investment Fraud SMS", risk: "High", target: "+91 87654 ****", confidence: 95, ts: "14:31:44" },
  { id: "TH-8819", type: "Fake KYC Link", risk: "High", target: "+91 76543 ****", confidence: 92, ts: "14:31:12" },
  { id: "TH-8818", type: "UPI Collect Request", risk: "Medium", target: "+91 65432 ****", confidence: 87, ts: "14:30:58" },
  { id: "TH-8817", type: "Deepfake Video Call", risk: "Critical", target: "+91 54321 ****", confidence: 96, ts: "14:30:22" },
];

const riskColor: Record<string, string> = {
  Critical: "text-red-600 bg-red-50 border-red-200",
  High: "text-orange-600 bg-orange-50 border-orange-200",
  Medium: "text-amber-600 bg-amber-50 border-amber-200",
  Low: "text-green-600 bg-green-50 border-green-200",
};

function VoiceDemo() {
  const [state, setState] = useState<"idle" | "listening" | "analyzing" | "result">("idle");
  const [transcript, setTranscript] = useState("");
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const start = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      setTranscript("Caller said: Hello, I am calling from RBI. Your account has been flagged for suspicious transactions. Share your OTP to verify your account now.");
      setState("analyzing");
      setTimeout(() => setState("result"), 2000);
      return;
    }
    const r = new SR();
    r.lang = "en-IN";
    r.continuous = true;
    r.onresult = (e: SpeechRecognitionEvent) => {
      const t = Array.from(e.results).map(r => r[0].transcript).join(" ");
      setTranscript(t);
    };
    r.onend = () => {
      setState("analyzing");
      setTimeout(() => setState("result"), 2000);
    };
    r.start();
    recognitionRef.current = r;
    setState("listening");
    setTimeout(() => { r.stop(); }, 8000);
  };

  const reset = () => { setState("idle"); setTranscript(""); };

  return (
    <div className="bg-white dark:bg-card rounded-2xl border border-border p-6 shadow-sm">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center text-red-600">
          <Mic className="w-6 h-6" />
        </div>
        <div>
          <h3 className="font-heading font-bold text-foreground">Live Voice Analysis</h3>
          <p className="text-sm text-muted-foreground">Speak a call transcript — AI detects vishing in real time</p>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {state === "idle" && (
          <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-6">
            <motion.button
              onClick={start}
              className="w-24 h-24 rounded-full bg-gradient-to-br from-red-500 to-red-700 text-white flex items-center justify-center mx-auto shadow-xl mb-4"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              animate={{ boxShadow: ["0 0 0 0 rgba(239,68,68,0.4)", "0 0 0 16px rgba(239,68,68,0)", "0 0 0 0 rgba(239,68,68,0)"] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <Mic className="w-10 h-10" />
            </motion.button>
            <p className="text-sm text-muted-foreground">Click to start voice analysis</p>
            <p className="text-xs text-muted-foreground mt-1">Or describe a suspicious call you received</p>
          </motion.div>
        )}
        {state === "listening" && (
          <motion.div key="listening" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-6">
            <motion.div className="w-24 h-24 rounded-full bg-red-600 text-white flex items-center justify-center mx-auto shadow-xl mb-4 relative"
              animate={{ scale: [1, 1.05, 1] }} transition={{ repeat: Infinity, duration: 0.8 }}>
              <Waves className="w-10 h-10" />
              <motion.div className="absolute inset-0 rounded-full border-4 border-red-400" animate={{ scale: [1, 1.4], opacity: [0.8, 0] }} transition={{ repeat: Infinity, duration: 1.2 }} />
            </motion.div>
            <p className="text-red-600 font-semibold text-sm">Recording... speak the call transcript</p>
            <p className="text-xs text-muted-foreground mt-1">Auto-stops in 8 seconds</p>
            {transcript && <div className="mt-4 p-3 bg-muted/50 rounded-xl text-sm text-foreground italic text-left">{transcript}</div>}
          </motion.div>
        )}
        {state === "analyzing" && (
          <motion.div key="analyzing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-6">
            <motion.div className="w-24 h-24 rounded-full bg-purple-600 text-white flex items-center justify-center mx-auto shadow-xl mb-4"
              animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
              <Cpu className="w-10 h-10" />
            </motion.div>
            <p className="text-purple-600 font-semibold text-sm">AI analyzing for vishing patterns...</p>
          </motion.div>
        )}
        {state === "result" && (
          <motion.div key="result" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="py-2">
            <div className="bg-red-50 dark:bg-red-950/20 border-2 border-red-200 rounded-2xl p-5 mb-4">
              <div className="flex items-center gap-3 mb-3">
                <AlertCircle className="w-8 h-8 text-red-500" />
                <span className="text-2xl font-heading font-bold text-red-600">VISHING DETECTED</span>
                <span className="ml-auto text-2xl font-bold text-foreground">97%</span>
              </div>
              <div className="space-y-1.5">
                {["Impersonation of RBI authority", "OTP solicitation (banks never ask for OTP)", "Urgency pressure tactic", "Voice phishing (Vishing) pattern"].map((r, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <AlertTriangle className="w-3 h-3 text-red-400 flex-shrink-0" />
                    {r}
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-blue-50 dark:bg-blue-950/20 rounded-xl p-4 border border-blue-100 dark:border-blue-900/50 text-sm text-muted-foreground mb-4">
              🛡️ <strong className="text-[#0B3D91]">Action:</strong> Hang up immediately. Call your bank on the official number on your card. Report to 1930.
            </div>
            <Button onClick={reset} variant="outline" className="w-full rounded-xl">Try Another</Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function AiProtection() {
  const [liveActive, setLiveActive] = useState(true);
  const [counter, setCounter] = useState(0);

  useEffect(() => {
    if (!liveActive) return;
    const t = setInterval(() => setCounter(c => c + Math.floor(Math.random() * 3) + 1), 2000);
    return () => clearInterval(t);
  }, [liveActive]);

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-gradient-to-r from-[#0B3D91] to-purple-700 text-white py-12">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                <Brain className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-3xl font-heading font-bold">AI Protection Suite</h1>
                <p className="text-blue-200 text-sm">Real-time AI-powered cyber threat detection & prevention</p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
              {[
                { label: "Scans Today", value: counter > 0 ? `${(310500 + counter).toLocaleString()}` : "310,500", icon: <ScanLine className="w-5 h-5" /> },
                { label: "Threats Blocked", value: "1,247", icon: <ShieldCheck className="w-5 h-5" /> },
                { label: "AI Accuracy", value: "97.3%", icon: <Cpu className="w-5 h-5" /> },
                { label: "Response Time", value: "< 0.3s", icon: <Zap className="w-5 h-5" /> },
              ].map((s, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                  className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm border border-white/20">
                  <div className="flex items-center gap-2 mb-2 opacity-80">{s.icon}<span className="text-xs uppercase tracking-wider">{s.label}</span></div>
                  <div className="text-2xl font-heading font-bold">{s.value}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10">
        <Tabs defaultValue="live">
          <TabsList className="mb-8">
            <TabsTrigger value="live"><Radio className="w-4 h-4 mr-2" />Live Detection</TabsTrigger>
            <TabsTrigger value="voice"><Mic className="w-4 h-4 mr-2" />Voice Analysis</TabsTrigger>
            <TabsTrigger value="models"><Brain className="w-4 h-4 mr-2" />AI Models</TabsTrigger>
            <TabsTrigger value="accuracy"><BarChart3 className="w-4 h-4 mr-2" />Performance</TabsTrigger>
          </TabsList>

          {/* Live Detection Tab */}
          <TabsContent value="live">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <div className="font-heading font-bold text-foreground flex items-center gap-2">
                    <Radio className="w-4 h-4 text-red-500" />Live Threat Feed
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-xs text-muted-foreground">Live</span>
                    <Button size="sm" variant="outline" className="h-7 text-xs rounded-full" onClick={() => setLiveActive(a => !a)}>
                      {liveActive ? "Pause" : "Resume"}
                    </Button>
                  </div>
                </div>
                <div className="space-y-3">
                  {liveThreats.map((t, i) => (
                    <motion.div key={t.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                      className="flex items-start gap-3 p-3 bg-muted/40 rounded-xl">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${t.risk === "Critical" ? "bg-red-100 text-red-600" : t.risk === "High" ? "bg-orange-100 text-orange-600" : "bg-amber-100 text-amber-600"}`}>
                        <AlertTriangle className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-foreground truncate">{t.type}</span>
                          <Badge className={`text-xs flex-shrink-0 ${riskColor[t.risk]}`}>{t.risk}</Badge>
                        </div>
                        <div className="text-xs text-muted-foreground">{t.target} · {t.confidence}% confidence</div>
                      </div>
                      <div className="text-xs text-muted-foreground flex-shrink-0">{t.ts}</div>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
                  <div className="font-heading font-bold text-foreground mb-4">AI Shield Status</div>
                  {[
                    { label: "Text/SMS Scanner", pct: 100, color: "bg-green-500" },
                    { label: "Call Analyzer", pct: 100, color: "bg-green-500" },
                    { label: "Transaction Monitor", pct: 100, color: "bg-green-500" },
                    { label: "Deepfake Detector", pct: 92, color: "bg-amber-500" },
                    { label: "Network Intelligence", pct: 100, color: "bg-green-500" },
                  ].map((s, i) => (
                    <div key={i} className="mb-3">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-foreground">{s.label}</span>
                        <span className="text-muted-foreground">{s.pct}%</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <motion.div className={`h-full rounded-full ${s.color}`}
                          initial={{ width: 0 }} animate={{ width: `${s.pct}%` }} transition={{ delay: i * 0.1, duration: 0.8 }} />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-green-50 dark:bg-green-950/20 rounded-2xl p-4 border border-green-200 dark:border-green-900/50 text-center">
                    <ShieldCheck className="w-8 h-8 text-[#2E8B57] mx-auto mb-2" />
                    <div className="text-2xl font-bold text-[#2E8B57]">ACTIVE</div>
                    <div className="text-xs text-muted-foreground">All Systems</div>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-950/20 rounded-2xl p-4 border border-blue-200 dark:border-blue-900/50 text-center">
                    <Activity className="w-8 h-8 text-[#0B3D91] mx-auto mb-2" />
                    <div className="text-2xl font-bold text-[#0B3D91]">{(310500 + counter).toLocaleString()}</div>
                    <div className="text-xs text-muted-foreground">Scans Today</div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Voice Analysis Tab */}
          <TabsContent value="voice">
            <div className="max-w-2xl mx-auto">
              <VoiceDemo />
              <div className="mt-6 grid grid-cols-3 gap-4">
                {[
                  { label: "Vishing Calls Detected Today", value: "47", icon: <Mic className="w-5 h-5 text-red-500" /> },
                  { label: "Voice Accuracy", value: "94.1%", icon: <Cpu className="w-5 h-5 text-blue-500" /> },
                  { label: "Languages Supported", value: "3", icon: <Bot className="w-5 h-5 text-green-500" /> },
                ].map((s, i) => (
                  <div key={i} className="bg-white dark:bg-card rounded-2xl border border-border p-4 shadow-sm text-center">
                    <div className="flex justify-center mb-2">{s.icon}</div>
                    <div className="text-xl font-bold text-foreground">{s.value}</div>
                    <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* AI Models Tab */}
          <TabsContent value="models">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {aiModels.map((m, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
                  className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#0B3D91] to-purple-600 flex items-center justify-center">
                      <Brain className="w-5 h-5 text-white" />
                    </div>
                    <Badge className={`text-xs ${m.status === "active" ? "bg-green-50 text-green-700 border-green-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}>
                      {m.status}
                    </Badge>
                  </div>
                  <h3 className="font-heading font-bold text-foreground text-sm mb-1">{m.name}</h3>
                  <div className="text-xs text-muted-foreground mb-3">{m.type}</div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Accuracy</span>
                    <span className="font-bold text-foreground">{m.accuracy}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden mb-3">
                    <motion.div className="h-full rounded-full bg-gradient-to-r from-[#0B3D91] to-purple-600"
                      initial={{ width: 0 }} animate={{ width: `${m.accuracy}%` }} transition={{ delay: i * 0.1, duration: 0.8 }} />
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <ScanLine className="w-3 h-3" />{m.scansToday} scans today
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="accuracy">
            <div className="max-w-3xl mx-auto space-y-6">
              <div className="bg-white dark:bg-card rounded-2xl border border-border p-6 shadow-sm">
                <h3 className="font-heading font-bold text-foreground mb-5">AI Accuracy Over 24 Hours</h3>
                <ResponsiveContainer width="100%" height={220}>
                  <AreaChart data={detectionData}>
                    <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                    <XAxis dataKey="time" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} domain={[90, 100]} />
                    <Tooltip formatter={(v) => [`${v}%`, "Accuracy"]} />
                    <defs>
                      <linearGradient id="accGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0B3D91" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#0B3D91" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <Area type="monotone" dataKey="accuracy" stroke="#0B3D91" strokeWidth={2.5} fill="url(#accGrad)" dot={{ r: 4 }} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-3 gap-5">
                {[
                  { label: "True Positives", value: "97.3%", desc: "Correctly identified scams", color: "text-[#2E8B57]", bg: "bg-green-50 dark:bg-green-950/20" },
                  { label: "False Positives", value: "0.8%", desc: "Legitimate flagged as scam", color: "text-amber-600", bg: "bg-amber-50 dark:bg-amber-950/20" },
                  { label: "False Negatives", value: "1.9%", desc: "Scams missed by AI", color: "text-red-600", bg: "bg-red-50 dark:bg-red-950/20" },
                ].map((s, i) => (
                  <div key={i} className={`${s.bg} rounded-2xl p-5 border border-border text-center`}>
                    <div className={`text-3xl font-heading font-bold ${s.color} mb-1`}>{s.value}</div>
                    <div className="text-sm font-semibold text-foreground mb-1">{s.label}</div>
                    <div className="text-xs text-muted-foreground">{s.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
