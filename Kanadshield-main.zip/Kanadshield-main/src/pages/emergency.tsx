import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Siren, MapPin, Heart, Activity, Phone, PhoneCall, Users,
  Wifi, Battery, Navigation, CheckCircle, AlertTriangle,
  Shield, Clock, Zap, Bell, User, Plus, X, ExternalLink
} from "lucide-react";

function ResponseTimer({ active }: { active: boolean }) {
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    if (!active) { setSeconds(0); return; }
    const t = setInterval(() => setSeconds(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [active]);
  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");
  return <span className="font-mono text-4xl font-bold">{mm}:{ss}</span>;
}

const contacts = [
  { name: "Ravi Shah", relation: "Son", phone: "+919876543210", display: "+91 98765 43210", avatar: "RS", color: "bg-blue-500", status: "notified" },
  { name: "Priya Shah", relation: "Daughter", phone: "+918765432109", display: "+91 87654 32109", avatar: "PS", color: "bg-purple-500", status: "notified" },
  { name: "Dr. Anjali Patel", relation: "Doctor", phone: "+919999912345", display: "+91 99999 12345", avatar: "AP", color: "bg-green-500", status: "on-call" },
  { name: "Cyber Safety Helpline", relation: "Police", phone: "1930", display: "1930", avatar: "CP", color: "bg-[#0B3D91]", status: "dispatched" },
];

const nearbyServices = [
  { name: "Satellite Police Station", type: "police", distance: "1.2 km", eta: "4 min", phone: "100", color: "text-[#0B3D91] bg-blue-50 border-blue-200" },
  { name: "Sterling Hospital", type: "hospital", distance: "2.3 km", eta: "7 min", phone: "108", color: "text-red-600 bg-red-50 border-red-200" },
  { name: "CIMS Hospital", type: "hospital", distance: "3.1 km", eta: "9 min", phone: "108", color: "text-red-600 bg-red-50 border-red-200" },
  { name: "Cyber Safety HQ", type: "police", distance: "4.5 km", eta: "12 min", phone: "1930", color: "text-[#0B3D91] bg-blue-50 border-blue-200" },
];

const initialLog = [
  { time: "14:28:00", event: "Daily check-in completed", type: "checkin" },
  { time: "14:15:00", event: "Medicine reminder sent — Aspirin 75mg", type: "medicine" },
];

const sosLog = [
  { time: "", event: "SOS Activated — GPS lock acquired", type: "sos" },
  { time: "", event: "Family notified: Ravi Shah, Priya Shah", type: "family" },
  { time: "", event: "Police safety alert sent", type: "police" },
  { time: "", event: "Nearest unit dispatched — ETA 4 min", type: "dispatch" },
];

export default function Emergency() {
  const [sosActive, setSosActive] = useState(false);
  const [sosHeld, setSosHeld] = useState(false);
  const [holdProgress, setHoldProgress] = useState(0);
  const [log, setLog] = useState(initialLog);
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationStatus, setLocationStatus] = useState("Requesting location access...");
  let holdTimer: ReturnType<typeof setInterval> | null = null;

  const startHold = () => {
    setSosHeld(true);
    let p = 0;
    holdTimer = setInterval(() => {
      p += 4;
      setHoldProgress(p);
      if (p >= 100) {
        clearInterval(holdTimer!);
        setSosActive(true);
        setSosHeld(false);
        setHoldProgress(0);
        const now = new Date();
        const timeStr = now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
        setLog([
          { time: timeStr, event: "SOS Activated — GPS lock acquired", type: "sos" },
          { time: timeStr, event: "Family notified: Ravi Shah, Priya Shah", type: "family" },
          { time: timeStr, event: "Police safety alert sent", type: "police" },
          { time: timeStr, event: "Nearest unit dispatched — ETA 4 min", type: "dispatch" },
          ...initialLog,
        ]);
      }
    }, 100);
  };

  useEffect(() => {
    if (!navigator.geolocation) {
      setLocationStatus("Live location is not supported by this browser.");
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      ({ coords }) => {
        setLocation({ latitude: coords.latitude, longitude: coords.longitude });
        setLocationStatus("Live location active");
      },
      () => setLocationStatus("Allow location access to show your live position."),
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 15000 },
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  const cancelHold = () => {
    setSosHeld(false);
    setHoldProgress(0);
    if (holdTimer) clearInterval(holdTimer);
  };

  const cancelSOS = () => {
    setSosActive(false);
    setLog(initialLog);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className={`sticky top-16 z-40 transition-colors duration-500 ${sosActive ? "bg-red-600" : "bg-[#0B3D91]"} text-white`}>
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Siren className={`w-6 h-6 ${sosActive ? "animate-bounce" : ""}`} />
            <div>
              <div className="font-heading font-bold text-lg">Emergency Dashboard</div>
              <div className="text-xs opacity-80">Emergency safety response</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm"><Wifi className="w-4 h-4" /><span>Signal Strong</span></div>
            <div className="flex items-center gap-2 text-sm"><Battery className="w-4 h-4" /><span>87%</span></div>
            {sosActive && <Badge className="bg-white text-red-600 font-bold animate-pulse">ACTIVE</Badge>}
          </div>
        </div>
      </div>

      {/* SOS Active Banner */}
      <AnimatePresence>
        {sosActive && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="bg-red-600 text-white overflow-hidden">
            <div className="container mx-auto px-4 py-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 0.8 }}>
                  <Siren className="w-6 h-6" />
                </motion.div>
                <div>
                  <div className="font-bold text-lg">🚨 SOS ACTIVE — Emergency services notified</div>
                  <div className="text-sm text-red-200">Police dispatched · Family alerted · Safety helpline informed</div>
                </div>
              </div>
              <div className="flex items-center gap-3 flex-wrap">
                <a href="tel:100" className="flex items-center gap-2 bg-white text-red-600 rounded-full px-5 py-2.5 font-bold text-sm hover:bg-red-50 transition-colors shadow-lg">
                  <Phone className="w-4 h-4" />Call Police 100
                </a>
                <a href="tel:108" className="flex items-center gap-2 bg-white/20 text-white rounded-full px-5 py-2.5 font-semibold text-sm hover:bg-white/30 transition-colors border border-white/40">
                  <Phone className="w-4 h-4" />Ambulance 108
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* SOS Column */}
          <div className="lg:col-span-1 flex flex-col gap-6">
            {/* SOS Button */}
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-white dark:bg-card rounded-3xl border border-border p-8 shadow-sm text-center">
              <div className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-6">Emergency SOS</div>
              <div className="relative flex items-center justify-center mb-6">
                {sosActive && (
                  <motion.div className="absolute w-52 h-52 rounded-full border-4 border-red-400"
                    animate={{ scale: [1, 1.3, 1], opacity: [0.8, 0, 0.8] }} transition={{ repeat: Infinity, duration: 1.2 }} />
                )}
                <motion.button
                  className={`relative w-44 h-44 rounded-full font-heading font-bold text-2xl text-white shadow-2xl flex flex-col items-center justify-center overflow-hidden border-4 border-white ${sosActive ? "bg-red-600" : "bg-gradient-to-br from-red-500 to-red-700"}`}
                  onMouseDown={startHold} onMouseUp={cancelHold} onTouchStart={startHold} onTouchEnd={cancelHold}
                  whileTap={{ scale: 0.96 }} data-testid="button-emergency-sos"
                >
                  {sosHeld && (
                    <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
                      <circle cx="50" cy="50" r="46" fill="none" stroke="white" strokeWidth="4" strokeOpacity="0.3" />
                      <circle cx="50" cy="50" r="46" fill="none" stroke="white" strokeWidth="4"
                        strokeDasharray={`${holdProgress * 2.89} 289`} />
                    </svg>
                  )}
                  <Siren className="w-12 h-12 mb-2" />
                  {sosActive ? "ACTIVE" : "SOS"}
                </motion.button>
              </div>

              {sosActive ? (
                <div>
                  <div className="text-red-600 font-heading font-bold text-lg mb-1">EMERGENCY ACTIVE</div>
                  <div className="text-muted-foreground text-sm mb-3">Police dispatched — ETA 4 minutes</div>
                  <ResponseTimer active={sosActive} />
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <a href="tel:100" className="flex items-center justify-center gap-1.5 bg-[#0B3D91] text-white rounded-xl py-2.5 text-sm font-bold hover:bg-[#0a3480] transition-colors">
                      <Phone className="w-4 h-4" />Call 100
                    </a>
                    <a href="tel:1930" className="flex items-center justify-center gap-1.5 bg-[#2E8B57] text-white rounded-xl py-2.5 text-sm font-bold hover:bg-green-700 transition-colors">
                      <Phone className="w-4 h-4" />Call 1930
                    </a>
                  </div>
                  <Button onClick={cancelSOS} variant="outline" className="mt-3 w-full rounded-xl border-red-300 text-red-600 hover:bg-red-50 text-sm" size="sm">
                    <X className="w-4 h-4 mr-1" />Cancel Emergency
                  </Button>
                </div>
              ) : (
                <div>
                  <p className="text-sm text-muted-foreground mb-3">Hold for 3 seconds to activate emergency alert</p>
                  {sosHeld && (
                    <p className="text-red-600 font-semibold text-sm animate-pulse">Keep holding...</p>
                  )}
                </div>
              )}
            </motion.div>

            {/* Quick Call — actual tel: links */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#0B3D91]" />Quick Call
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: "Police", num: "100", color: "bg-[#0B3D91] hover:bg-[#0a3480]" },
                  { label: "Ambulance", num: "108", color: "bg-red-600 hover:bg-red-700" },
                  { label: "Cyber Crime", num: "1930", color: "bg-[#2E8B57] hover:bg-green-700" },
                ].map((q, i) => (
                  <a key={i} href={`tel:${q.num}`}
                    className={`${q.color} text-white rounded-xl p-3 text-center transition-colors block`}
                    data-testid={`button-quick-call-${i}`}>
                    <Phone className="w-5 h-5 mx-auto mb-1" />
                    <div className="text-sm font-bold">{q.num}</div>
                    <div className="text-xs opacity-80">{q.label}</div>
                  </a>
                ))}
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <a href="tel:112" className="flex items-center justify-center gap-1.5 border border-border rounded-xl py-2 text-sm font-semibold text-foreground hover:bg-muted transition-colors">
                  <Siren className="w-4 h-4 text-red-500" />National 112
                </a>
                <a href="tel:181" className="flex items-center justify-center gap-1.5 border border-border rounded-xl py-2 text-sm font-semibold text-foreground hover:bg-muted transition-colors">
                  <Shield className="w-4 h-4 text-blue-500" />Women 181
                </a>
              </div>
            </motion.div>

            {/* Health Status */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className="text-sm font-semibold text-foreground mb-4">Health Status</div>
              {[
                { label: "Heart Rate", value: "78 BPM", icon: <Heart className="w-4 h-4 text-red-500" />, ok: true },
                { label: "Blood Pressure", value: "120/80", icon: <Activity className="w-4 h-4 text-blue-500" />, ok: true },
                { label: "SpO2", value: "98%", icon: <Zap className="w-4 h-4 text-green-500" />, ok: true },
                { label: "Temperature", value: "98.4°F", icon: <Zap className="w-4 h-4 text-amber-500" />, ok: true },
              ].map((h, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div className="flex items-center gap-2">{h.icon}<span className="text-sm text-muted-foreground">{h.label}</span></div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-foreground">{h.value}</span>
                    <span className={`w-2 h-2 rounded-full ${h.ok ? "bg-green-400" : "bg-red-400"}`} />
                  </div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Main Panel */}
          <div className="lg:col-span-2 flex flex-col gap-6">
            {/* Location */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="font-semibold text-foreground flex items-center gap-2"><Navigation className="w-4 h-4 text-[#0B3D91]" />Live Location</div>
                <div className="flex items-center gap-2">
                  <Badge className="bg-green-50 text-green-700 border-green-200">{location ? "GPS Active" : "GPS Pending"}</Badge>
                  {location && <a href={`https://maps.google.com/?q=${location.latitude},${location.longitude}`} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1 text-xs text-[#0B3D91] hover:underline">
                    Open Maps <ExternalLink className="w-3 h-3" />
                  </a>}
                </div>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/20 rounded-xl h-40 flex items-center justify-center relative overflow-hidden border border-blue-200 dark:border-blue-900/50 mb-4">
                <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 400 200">
                  {Array.from({ length: 10 }).map((_, i) => <line key={`v${i}`} x1={i * 44} y1="0" x2={i * 44} y2="200" stroke="#0B3D91" strokeWidth="1" />)}
                  {Array.from({ length: 6 }).map((_, i) => <line key={`h${i}`} x1="0" y1={i * 40} x2="400" y2={i * 40} stroke="#0B3D91" strokeWidth="1" />)}
                </svg>
                <div className="z-10 text-center">
                  <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1.5 }}>
                    <MapPin className="w-10 h-10 text-[#0B3D91] mx-auto" />
                  </motion.div>
                    <div className="font-semibold text-[#0B3D91] mt-2">{location ? "Your live position" : "Location access needed"}</div>
                    <div className="text-sm text-muted-foreground">{location ? `${location.latitude.toFixed(5)}°N, ${location.longitude.toFixed(5)}°E` : locationStatus}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {nearbyServices.map((s, i) => (
                  <div key={i} className={`rounded-xl p-3 border ${s.color} text-center`}>
                    <div className="text-xs font-semibold mb-1 truncate">{s.name.split(" ").slice(0, 2).join(" ")}</div>
                    <div className="text-lg font-bold">{s.distance}</div>
                    <div className="text-xs opacity-75 mb-2">ETA: {s.eta}</div>
                    <a href={`tel:${s.phone}`}
                      className="block w-full text-xs font-bold py-1.5 rounded-lg bg-white/80 hover:bg-white transition-colors text-center">
                      📞 {s.phone}
                    </a>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Contacts — with real tel: links */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className="font-semibold text-foreground mb-4 flex items-center gap-2"><Users className="w-4 h-4 text-[#0B3D91]" />Emergency Contacts</div>
              <div className="space-y-3">
                {contacts.map((c, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-muted/40 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full ${c.color} flex items-center justify-center text-white text-sm font-bold flex-shrink-0`}>{c.avatar}</div>
                      <div>
                        <div className="font-medium text-foreground text-sm">{c.name}</div>
                        <div className="text-xs text-muted-foreground">{c.relation} · {c.display}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={`text-xs ${c.status === "dispatched" ? "bg-red-50 text-red-600 border-red-200" : c.status === "notified" ? "bg-amber-50 text-amber-600 border-amber-200" : "bg-green-50 text-green-600 border-green-200"}`}>
                        {c.status}
                      </Badge>
                      <a href={`tel:${c.phone}`}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-full border border-green-300 text-green-600 hover:bg-green-50 text-xs font-semibold transition-colors"
                        data-testid={`button-call-contact-${i}`}>
                        <PhoneCall className="w-3 h-3" />Call
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Activity Log */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className="font-semibold text-foreground mb-4 flex items-center gap-2"><Bell className="w-4 h-4 text-[#0B3D91]" />Activity Log</div>
              <div className="space-y-3">
                {log.map((entry, i) => (
                  <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                    className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      entry.type === "sos" ? "bg-red-100 text-red-600" :
                      entry.type === "police" ? "bg-blue-100 text-blue-600" :
                      entry.type === "family" ? "bg-purple-100 text-purple-600" :
                      entry.type === "dispatch" ? "bg-amber-100 text-amber-600" :
                      "bg-green-100 text-green-600"
                    }`}>
                      {entry.type === "sos" ? <Siren className="w-4 h-4" /> :
                       entry.type === "police" ? <Shield className="w-4 h-4" /> :
                       entry.type === "family" ? <Users className="w-4 h-4" /> :
                       entry.type === "dispatch" ? <Navigation className="w-4 h-4" /> :
                       <CheckCircle className="w-4 h-4" />}
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-foreground">{entry.event}</div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Clock className="w-3 h-3" />{entry.time}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
