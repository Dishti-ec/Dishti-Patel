import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import {
  Shield, TrendingUp, CheckCircle, Clock, BarChart3, AlertTriangle, Users, Zap
} from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend
} from "recharts";

const monthlyData = [
  { month: "Jan", cases: 145, resolved: 132 }, { month: "Feb", cases: 178, resolved: 165 },
  { month: "Mar", cases: 203, resolved: 188 }, { month: "Apr", cases: 167, resolved: 159 },
  { month: "May", cases: 221, resolved: 208 }, { month: "Jun", cases: 248, resolved: 231 },
  { month: "Jul", cases: 189, resolved: 175 }, { month: "Aug", cases: 267, resolved: 251 },
  { month: "Sep", cases: 312, resolved: 295 }, { month: "Oct", cases: 278, resolved: 262 },
  { month: "Nov", cases: 341, resolved: 318 }, { month: "Dec", cases: 298, resolved: 280 },
];

const scamTypeData = [
  { name: "OTP Scam", value: 35, color: "#0B3D91" },
  { name: "UPI Fraud", value: 25, color: "#2E8B57" },
  { name: "Investment Fraud", value: 20, color: "#FFB703" },
  { name: "KYC Scam", value: 12, color: "#8B5CF6" },
  { name: "Other", value: 8, color: "#EC4899" },
];

const districtData = [
  { district: "North Zone", reports: 89, resolved: 82 },
  { district: "South Zone", reports: 67, resolved: 61 },
  { district: "East Zone", reports: 54, resolved: 50 },
  { district: "Central Zone", reports: 78, resolved: 71 },
  { district: "West Zone", reports: 45, resolved: 40 },
  { district: "Outer Zone", reports: 62, resolved: 58 },
];

const riskHeatmap = [
  ["Low", "Low", "Medium", "Low", "Low"],
  ["Medium", "High", "High", "Medium", "Low"],
  ["Low", "Medium", "Critical", "High", "Medium"],
  ["Low", "Low", "High", "Medium", "Low"],
  ["Low", "Low", "Medium", "Low", "Low"],
];

const riskColor: Record<string, string> = {
  Low: "bg-green-100 text-green-700",
  Medium: "bg-amber-100 text-amber-700",
  High: "bg-orange-100 text-orange-700",
  Critical: "bg-red-100 text-red-700",
};

const recentCases = [
  { id: "CC2024-1247", type: "OTP Scam", victim: "Shantaben P.", amount: "₹45,000", status: "Resolved", date: "Dec 18, 2024" },
  { id: "CC2024-1248", type: "UPI Fraud", victim: "Ramanbhai S.", amount: "₹12,500", status: "Active", date: "Dec 19, 2024" },
  { id: "CC2024-1249", type: "Fake Investment", victim: "Kamala M.", amount: "₹2,80,000", status: "Active", date: "Dec 19, 2024" },
  { id: "CC2024-1250", type: "KYC Scam", victim: "Ishwar B.", amount: "₹8,000", status: "Pending", date: "Dec 20, 2024" },
  { id: "CC2024-1251", type: "Voice Phishing", victim: "Savitaben J.", amount: "₹35,000", status: "Resolved", date: "Dec 20, 2024" },
  { id: "CC2024-1252", type: "Deepfake Scam", victim: "Govind P.", amount: "₹1,20,000", status: "Pending", date: "Dec 20, 2024" },
];

const statusColor: Record<string, string> = {
  Resolved: "bg-green-50 text-green-700 border-green-200",
  Active: "bg-red-50 text-red-700 border-red-200",
  Pending: "bg-amber-50 text-amber-700 border-amber-200",
};

export default function Analytics() {
  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[#0B3D91] text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-3 mb-2">
            <BarChart3 className="w-6 h-6" />
            <h1 className="text-2xl font-heading font-bold">Cyber Crime Analytics</h1>
          </div>
          <p className="text-blue-200 text-sm">Intelligence dashboard — VRIDDHAKSHA response network</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5 mb-8">
          {[
            { label: "Seniors Protected", value: "52,347", icon: <Users className="w-5 h-5" />, delta: "+12%", color: "text-[#0B3D91] bg-blue-50 dark:bg-blue-950/30" },
            { label: "Scams Prevented (Month)", value: "1,247", icon: <Shield className="w-5 h-5" />, delta: "+8%", color: "text-[#2E8B57] bg-green-50 dark:bg-green-950/30" },
            { label: "Avg Response Time", value: "8.2 min", icon: <Clock className="w-5 h-5" />, delta: "-23%", color: "text-amber-600 bg-amber-50 dark:bg-amber-950/30" },
            { label: "Resolution Rate", value: "94.2%", icon: <CheckCircle className="w-5 h-5" />, delta: "+5%", color: "text-purple-600 bg-purple-50 dark:bg-purple-950/30" },
          ].map((kpi, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
              className="bg-white dark:bg-card rounded-2xl border border-border p-5 shadow-sm">
              <div className={`w-10 h-10 rounded-xl ${kpi.color} flex items-center justify-center mb-3`}>{kpi.icon}</div>
              <div className="text-2xl font-heading font-bold text-foreground">{kpi.value}</div>
              <div className="text-sm text-muted-foreground mt-1">{kpi.label}</div>
              <div className={`text-xs font-semibold mt-2 ${kpi.delta.startsWith("+") ? "text-green-600" : "text-green-600"}`}>
                <TrendingUp className="w-3 h-3 inline mr-1" />{kpi.delta} this month
              </div>
            </motion.div>
          ))}
        </div>

        {/* Charts Row 1 */}
        <div className="grid md:grid-cols-3 gap-6 mb-6">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}
            className="md:col-span-2 bg-white dark:bg-card rounded-2xl border border-border p-6 shadow-sm">
            <h3 className="font-heading font-bold text-foreground mb-5">Monthly Fraud Trend (2024)</h3>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="cases" name="Cases Reported" stroke="#0B3D91" strokeWidth={2.5} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="resolved" name="Cases Resolved" stroke="#2E8B57" strokeWidth={2.5} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 }}
            className="bg-white dark:bg-card rounded-2xl border border-border p-6 shadow-sm">
            <h3 className="font-heading font-bold text-foreground mb-5">Scam Types</h3>
            <ResponsiveContainer width="100%" height={140}>
              <PieChart>
                <Pie data={scamTypeData} cx="50%" cy="50%" innerRadius={40} outerRadius={65} dataKey="value">
                  {scamTypeData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2 mt-3">
              {scamTypeData.map((d, i) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: d.color }} />
                  <span className="text-muted-foreground flex-1 text-xs">{d.name}</span>
                  <span className="font-semibold text-foreground text-xs">{d.value}%</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Charts Row 2 */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
            className="bg-white dark:bg-card rounded-2xl border border-border p-6 shadow-sm">
            <h3 className="font-heading font-bold text-foreground mb-5">District-wise Reports</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={districtData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="district" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="reports" name="Reported" fill="#0B3D91" radius={[4, 4, 0, 0]} />
                <Bar dataKey="resolved" name="Resolved" fill="#2E8B57" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Risk Heatmap */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
            className="bg-white dark:bg-card rounded-2xl border border-border p-6 shadow-sm">
            <h3 className="font-heading font-bold text-foreground mb-2">Regional Risk Heatmap</h3>
            <p className="text-xs text-muted-foreground mb-4">District-level senior citizen cyber risk index</p>
            <div className="grid gap-1.5" style={{ gridTemplateColumns: "repeat(5, 1fr)" }}>
              {riskHeatmap.flat().map((risk, i) => (
                <div key={i} className={`rounded-lg p-2 text-center text-xs font-semibold ${riskColor[risk]}`}>
                  {risk}
                </div>
              ))}
            </div>
            <div className="flex gap-4 mt-4 flex-wrap">
              {Object.entries(riskColor).map(([level, cls]) => (
                <div key={level} className="flex items-center gap-1.5">
                  <div className={`w-3 h-3 rounded-sm ${cls}`} />
                  <span className="text-xs text-muted-foreground">{level}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Recent Cases Table */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="bg-white dark:bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
          <div className="p-5 border-b border-border flex items-center justify-between">
            <h3 className="font-heading font-bold text-foreground">Recent Cases</h3>
            <Badge className="bg-blue-50 dark:bg-blue-950/50 text-[#0B3D91] border-blue-200">Live Updates</Badge>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/40">
                <tr>
                  {["Case ID", "Type", "Victim", "Amount", "Date", "Status"].map(h => (
                    <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recentCases.map((c, i) => (
                  <tr key={i} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors" data-testid={`row-case-${i}`}>
                    <td className="px-5 py-4 text-sm font-mono text-[#0B3D91]">{c.id}</td>
                    <td className="px-5 py-4 text-sm text-foreground">{c.type}</td>
                    <td className="px-5 py-4 text-sm text-foreground">{c.victim}</td>
                    <td className="px-5 py-4 text-sm font-semibold text-foreground">{c.amount}</td>
                    <td className="px-5 py-4 text-sm text-muted-foreground">{c.date}</td>
                    <td className="px-5 py-4">
                      <Badge className={`text-xs ${statusColor[c.status]}`}>{c.status}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
