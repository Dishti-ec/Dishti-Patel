import React, { createContext, useContext, useState } from "react";

export type Language = "en" | "hi" | "gu";

export const translations = {
  en: {
    // Nav
    nav_home: "Home",
    nav_emergency: "Emergency",
    nav_family: "Family",
    nav_resources: "Resources",
    nav_contact: "Contact",
    nav_get_protected: "Get Protected",
    nav_tagline: "Senior Safety Platform",

    // Hero
    hero_badge: "VRIDDHAKSHA safety network",
    hero_h1_1: "Cyber-Aware Safety &",
    hero_h1_2: "Welfare Platform",
    hero_h1_3: "for Senior Citizens",
    hero_sub: "Protecting senior citizens from cyber fraud, medical emergencies, and digital threats through AI-powered prevention and real-time police assistance.",
    hero_btn1: "Get Protected",
    hero_btn2: "Report Scam",
    hero_btn3: "Watch Demo",

    // Stats
    stat1_label: "Scams Prevented",
    stat2_label: "Monitoring",
    stat3_label: "Emergency SOS",
    stat4_label: "AI Accuracy",

    // Features
    features_badge: "Core Features",
    features_h2: "Complete Senior Protection",
    features_sub: "Six pillars of defence working together to keep every senior citizen safe, connected and confident.",
    feat1_title: "Emergency SOS",
    feat2_title: "Cyber Fraud Protection",
    feat3_title: "Evidence Collection",
    feat4_title: "Police Integration",
    feat5_title: "Family Dashboard",
    feat6_title: "Health & Welfare",
    learn_more: "Learn More",

    // How it works
    hiw_badge: "Process",
    hiw_h2: "How VRIDDHAKSHA Works",
    hiw_sub: "From threat detection to case resolution — every step automated and tracked.",
    step1: "Detect Threat",
    step2: "Verify with AI",
    step3: "Alert Senior Citizen",
    step4: "Notify Family",
    step5: "Notify Police Safety Network",
    step6: "Track Resolution",

    // AI Demo
    ai_badge: "Live Demo",
    ai_h2: "AI Scam Detection",
    ai_sub: "Try our AI — paste a suspicious message, call transcript, or email and see instant threat classification.",
    ai_engine: "VRIDDHAKSHA AI Engine",
    ai_poweredby: "Powered by VRIDDHAKSHA AI Engine",
    ai_live: "Live",
    ai_analyze: "Analyze Now",
    ai_analyzing: "Analyzing with AI...",
    ai_threat_indicators: "Threat Indicators:",

    // Emergency section
    em_badge: "Emergency System",
    em_h2: "Emergency Dashboard",
    em_sub: "One tap to safety. Real-time coordination between senior citizens, family, and police.",
    em_open: "Open Full Emergency Dashboard",

    // Awareness
    aw_badge: "Education",
    aw_h2: "Awareness Center",
    aw_sub: "Knowledge is the best defence. Learn to recognize and avoid every type of cyber scam.",

    // Testimonials
    test_badge: "Testimonials",
    test_h2: "Trusted by Those Who Matter",

    // CTA strip
    cta_h2: "Protect Your Loved Ones Today",
    cta_sub: "Join 50,000+ senior citizens already protected by VRIDDHAKSHA",
    cta_btn1: "Get Protected Now",
    cta_btn2: "Contact Us",

    // Footer
    footer_tagline: "Protecting Every Senior. Every Second.",
    footer_emergency: "Emergency Numbers",
    footer_links: "Quick Links",
    footer_rights: "All rights reserved.",
    footer_cyber: "VRIDDHAKSHA Platform.",
  },

  hi: {
    // Nav
    nav_home: "होम",
    nav_emergency: "आपातकाल",
    nav_family: "परिवार",
    nav_resources: "संसाधन",
    nav_contact: "संपर्क",
    nav_get_protected: "सुरक्षित हों",
    nav_tagline: "वरिष्ठ सुरक्षा मंच",

    // Hero
    hero_badge: "VRIDDHAKSHA सुरक्षा नेटवर्क",
    hero_h1_1: "वरिष्ठ नागरिकों के लिए",
    hero_h1_2: "साइबर सुरक्षा एवं",
    hero_h1_3: "कल्याण मंच",
    hero_sub: "AI-संचालित सुरक्षा और वास्तविक समय पुलिस सहायता के माध्यम से वरिष्ठ नागरिकों को साइबर धोखाधड़ी, चिकित्सा आपात स्थितियों और डिजिटल खतरों से बचाना।",
    hero_btn1: "सुरक्षित हों",
    hero_btn2: "घोटाला रिपोर्ट करें",
    hero_btn3: "डेमो देखें",

    // Stats
    stat1_label: "घोटाले रोके गए",
    stat2_label: "निगरानी",
    stat3_label: "आपातकालीन SOS",
    stat4_label: "AI सटीकता",

    // Features
    features_badge: "मुख्य विशेषताएं",
    features_h2: "संपूर्ण वरिष्ठ सुरक्षा",
    features_sub: "छह सुरक्षा स्तंभ मिलकर हर वरिष्ठ नागरिक को सुरक्षित, जुड़ा हुआ और आत्मविश्वासी रखते हैं।",
    feat1_title: "आपातकालीन SOS",
    feat2_title: "साइबर धोखाधड़ी सुरक्षा",
    feat3_title: "साक्ष्य संग्रह",
    feat4_title: "पुलिस एकीकरण",
    feat5_title: "परिवार डैशबोर्ड",
    feat6_title: "स्वास्थ्य एवं कल्याण",
    learn_more: "और जानें",

    // How it works
    hiw_badge: "प्रक्रिया",
    hiw_h2: "VRIDDHAKSHA कैसे काम करता है",
    hiw_sub: "खतरे की पहचान से लेकर मामले के समाधान तक — हर कदम स्वचालित और ट्रैक किया गया।",
    step1: "खतरा पहचानें",
    step2: "AI से सत्यापित करें",
    step3: "वरिष्ठ नागरिक को अलर्ट करें",
    step4: "परिवार को सूचित करें",
    step5: "पुलिस सुरक्षा नेटवर्क को सूचित करें",
    step6: "समाधान ट्रैक करें",

    // AI Demo
    ai_badge: "लाइव डेमो",
    ai_h2: "AI घोटाला पहचान",
    ai_sub: "हमारा AI आज़माएं — संदिग्ध संदेश, कॉल ट्रांसक्रिप्ट या ईमेल डालें और तत्काल खतरे का वर्गीकरण देखें।",
    ai_engine: "VRIDDHAKSHA AI इंजन",
    ai_poweredby: "VRIDDHAKSHA AI इंजन द्वारा संचालित",
    ai_live: "लाइव",
    ai_analyze: "अभी विश्लेषण करें",
    ai_analyzing: "AI से विश्लेषण हो रहा है...",
    ai_threat_indicators: "खतरे के संकेत:",

    // Emergency section
    em_badge: "आपातकालीन प्रणाली",
    em_h2: "आपातकालीन डैशबोर्ड",
    em_sub: "एक टैप से सुरक्षा। वरिष्ठ नागरिकों, परिवार और पुलिस के बीच वास्तविक समय समन्वय।",
    em_open: "पूर्ण आपातकालीन डैशबोर्ड खोलें",

    // Awareness
    aw_badge: "शिक्षा",
    aw_h2: "जागरूकता केंद्र",
    aw_sub: "ज्ञान सबसे अच्छा बचाव है। हर प्रकार के साइबर घोटाले को पहचानना और बचना सीखें।",

    // Testimonials
    test_badge: "प्रशंसापत्र",
    test_h2: "जो मायने रखते हैं उन पर भरोसा",

    // CTA strip
    cta_h2: "आज ही अपने प्रियजनों की रक्षा करें",
    cta_sub: "VRIDDHAKSHA द्वारा सुरक्षित 50,000+ वरिष्ठ नागरिकों से जुड़ें।",
    cta_btn1: "अभी सुरक्षित हों",
    cta_btn2: "संपर्क करें",

    // Footer
    footer_tagline: "हर वरिष्ठ नागरिक की रक्षा। हर पल।",
    footer_emergency: "आपातकालीन नंबर",
    footer_links: "त्वरित लिंक",
    footer_rights: "सर्वाधिकार सुरक्षित।",
    footer_cyber: "VRIDDHAKSHA मंच।",
  },

  gu: {
    // Nav
    nav_home: "હોમ",
    nav_emergency: "કટોકટી",
    nav_family: "પરિવાર",
    nav_resources: "સ્ત્રોતો",
    nav_contact: "સંપર્ક",
    nav_get_protected: "સુરક્ષિત થાઓ",
    nav_tagline: "વૃદ્ધ સલામતી પ્લેટફોર્મ",

    // Hero
    hero_badge: "VRIDDHAKSHA સુરક્ષા નેટવર્ક",
    hero_h1_1: "વૃદ્ધ નાગરિકો માટે",
    hero_h1_2: "સાઇબર સલામતી અને",
    hero_h1_3: "કલ્યાણ પ્લેટફોર્મ",
    hero_sub: "AI-સંચાલિત નિવારણ અને રીઅલ-ટાઇમ પોલીસ સહાય દ્વારા વૃદ્ધ નાગરિકોને સાઇબર છેતરપિંડી, તબીબી કટોકટી અને ડિજિટલ ખતરાઓથી રક્ષણ.",
    hero_btn1: "સુરક્ષિત થાઓ",
    hero_btn2: "છેતરપિંડી નોંધો",
    hero_btn3: "ડેમો જુઓ",

    // Stats
    stat1_label: "છેતરપિંડી અટકાવી",
    stat2_label: "નિગરાની",
    stat3_label: "કટોકટી SOS",
    stat4_label: "AI ચોકસાઈ",

    // Features
    features_badge: "મુખ્ય સુવિધાઓ",
    features_h2: "સંપૂર્ણ વૃદ્ધ સુરક્ષા",
    features_sub: "છ સુરક્ષા સ્તંભ ભેગા મળીને દરેક વૃદ્ધ નાગરિકને સુરક્ષિત, જોડાયેલ અને આત્મવિશ્વાસી રાખે છે.",
    feat1_title: "કટોકટી SOS",
    feat2_title: "સાઇબર છેતરપિંડી સુરક્ષા",
    feat3_title: "પુરાવા સંગ્રહ",
    feat4_title: "પોલીસ એકીકરણ",
    feat5_title: "પરિવાર ડૅશબોર્ડ",
    feat6_title: "આરોગ્ય અને કલ્યાણ",
    learn_more: "વધુ જાણો",

    // How it works
    hiw_badge: "પ્રક્રિયા",
    hiw_h2: "VRIDDHAKSHA કેવી રીતે કામ કરે છે",
    hiw_sub: "ખતરાની ઓળખથી લઈને કેસ નિવારણ સુધી — દરેક પગલું સ્વચાલિત અને ટ્ર્રૅક.",
    step1: "ખતરો ઓળખો",
    step2: "AI સાથે ચકાસો",
    step3: "વૃદ્ધ નાગરિકને ચેતવો",
    step4: "પરિવારને જાણ કરો",
    step5: "પોલીસ સુરક્ષા નેટવર્કને જાણ કરો",
    step6: "નિવારણ ટ્ર્રૅક કરો",

    // AI Demo
    ai_badge: "લાઇવ ડેમો",
    ai_h2: "AI છેતરપિંડી શોધ",
    ai_sub: "અમારું AI અજમાવો — શંકાસ્પદ સંદેશ, કૉલ ટ્રાન્સ્ક્રિપ્ટ અથવા ઇમેઇલ દાખલ કરો અને તાત્કાલિક ખતરાનું વર્ગીકરણ જુઓ.",
    ai_engine: "VRIDDHAKSHA AI એન્જિન",
    ai_poweredby: "VRIDDHAKSHA AI એન્જિન દ્વારા સંચાલિત",
    ai_live: "લાઇવ",
    ai_analyze: "હમણાં વિશ્લેષણ કરો",
    ai_analyzing: "AI સાથે વિશ્લેષણ...",
    ai_threat_indicators: "ખતરાના સંકેત:",

    // Emergency section
    em_badge: "કટોકટી સિસ્ટમ",
    em_h2: "કટોકટી ડૅશબોર્ડ",
    em_sub: "એક ટૅપ સાથે સલામતી. વૃદ્ધ નાગરિકો, પરિવાર અને પોલીસ વચ્ચે રીઅલ-ટાઇમ સંકલન.",
    em_open: "સંપૂર્ણ કટોકટી ડૅશબોર્ડ ખોલો",

    // Awareness
    aw_badge: "શિક્ષણ",
    aw_h2: "જાગૃતતા કેન્દ્ર",
    aw_sub: "જ્ઞાન એ શ્રેષ્ઠ રક્ષા છે. દરેક પ્રકારની સાઇબર છેતરપિંડી ઓળખવા અને ટાળવાનું શીખો.",

    // Testimonials
    test_badge: "પ્રશંસાપત્રો",
    test_h2: "જે મહત્ત્વ ધરાવે છે તે પર વિશ્વાસ",

    // CTA strip
    cta_h2: "આજે જ તમારા પ્રિયજનોને સુરક્ષિત કરો",
    cta_sub: "VRIDDHAKSHA દ્વારા સુરક્ષિત 50,000+ વૃદ્ધ નાગરિકો સાથે જોડાઓ.",
    cta_btn1: "હમણાં સુરક્ષિત થાઓ",
    cta_btn2: "સંપર્ક કરો",

    // Footer
    footer_tagline: "દરેક વૃદ્ધ નાગરિકનું રક્ષણ. દરેક ક્ષણ.",
    footer_emergency: "કટોકટી નંબર",
    footer_links: "ઝડપી લિંક",
    footer_rights: "સર્વ અધિકાર સુરક્ષિત.",
    footer_cyber: "VRIDDHAKSHA પ્લેટફોર્મ.",
  },
};

export type TranslationKey = keyof typeof translations.en;

interface I18nContextValue {
  lang: Language;
  setLang: (l: Language) => void;
  t: (key: TranslationKey) => string;
}

const I18nContext = createContext<I18nContextValue>({
  lang: "en",
  setLang: () => {},
  t: (key) => translations.en[key],
});

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLang] = useState<Language>("en");
  const t = (key: TranslationKey): string => translations[lang][key] ?? translations.en[key];
  return <I18nContext.Provider value={{ lang, setLang, t }}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  return useContext(I18nContext);
}
