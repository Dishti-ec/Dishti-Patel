import React from "react";
import { Link, useLocation } from "wouter";
import { useTheme } from "next-themes";
import { Shield, Sun, Moon, Globe, Menu, X, AlertTriangle, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { useI18n, Language } from "@/lib/i18n";

export default function Navbar() {
  const [location, setLocation] = useLocation();
  const { theme, setTheme } = useTheme();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [moreOpen, setMoreOpen] = React.useState(false);
  const { t, lang, setLang } = useI18n();

  const primaryLinks = [
    { name: t("nav_home"), path: "/" },
    { name: t("nav_emergency"), path: "/emergency" },
    { name: t("nav_family"), path: "/family" },
    { name: "AI Protection", path: "/ai-protection" },
    { name: "Track Case", path: "/case-tracker" },
    { name: t("nav_resources"), path: "/resources" },
  ];

  const moreLinks = [
    { name: t("nav_contact"), path: "/contact" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/90 backdrop-blur-md supports-[backdrop-filter]:bg-background/60 shadow-sm">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 gap-2">
        <Link href="/" className="flex items-center gap-2.5 flex-shrink-0">
          <div className="bg-primary p-1.5 rounded-lg">
            <Shield className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <span className="font-heading font-bold text-primary text-lg tracking-tight leading-none block">VRIDDHAKSHA</span>
            <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">{t("nav_tagline")}</span>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {primaryLinks.map((link) => (
            <Link
              key={link.path}
              href={link.path}
              className={`text-sm font-medium px-3 py-1.5 rounded-full transition-colors hover:text-primary hover:bg-primary/5 ${location === link.path ? "text-primary font-bold bg-primary/8" : "text-foreground/80"}`}
            >
              {link.name}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-2 flex-shrink-0">
          <div className="flex items-center gap-1 border border-border rounded-full px-2 py-1 bg-card/50">
            <Globe className="w-3.5 h-3.5 text-muted-foreground" />
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value as Language)}
              className="bg-transparent text-xs font-medium text-foreground outline-none appearance-none cursor-pointer pr-0.5"
              aria-label="Select language"
            >
              <option value="en">EN</option>
              <option value="hi">हिं</option>
              <option value="gu">ગુ</option>
            </select>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="rounded-full w-8 h-8"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>

          <Button
            onClick={() => setLocation("/report-scam")}
            size="sm"
            className="font-semibold bg-[#FFB703] hover:bg-[#e5a400] text-gray-900 rounded-full px-4 text-xs"
          >
            <AlertTriangle className="w-3.5 h-3.5 mr-1.5" />Report Scam
          </Button>

          <Button onClick={() => setLocation("/emergency")} className="font-semibold bg-primary hover:bg-primary/90 text-white rounded-full px-4 text-sm">
            {t("nav_get_protected")}
          </Button>
        </div>

        {/* Mobile controls */}
        <div className="lg:hidden flex items-center gap-1.5">
          <div className="flex items-center gap-1 border border-border rounded-full px-2 py-1 bg-card/50">
            <Globe className="w-3 h-3 text-muted-foreground" />
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value as Language)}
              className="bg-transparent text-xs font-medium text-foreground outline-none appearance-none cursor-pointer"
            >
              <option value="en">EN</option>
              <option value="hi">हिं</option>
              <option value="gu">ગુ</option>
            </select>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} className="w-8 h-8">
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="w-8 h-8">
            {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden border-t border-border bg-background/95 backdrop-blur-md overflow-hidden"
          >
            <nav className="flex flex-col p-4 gap-1">
              {[...primaryLinks, ...moreLinks].map((link) => (
                <Link
                  key={link.path}
                  href={link.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`text-sm font-medium py-2.5 px-4 rounded-xl transition-colors ${location === link.path ? "text-primary bg-primary/8 font-bold" : "text-foreground/80 hover:bg-muted"}`}
                >
                  {link.name}
                </Link>
              ))}
              <div className="flex gap-2 mt-3 pt-3 border-t border-border">
                <Button onClick={() => { setLocation("/report-scam"); setIsMobileMenuOpen(false); }} className="flex-1 bg-[#FFB703] text-gray-900 hover:bg-[#e5a400] rounded-full font-semibold text-sm">
                  <AlertTriangle className="w-4 h-4 mr-1.5" />Report Scam
                </Button>
                <Button onClick={() => { setLocation("/emergency"); setIsMobileMenuOpen(false); }} className="flex-1 bg-primary text-white rounded-full font-semibold text-sm">
                  {t("nav_get_protected")}
                </Button>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
