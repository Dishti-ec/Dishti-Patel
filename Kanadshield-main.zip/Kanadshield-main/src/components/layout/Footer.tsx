import React from "react";
import { Link } from "wouter";
import { Shield, Phone, MapPin, Mail, Twitter, Facebook, Instagram } from "lucide-react";
import { useI18n } from "@/lib/i18n";

export default function Footer() {
  const { t } = useI18n();

  return (
    <footer className="bg-[#0B3D91] text-white pt-16 pb-8 border-t border-blue-800">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-white/10 p-2 rounded-lg backdrop-blur-sm">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <div>
                <span className="font-heading font-bold text-xl tracking-tight block">VRIDDHAKSHA</span>
                <span className="text-xs text-blue-200 uppercase tracking-widest font-semibold">{t("nav_tagline")}</span>
              </div>
            </div>
            <p className="text-blue-200 mb-6 text-sm leading-relaxed">{t("footer_tagline")}</p>
            <div className="flex gap-4">
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-white/20 transition-colors" aria-label="Twitter">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-white/20 transition-colors" aria-label="Facebook">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-white/20 transition-colors" aria-label="Instagram">
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-6 border-b border-blue-800 pb-2">{t("footer_links")}</h3>
            <ul className="space-y-3">
              <li><Link href="/" className="text-blue-200 hover:text-white transition-colors text-sm">{t("nav_home")}</Link></li>
              <li><Link href="/emergency" className="text-blue-200 hover:text-white transition-colors text-sm">{t("nav_emergency")}</Link></li>
              <li><Link href="/family" className="text-blue-200 hover:text-white transition-colors text-sm">{t("nav_family")}</Link></li>
              <li><Link href="/resources" className="text-blue-200 hover:text-white transition-colors text-sm">{t("nav_resources")}</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-6 border-b border-blue-800 pb-2">{t("footer_emergency")}</h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-3">
                <div className="bg-red-500/20 p-2 rounded-full text-red-400">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white leading-none">100</div>
                  <div className="text-xs text-blue-200 uppercase tracking-wider">Police</div>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <div className="bg-green-500/20 p-2 rounded-full text-green-400">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white leading-none">108</div>
                  <div className="text-xs text-blue-200 uppercase tracking-wider">Ambulance</div>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <div className="bg-amber-500/20 p-2 rounded-full text-amber-400">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white leading-none">1930</div>
                  <div className="text-xs text-blue-200 uppercase tracking-wider">Cyber Helpline</div>
                </div>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-6 border-b border-blue-800 pb-2">{t("nav_contact")}</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-blue-300 shrink-0 mt-0.5" />
                <span className="text-blue-200 text-sm">VRIDDHAKSHA Support Center<br />Online assistance available nationwide</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-blue-300 shrink-0" />
                <span className="text-blue-200 text-sm">079-22843050</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-blue-300 shrink-0" />
                <span className="text-blue-200 text-sm">support@vriddhaksha.in</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-blue-800/50 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-blue-300 text-sm text-center md:text-left">
            &copy; {new Date().getFullYear()} {t("footer_cyber")} {t("footer_rights")}
          </p>
          <div className="flex gap-6 text-sm text-blue-300">
            <Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
            <Link href="/accessibility" className="hover:text-white transition-colors">Accessibility</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
