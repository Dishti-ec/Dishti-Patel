import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Accessibility, Type, Sun, ZoomIn, ZoomOut, X, Eye } from "lucide-react";

export default function AccessibilityPanel() {
  const [open, setOpen] = useState(false);
  const [fontSize, setFontSize] = useState(100);
  const [highContrast, setHighContrast] = useState(false);

  useEffect(() => {
    document.documentElement.style.fontSize = `${fontSize}%`;
  }, [fontSize]);

  useEffect(() => {
    if (highContrast) {
      document.documentElement.classList.add("high-contrast");
    } else {
      document.documentElement.classList.remove("high-contrast");
    }
  }, [highContrast]);

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen(o => !o)}
        className="fixed bottom-28 right-6 z-50 w-12 h-12 rounded-full bg-[#2E8B57] text-white shadow-lg flex items-center justify-center border-2 border-white"
        aria-label="Accessibility options"
        data-testid="button-accessibility"
      >
        <Accessibility className="w-5 h-5" />
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed bottom-44 right-6 z-50 w-56 bg-white dark:bg-card rounded-2xl border border-border shadow-2xl overflow-hidden"
          >
            <div className="bg-[#2E8B57] text-white px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Accessibility className="w-4 h-4" />
                <span className="text-sm font-semibold">Accessibility</span>
              </div>
              <button onClick={() => setOpen(false)} className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors">
                <X className="w-3 h-3" />
              </button>
            </div>

            <div className="p-4 space-y-4">
              <div>
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Type className="w-3 h-3" />Font Size
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setFontSize(f => Math.max(80, f - 10))}
                    className="w-8 h-8 rounded-full border border-border flex items-center justify-center hover:bg-muted transition-colors text-foreground"
                    aria-label="Decrease font size"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <div className="flex-1 text-center text-sm font-bold text-foreground">{fontSize}%</div>
                  <button
                    onClick={() => setFontSize(f => Math.min(140, f + 10))}
                    className="w-8 h-8 rounded-full border border-border flex items-center justify-center hover:bg-muted transition-colors text-foreground"
                    aria-label="Increase font size"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex gap-1.5 mt-2">
                  {[90, 100, 120].map(size => (
                    <button key={size} onClick={() => setFontSize(size)}
                      className={`flex-1 text-xs py-1 rounded-lg border transition-colors font-medium ${fontSize === size ? "bg-[#2E8B57] text-white border-[#2E8B57]" : "border-border text-foreground hover:bg-muted"}`}>
                      {size === 90 ? "A−" : size === 100 ? "A" : "A+"}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Eye className="w-3 h-3" />High Contrast
                </div>
                <button
                  onClick={() => setHighContrast(hc => !hc)}
                  className={`w-full py-2 rounded-xl border font-medium text-sm transition-all ${highContrast ? "bg-black text-white border-black" : "border-border text-foreground hover:bg-muted"}`}
                  data-testid="button-high-contrast"
                >
                  {highContrast ? "Contrast: ON" : "Contrast: OFF"}
                </button>
              </div>

              <button
                onClick={() => setFontSize(100)}
                className="w-full py-2 rounded-xl border border-border text-sm text-muted-foreground hover:bg-muted transition-colors font-medium"
              >
                Reset to Default
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
