import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Bot, X, Send, Mic, MicOff, Phone, Shield } from "lucide-react";
import { useI18n } from "@/lib/i18n";

type Msg = { role: "user" | "bot"; text: string; time: string };

const knowledge: Array<{ keywords: string[]; en: string; hi: string; gu: string }> = [
  {
    keywords: ["otp", "one time", "password"],
    en: "⚠️ Never share OTP with anyone — not even bank officials. Banks NEVER ask for OTP. If someone is asking for your OTP, it is 100% a scam. Hang up immediately and call your bank's official helpline.",
    hi: "⚠️ कभी भी OTP किसी के साथ साझा न करें — बैंक अधिकारियों के साथ भी नहीं। बैंक कभी OTP नहीं मांगता। तुरंत फोन काटें और अपने बैंक को कॉल करें।",
    gu: "⚠️ ક્યારેય OTP કોઈની સાથે શેર ન કરો — બેન્ક અધિકારી સાથે પણ નહીં. બેન્ક ક્યારેય OTP માંગતી નથી. તરત ફોન કાપો.",
  },
  {
    keywords: ["upi", "payment", "qr", "scan", "receive money"],
    en: "🚨 UPI scam alert! Scanning a QR code or approving a 'collect request' SENDS money from your account — it can never receive money. If someone says 'scan to receive money', it's always fraud.",
    hi: "🚨 UPI घोटाला! QR स्कैन करने से आपके खाते से पैसे जाते हैं — आते नहीं। 'पैसे प्राप्त करने के लिए स्कैन करें' — यह हमेशा धोखाधड़ी है।",
    gu: "🚨 UPI છેતરપિંડી! QR સ્કૅન કરવાથી પૈસા જાય છે — આવે નહીં. 'પૈસા મળવા માટે સ્કૅન કરો' — આ હંમેશા છળ છે.",
  },
  {
    keywords: ["invest", "return", "profit", "stock", "crypto", "scheme"],
    en: "⚠️ Investment fraud warning! No legitimate investment guarantees 30%+ returns. If someone promises guaranteed high profits — it is always a Ponzi scheme. Only invest through SEBI-registered advisors.",
    hi: "⚠️ निवेश घोटाला! कोई भी वैध निवेश 30%+ रिटर्न की गारंटी नहीं देता। SEBI-पंजीकृत सलाहकार के माध्यम से ही निवेश करें।",
    gu: "⚠️ રોકાણ છેતરપિંડી! કોઈ પણ વૈધ રોકાণ 30%+ વળતરની ગેરેંટી આપતું નથી. ફક્ત SEBI-નોંધાયેલ સલાહકાર દ્વારા રોકાણ કરો.",
  },
  {
    keywords: ["kyc", "update", "block", "account", "link"],
    en: "🛑 KYC scam! Real KYC is done physically at your bank branch — NEVER over a phone call or WhatsApp link. If you received a link or call for KYC, ignore it and call your bank directly.",
    hi: "🛑 KYC घोटाला! असली KYC बैंक शाखा में होती है — फोन कॉल या WhatsApp लिंक पर कभी नहीं। लिंक पर क्लिक न करें।",
    gu: "🛑 KYC છળ! સાચી KYC ફક્ત બેન્ક શાખામાં થાય — ફોન કૉલ કે WhatsApp link પર નહીં. Link પર ક્લિક ન કરો.",
  },
  {
    keywords: ["sos", "emergency", "help", "danger", "police"],
    en: "🚨 EMERGENCY: Call 100 (Police) or 1930 (Cyber Crime Helpline) IMMEDIATELY. You can also press the SOS button on the Emergency page of this app. Stay calm and stay on the line.",
    hi: "🚨 आपातकाल: तुरंत 100 (पुलिस) या 1930 (साइबर अपराध) पर कॉल करें। इस ऐप पर आपातकालीन पृष्ठ का SOS बटन दबाएं।",
    gu: "🚨 કટોકટી: તરત 100 (પોલીસ) અથવા 1930 (સાઇબર ક્રાઈમ) પર ફોન કરો. ઍપ પર Emergency SOS બટન દબાવો.",
  },
  {
    keywords: ["report", "complaint", "fir", "case"],
    en: "📋 To report cyber crime: 1) Call 1930 (National Cyber Helpline) 2) File a complaint at cybercrime.gov.in 3) Contact your nearest police station. Collect all evidence (screenshots, transaction IDs) before reporting.",
    hi: "📋 साइबर अपराध रिपोर्ट करने के लिए: 1) 1930 पर कॉल करें 2) cybercrime.gov.in पर शिकायत दर्ज करें 3) साइबर अपराध शाखा, अहमदाबाद जाएं।",
    gu: "📋 સાઇબર ક્રાઈમ નોંધવા: 1) 1930 પર ફોન 2) cybercrime.gov.in પર ફરિયાદ 3) સાઇબર ક્રાઈમ શાખા, અમદાવાદ.",
  },
  {
    keywords: ["deepfake", "video", "voice", "clone", "ai call"],
    en: "🤖 AI Deepfake scam! AI can clone anyone's face & voice. If a video call shows a relative in distress asking for money — always verify by calling them back on their KNOWN number before sending anything.",
    hi: "🤖 AI डीपफेक घोटाला! AI किसी का भी चेहरा और आवाज नकल कर सकता है। पैसे भेजने से पहले उनके जाने-माने नंबर पर वापस कॉल करें।",
    gu: "🤖 AI Deepfake છळ! AI કોઈ પણ ચહેરો અને અવાજ નકલ કરી શકે. પૈસા મોકલતા પહેલા તેમના જાણીતા નંબર પર ફોન કરો.",
  },
  {
    keywords: ["sim", "swap", "signal", "network", "no service"],
    en: "📱 SIM Swap alert! If your phone suddenly loses signal, call your operator IMMEDIATELY from another phone. Then freeze your bank accounts. SIM swap lets fraudsters intercept all your OTPs.",
    hi: "📱 SIM स्वैप! अगर आपका फोन अचानक नेटवर्क खो दे, तो दूसरे फोन से अपने ऑपरेटर को कॉल करें और बैंक खाता तुरंत फ्रीज़ करें।",
    gu: "📱 SIM Swap! ફોન અચાનક signal ગુમાવે, તો બીજા ફોનથી operator ને ફોન કરો અને bank account ફ્રીઝ કરો.",
  },
];

const greetings = {
  en: [
    "Hello! I'm VRIDDHAKSHA AI Assistant 🛡️ How can I help protect you today?",
    "You can ask me about: OTP scams, UPI fraud, investment fraud, KYC scams, SIM swap, deepfakes, or how to report a crime.",
  ],
  hi: [
    "नमस्ते! मैं VRIDDHAKSHA AI सहायक हूं 🛡️ आज मैं आपकी कैसे सुरक्षा कर सकता हूं?",
    "आप मुझसे पूछ सकते हैं: OTP घोटाला, UPI धोखाधड़ी, निवेश घोटाला, KYC, SIM swap या अपराध रिपोर्ट करने के बारे में।",
  ],
  gu: [
    "નમસ્તે! હું VRIDDHAKSHA AI સહાયક છું 🛡️ આજે હું તમને કેવી રીતે મદદ કરી શકું?",
    "OTP છળ, UPI છળ, રોકાણ છળ, KYC, SIM swap અથવા ગુના નોંધવા વિશે પૂછો.",
  ],
};

const fallbacks = {
  en: "I'm not sure about that specific query. For urgent matters, please call **1930** (Cyber Crime Helpline) or **100** (Police). You can also use the Report Scam page to file a complaint.",
  hi: "इस विशेष प्रश्न के बारे में मुझे निश्चित नहीं है। तत्काल मामलों के लिए **1930** या **100** पर कॉल करें।",
  gu: "આ ચોક્કસ પ્રશ્ન વિશે મને ખાતરી નથી. તાત્કાલિક બાબતો માટે **1930** અથવા **100** પર ફોન કરો.",
};

function getAnswer(input: string, lang: "en" | "hi" | "gu"): string {
  const lower = input.toLowerCase();
  for (const entry of knowledge) {
    if (entry.keywords.some(kw => lower.includes(kw))) {
      return entry[lang];
    }
  }
  return fallbacks[lang];
}

function now() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export default function ChatBot() {
  const { lang } = useI18n();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [listening, setListening] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    if (open && messages.length === 0) {
      const gs = greetings[lang] ?? greetings.en;
      setMessages(gs.map(text => ({ role: "bot", text, time: now() })));
    }
  }, [open]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Msg = { role: "user", text, time: now() };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      const answer = getAnswer(text, lang as "en" | "hi" | "gu");
      setMessages(prev => [...prev, { role: "bot", text: answer, time: now() }]);
      setTyping(false);
    }, 800 + Math.random() * 600);
  };

  const startListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;
    const r = new SpeechRecognition();
    r.lang = lang === "hi" ? "hi-IN" : lang === "gu" ? "gu-IN" : "en-IN";
    r.onresult = (e: SpeechRecognitionEvent) => {
      const transcript = e.results[0][0].transcript;
      setInput(transcript);
      setListening(false);
    };
    r.onend = () => setListening(false);
    r.start();
    recognitionRef.current = r;
    setListening(true);
  };

  const labels = {
    en: { title: "VRIDDHAKSHA AI Assistant", subtitle: "Ask me about cyber scams", placeholder: "Type your question...", send: "Send" },
    hi: { title: "VRIDDHAKSHA AI सहायक", subtitle: "साइबर घोटालों के बारे में पूछें", placeholder: "अपना प्रश्न टाइप करें...", send: "भेजें" },
    gu: { title: "VRIDDHAKSHA AI સહાયક", subtitle: "સાઇબર છળ વિશે પૂછો", placeholder: "તમારો પ્રશ્ન ટાઇપ કરો...", send: "મોકલો" },
  };
  const L = labels[lang as keyof typeof labels] ?? labels.en;

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!open && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setOpen(true)}
            className="fixed bottom-6 right-6 z-50 w-16 h-16 rounded-full bg-gradient-to-br from-[#0B3D91] to-blue-600 text-white shadow-2xl flex items-center justify-center border-4 border-white"
            aria-label="Open AI Chat"
            data-testid="button-chatbot-open"
          >
            <motion.div
              className="absolute w-20 h-20 rounded-full border-2 border-blue-400"
              animate={{ scale: [1, 1.3, 1], opacity: [0.6, 0, 0.6] }}
              transition={{ repeat: Infinity, duration: 2 }}
            />
            <Bot className="w-7 h-7 relative z-10" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 60 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 60 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed bottom-6 right-6 z-50 w-[360px] max-w-[calc(100vw-24px)] rounded-3xl shadow-2xl overflow-hidden border border-border flex flex-col"
            style={{ height: 520 }}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-[#0B3D91] to-blue-600 p-4 text-white flex items-center gap-3 flex-shrink-0">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Bot className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-heading font-bold text-sm leading-tight">{L.title}</div>
                <div className="text-xs text-blue-200 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                  {L.subtitle}
                </div>
              </div>
              <div className="flex items-center gap-1">
                <a href="tel:1930" className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors" title="Call 1930">
                  <Phone className="w-4 h-4" />
                </a>
                <button onClick={() => { setOpen(false); setMessages([]); }} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors" aria-label="Close chat">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-background">
              {messages.map((m, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {m.role === "bot" && (
                    <div className="w-7 h-7 rounded-full bg-[#0B3D91] flex items-center justify-center mr-2 flex-shrink-0 mt-1">
                      <Shield className="w-3.5 h-3.5 text-white" />
                    </div>
                  )}
                  <div className={`max-w-[78%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${m.role === "user" ? "bg-[#0B3D91] text-white rounded-br-sm" : "bg-muted text-foreground rounded-bl-sm"}`}>
                    {m.text.split("**").map((part, j) => j % 2 === 1 ? <strong key={j}>{part}</strong> : part)}
                    <div className={`text-xs mt-1 opacity-60 ${m.role === "user" ? "text-right" : ""}`}>{m.time}</div>
                  </div>
                </motion.div>
              ))}
              {typing && (
                <div className="flex justify-start">
                  <div className="w-7 h-7 rounded-full bg-[#0B3D91] flex items-center justify-center mr-2 flex-shrink-0">
                    <Shield className="w-3.5 h-3.5 text-white" />
                  </div>
                  <div className="bg-muted rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-1">
                    {[0, 0.2, 0.4].map(d => (
                      <motion.span key={d} className="w-2 h-2 bg-muted-foreground rounded-full" animate={{ y: [0, -4, 0] }} transition={{ repeat: Infinity, duration: 0.8, delay: d }} />
                    ))}
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Quick Chips */}
            <div className="px-3 py-2 bg-background border-t border-border flex gap-2 overflow-x-auto flex-shrink-0">
              {["OTP Scam", "UPI Fraud", "Report Crime", "Emergency"].map(chip => (
                <button key={chip} onClick={() => sendMessage(chip)}
                  className="text-xs px-3 py-1.5 rounded-full border border-[#0B3D91] text-[#0B3D91] hover:bg-blue-50 transition-colors whitespace-nowrap flex-shrink-0 font-medium">
                  {chip}
                </button>
              ))}
            </div>

            {/* Input */}
            <div className="p-3 bg-background border-t border-border flex items-center gap-2 flex-shrink-0">
              <button
                onClick={startListening}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors flex-shrink-0 ${listening ? "bg-red-500 text-white" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}
                aria-label="Voice input"
                data-testid="button-voice-input"
              >
                {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
              <input
                type="text"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && sendMessage(input)}
                placeholder={L.placeholder}
                className="flex-1 text-sm bg-muted rounded-full px-4 py-2.5 outline-none text-foreground placeholder:text-muted-foreground border border-transparent focus:border-[#0B3D91] transition-colors"
                data-testid="input-chatbot"
              />
              <button
                onClick={() => sendMessage(input)}
                className="w-10 h-10 rounded-full bg-[#0B3D91] text-white flex items-center justify-center hover:bg-[#0a3480] transition-colors flex-shrink-0 disabled:opacity-50"
                disabled={!input.trim() || typing}
                aria-label="Send message"
                data-testid="button-chatbot-send"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
